"""
Smart CafeX — the Odoo-style workspace layer.

This module doesn't re-implement any analytics. It sits on top of the engines
that already exist (analytics, menu_engineering, positioning, complaints,
templates) and adds the three things the Smart CafeX UI needs that the classic
app didn't have:

  1. Per-account data that survives logout  — the Sales and Review files an
     owner uploads are pickled to their account (via user_store) and reused
     until they click "Update". On load we hydrate the browser session from
     them so every existing analytics endpoint works unchanged.

  2. Actionable insights for the Approval panel — a small, ranked set of
     "do this" cards drawn from the owner's own data. Each can be Approved
     (which "executes" it — today that means producing the ready-to-use Excel:
     the win-back list + messages, the menu combos, the reputation/complaint
     action plan), Disapproved (hidden), or opened for details.

  3. A per-account task list.

Decisions and tasks live in the user's JSON state; the two dataframes live as
pickles beside it.
"""
from __future__ import annotations

import hashlib
import io
import threading

import pandas as pd

from backend.core import cache
from backend.core import (analytics, complaints, content_gen, positioning, product_config,
                          templates, user_store)

SALES_KEY = "smart_sales_txns"
REVIEW_KEY = "smart_review_df"
SUPPLY_SALES_KEY = "smart_supply_sales_txns"   # separate "previous sales" set, used ONLY by Supply


# ---------------------------------------------------------
# Product type (what the seller sells) — drives keyword tracking everywhere
# ---------------------------------------------------------
PRODUCT_LABEL_KEY = "product_type_label"


def get_product_type(email: str) -> str:
    return product_config.normalize(user_store.get_key(email, "product_type", None))


def get_product_label(email: str) -> str:
    """What this seller calls what they sell, in their own words. "" if they
    have not said — never a guess."""
    return product_config.clean_label(user_store.get_key(email, PRODUCT_LABEL_KEY, ""))


def product_meta(email: str) -> dict:
    """The type, with the seller's own label and nouns. This is what every
    caption, hashtag and image prompt should ask for — not the raw id, which
    says "product" for everyone outside the four presets."""
    return product_config.meta(get_product_type(email), get_product_label(email))


def set_product_type(email: str, product_type: str, label: str | None = None) -> str:
    """Save what this seller sells.

    `label` is their own words and may refine a preset — "Kundan jewellery"
    with type jewellery is better than either alone. But CHANGING THE TYPE
    without giving new words clears the old ones: a seller who typed "Soy wax
    candles" and then picked Jewellery does not still sell candles, and leaving
    the stale label would have every caption say so."""
    pt = product_config.normalize(product_type)
    was = product_config.normalize(user_store.get_key(email, "product_type", None))
    user_store.set_key(email, "product_type", pt)
    if label is not None:
        user_store.set_key(email, PRODUCT_LABEL_KEY, product_config.clean_label(label))
    elif pt != was:
        user_store.set_key(email, PRODUCT_LABEL_KEY, "")
    return pt


# ---------------------------------------------------------
# Data persistence + session hydration
# ---------------------------------------------------------
def save_sales(email: str, txns: pd.DataFrame, meta: dict, mode: str = "replace") -> None:
    """Persist the account's Sales data.

    mode="replace" (default) overwrites; mode="append" adds the new rows on top
    of whatever is already saved (used by the "Add records" flow). Both frames
    are canonical Transactions frames from mapper.build_transactions, so their
    columns line up for a straight concat.
    """
    if mode == "append":
        existing = load_sales(email)
        if existing is not None and len(existing):
            txns = pd.concat([existing, txns], ignore_index=True)
    user_store.save_df(email, SALES_KEY, txns)
    st = user_store.get_key(email, "smart_data", {}) or {}
    st["sales"] = {**meta, "rows": int(len(txns)),
                   "updated_at": pd.Timestamp.now().isoformat(timespec="seconds")}
    user_store.set_key(email, "smart_data", st)


def save_review(email: str, df: pd.DataFrame, meta: dict, mode: str = "replace") -> None:
    """Persist the account's Review data.

    mode="replace" (default) overwrites; mode="append" stacks the new rows onto
    the saved reviews (the "Add records" flow). Columns are canonicalised to
    Review/Rating/Date before saving, so the concat aligns.
    """
    if mode == "append":
        existing = load_review(email)
        if existing is not None and len(existing):
            df = pd.concat([existing, df], ignore_index=True)
    user_store.save_df(email, REVIEW_KEY, df)
    st = user_store.get_key(email, "smart_data", {}) or {}
    st["review"] = {**meta, "rows": int(len(df)),
                    "updated_at": pd.Timestamp.now().isoformat(timespec="seconds")}
    user_store.set_key(email, "smart_data", st)


def load_sales(email: str):
    return user_store.load_df(email, SALES_KEY)


def load_review(email: str):
    return user_store.load_df(email, REVIEW_KEY)


def save_supply_sales(email: str, txns: pd.DataFrame, meta: dict, mode: str = "replace") -> None:
    """Persist the Supply module's own historical/"previous" sales set. Kept
    separate from the main Sales data — it feeds the supply-chain math only."""
    if mode == "append":
        existing = load_supply_sales(email)
        if existing is not None and len(existing):
            txns = pd.concat([existing, txns], ignore_index=True)
    user_store.save_df(email, SUPPLY_SALES_KEY, txns)
    st = user_store.get_key(email, "smart_data", {}) or {}
    st["supply_sales"] = {**meta, "rows": int(len(txns)),
                          "updated_at": pd.Timestamp.now().isoformat(timespec="seconds")}
    user_store.set_key(email, "smart_data", st)


def load_supply_sales(email: str):
    return user_store.load_df(email, SUPPLY_SALES_KEY)


def clear(email: str, kind: str) -> None:
    st = user_store.get_key(email, "smart_data", {}) or {}
    if kind == "sales":
        user_store.delete_df(email, SALES_KEY); st.pop("sales", None)
    elif kind == "review":
        user_store.delete_df(email, REVIEW_KEY); st.pop("review", None)
    elif kind == "supply_sales":
        user_store.delete_df(email, SUPPLY_SALES_KEY); st.pop("supply_sales", None)
    user_store.set_key(email, "smart_data", st)


def data_status(email: str) -> dict:
    st = user_store.get_key(email, "smart_data", {}) or {}
    return {
        "sales": {"ready": user_store.has_df(email, SALES_KEY), **(st.get("sales") or {})},
        "review": {"ready": user_store.has_df(email, REVIEW_KEY), **(st.get("review") or {})},
        "supply_sales": {"ready": user_store.has_df(email, SUPPLY_SALES_KEY), **(st.get("supply_sales") or {})},
    }


def hydrate_session(email: str, sess) -> dict:
    """Load the account's saved Sales data into the live browser session so the
    existing /api/analytics, /api/subcategory, /api/rfm endpoints work on it."""
    txns = load_sales(email)
    if txns is not None and len(txns):
        try:
            from backend.core import products as _products
            txns = _products.canonicalize_df(email, txns)
        except Exception:
            pass
        sess.txns_df = txns
        sess.mapped_file_id = "smart_sales"
    return data_status(email)


# ---------------------------------------------------------
# Actionable insights for the Approval panel
# ---------------------------------------------------------
def _content_suggestion_insights(email: str) -> list[dict]:
    """One 'suggested post' card in the Approval panel, pulled from the
    ranked topic bank + generated on demand when the user opens details.
    Stored in the account so the same suggestion sticks between reloads
    (a new one appears once the seller approves/dismisses the current one)."""
    # Until the seller has said what they sell or given us their sales, the
    # only idea we have is the generic one ("this week's trending angle for
    # small brands"), and the first suggestion a brand-new seller ever saw read
    # like filler. Hold it back until there is something specific to say.
    known_type = product_config.normalize(get_product_type(email)) != "generic"
    has_sales = bool((data_status(email).get("sales") or {}).get("ready"))
    if not known_type and not has_sales:
        return []
    stored = user_store.get_key(email, "content_current_suggestion", None)
    if not stored or stored.get("_gone"):
        pt = get_product_type(email)
        topic = content_gen.suggest_topic(pt)
        stored = {
            "id": f"content_{__import__('secrets').token_hex(4)}",
            "topic": topic,
            "product_type": pt,
            "platform": "instagram",
            "generated": False,   # only text/image once the seller opens details
            "created_at": pd.Timestamp.now().isoformat(timespec="seconds"),
        }
        user_store.set_key(email, "content_current_suggestion", stored)
    return [{
        "id": stored["id"], "module": "content", "page": "content", "icon": "image",
        "title": f"Suggested post: {stored['topic']}",
        "detail": ("An Instagram post idea based on what's trending for your product type. "
                   "Open Details to see the caption, hashtags and image, edit anything, "
                   "then Post now or schedule."),
        "action_label": "Approve → post to Instagram", "has_download": False,
        "content": True,
    }]


def clear_content_suggestion(email: str) -> None:
    """Marks the current suggestion as gone so the next status call regenerates one."""
    user_store.set_key(email, "content_current_suggestion", None)


def get_or_generate_content(email: str, insight_id: str, force: bool = False) -> dict | None:
    """Return the FULL suggestion (caption, hashtags, image) for the given
    Approval-panel content id, generating it on first open (or when force=True)."""
    from backend.core import content_gen as _cg
    stored = user_store.get_key(email, "content_current_suggestion", None) or {}
    if stored.get("id") != insight_id:
        return None
    if force or not stored.get("generated"):
        full = _cg.generate_suggestion(email, product_type=stored.get("product_type"),
                                       topic=stored.get("topic"),
                                       platform=stored.get("platform", "instagram"))
        # keep the original id (the one in the panel) so decisions match up
        full["id"] = stored["id"]
        stored.update(full)
        stored["generated"] = True
        user_store.set_key(email, "content_current_suggestion", stored)
    return stored


def save_content_suggestion(email: str, insight_id: str, edits: dict) -> dict | None:
    stored = user_store.get_key(email, "content_current_suggestion", None) or {}
    if stored.get("id") != insight_id:
        return None
    for k in ("caption", "hashtags", "description", "image_url", "platform", "topic"):
        if k in edits and edits[k] is not None:
            stored[k] = edits[k]
    user_store.set_key(email, "content_current_suggestion", stored)
    return stored


def _festival_insight(email: str) -> dict | None:
    """Fire when the campaign should START, not when the festival arrives.

    A Diwali card that appears on Diwali is useless. The lead time is per
    festival because they are not equal: Diwali wants roughly two and a half
    weeks of run-up, Dhanteras about five days."""
    try:
        from backend.core import localtime as _lt, social as _social
        s = _social.get_settings(email)
        # The seller's date. A festival card that fires on the server's day is
        # a day early or late for anyone not living in UTC, and this card is
        # the one that says "start posting on the 22nd".
        upcoming = _social.upcoming_festivals(_lt.today(email),
                                              category=s.get("category") or "")
    except Exception:  # noqa: BLE001
        return None
    due = [f for f in upcoming if f.get("start_in_days", 99) <= 7]
    if not due:
        return None
    f = due[0]
    return {
        "id": "festival", "module": "sales", "page": "social", "icon": "gift",
        "title": f"Plan the {f['name']} campaign",
        "detail": f"{f['name']} is {f['days_away']} days away.",
        "action_label": "Build the plan",
        "festival": f["name"], "days_away": f["days_away"],
        "start_on": f.get("start_on", ""), "act_now": bool(f.get("act_now")),
        "count": 1, "has_download": False,
    }


def build_insights(email: str, include_decided: bool = False) -> list[dict]:
    """Ranked 'do this' cards from the owner's own data.

    By default the Approval panel only shows *pending* items — approved or
    dismissed ones move to History and drop out of the active list, so the
    owner isn't looking at cards they've already answered. Pass
    include_decided=True to get every card the data currently produces
    (used by build_history to know which historic items are still valid for
    re-download).
    """
    from backend.core import personas
    decisions = user_store.get_key(email, "smart_decisions", {}) or {}
    out: list[dict] = []
    txns = load_sales(email)
    review = load_review(email)

    if txns is not None and len(txns):
        # 1) win-back campaign
        #
        # TWO DIFFERENT CARDS, and the difference matters. The weekly job
        # (backend/core/winback_auto.py) prepares an actual batch — these
        # specific people, these specific messages, nobody contacted in the
        # last 45 days — and approving it SENDS. When no batch is waiting the
        # old card stands: a standing offer to generate one by hand, which ends
        # in a spreadsheet. Showing the sending card when nothing is prepared
        # would mean "Approve → send" sent something the seller never saw.
        from backend.core import winback_auto
        waiting = None
        try:
            waiting = winback_auto.pending(email)
        except Exception:  # noqa: BLE001
            waiting = None
        if waiting:
            n = len(waiting.get("rows") or [])
            reach = int(waiting.get("reachable") or 0)
            cooled = int(waiting.get("skipped_cooldown") or 0)
            detail = (f"{n} regulars have gone quiet. The messages are written — each one "
                      f"names what that customer actually bought — and {reach} of them have "
                      f"an email or phone on file. Approve and they go out from your own "
                      f"address.")
            if cooled:
                detail += (f" {cooled} more were left out because they were already "
                           f"contacted in the last {winback_auto.COOLDOWN_DAYS} days.")
            out.append({
                "id": "winback_auto", "module": "marketing", "page": "winback", "icon": "mail",
                "title": f"Send this week's win-back to {reach or n} customers",
                "detail": detail,
                "action_label": "Approve → send now", "count": reach or n,
                "value": round(float(waiting.get("value") or 0), 2) or None,
            })
        else:
            # same shared pool the Today strip and the campaign generator read
            at_risk = analytics.at_risk_cached(email, txns)
            if at_risk:
                out.append({
                    "id": "winback", "module": "sales", "page": "winback", "icon": "mail",
                    "title": f"Win back {len(at_risk)} at-risk customers",
                    "detail": (f"{len(at_risk)} regulars haven't visited in a while. Approve to generate a "
                               "ready-to-send message + personalised coupon for each, exported to Excel."),
                    "action_label": "Approve → download campaign", "count": len(at_risk),
                    "value": round(sum(float(c.get("monetary") or 0) for c in at_risk), 2) or None,
                    "has_download": True,
                })
    if review is not None and len(review):
        pt = get_product_type(email)
        # 2) reputation / positioning
        try:
            pos = positioning.analyze_reviews(review, "en", product_type=pt)
        except Exception:
            pos = {"available": False}
        if pos.get("available") and pos.get("insights"):
            out.append({
                "id": "reputation", "module": "review", "page": "positioning", "icon": "star",
                "title": "Act on your brand positioning",
                "detail": (f"From {pos.get('n_reviews', 0)} reviews we found {len(pos['insights'])} positioning "
                           "moves for your brand. Approve to export the prioritised action plan."),
                "action_label": "Approve → download action plan", "count": len(pos["insights"]), "has_download": True,
            })
        # 3) complaints focus
        try:
            comp = complaints.analyze_complaints(review, product_type=pt)
        except Exception:
            comp = {"actions": []}
        focus = (comp.get("focus") or {}).get("focus_now") or []
        if focus:
            out.append({
                "id": "complaints", "module": "review", "page": "complaints", "icon": "flame",
                "title": f"Fix your top {len(focus)} complaint themes",
                "detail": ("These are the complaint themes hurting you most right now. Approve to export the "
                           "fix-first action plan."),
                "action_label": "Approve → download fix plan", "count": len(focus), "has_download": True,
            })

    # 4) supply — items at/below their reorder point
    from backend.core import supply as _supply
    reorder_card = _supply.build_reorder_insight(email)
    if reorder_card:
        out.append(reorder_card)
    # 4b) the mirror card nobody builds — stock sitting too long. Running out
    # is loud; overstock is silent, and it is where a small seller's cash goes.
    over_card = _supply.build_overstock_insight(email)
    if over_card:
        out.append(over_card)
    # 4c) single-sourced items. Invisible until the day it is not.
    risk_card = _supply.build_supplier_risk_insight(email)
    if risk_card:
        out.append(risk_card)
    # 4d) the calendar. Festival demand is the single biggest driver for
    # clothing and jewellery in India, and it is missed by being late, not by
    # being wrong — so the card fires on the START date, not the festival.
    fest_card = _festival_insight(email)
    if fest_card:
        out.append(fest_card)

    # 5) one 'suggested post' — a content-creator idea in the same panel
    if not include_decided:
        out.extend(_content_suggestion_insights(email))

    # 6) real, already-written posts waiting on a decision. These used to
    # have their own separate approve/skip strip on the Social Media
    # Manager page; now they're cards here like everything else, so there is
    # exactly one place a seller decides anything. Not scoped by
    # include_decided the same way as the others -- pending_insight_cards()
    # only ever returns posts still in "draft", so a post that was already
    # approved or skipped naturally stops appearing on its own, no bookkeeping
    # in smart_decisions needed (the post's own state IS the decision).
    if not include_decided:
        from backend.core import social as _social_mod
        out.extend(_social_mod.pending_insight_cards(email))

    # 7) purchase orders the replenishment check drafted after an order came
    # in. Like posts, the PO's own status is the decision.
    if not include_decided:
        try:
            from backend.core import replenish as _replenish
            out.extend(_replenish.insight_cards(email))
        except Exception:  # noqa: BLE001 — never let this take the panel down
            pass

    # attach each card's decision; hide decided ones from the active panel
    # unless the caller explicitly asked for the full list.
    visible = []
    for card in out:
        if card["id"] == "reorder":
            card["decision"] = _supply.reorder_decision_state(email)
            card["decided_at"] = None
        else:
            d = decisions.get(card["id"])
            card["decision"] = (d.get("state") if isinstance(d, dict) else d) or "pending"
            card["decided_at"] = d.get("at") if isinstance(d, dict) else None
        if include_decided:
            visible.append(card)
        elif card["decision"] == "pending":
            visible.append(card)
    return personas.dress_all(visible)


def build_history(email: str) -> dict:
    """History view: everything ever approved or dismissed, newest first.
    Each entry knows if it's still *valid* (its data still produces the card)
    so the UI can offer re-download for approved items."""
    decisions = user_store.get_key(email, "smart_decisions", {}) or {}
    # a fresh snapshot of every currently-producible card, keyed by id
    live = {c["id"]: c for c in build_insights(email, include_decided=True)}
    approved, dismissed = [], []
    for iid, rec in decisions.items():
        state = rec.get("state") if isinstance(rec, dict) else rec
        at = rec.get("at") if isinstance(rec, dict) else None
        # title/icon: prefer live, fall back to remembered snapshot on the record
        snap = live.get(iid) or (rec.get("snapshot") if isinstance(rec, dict) else None) or {}
        entry = {
            "id": iid, "title": snap.get("title", iid), "icon": snap.get("icon", "•"),
            "detail": snap.get("detail", ""), "at": at,
            "valid": iid in live, "has_download": bool(snap.get("has_download")),
        }
        # tolerate the earlier "disapproved" label; "dismissed" is the new name.
        if state == "approved":
            approved.append(entry)
        elif state in ("dismissed", "disapproved"):
            dismissed.append(entry)
    # newest first (fall back to 0 when a legacy record lacks a timestamp)
    approved.sort(key=lambda e: e.get("at") or "", reverse=True)
    dismissed.sort(key=lambda e: e.get("at") or "", reverse=True)
    return {"approved": approved, "dismissed": dismissed}


def _decision_snapshot(email: str, insight_id: str) -> dict:
    """Look the insight up in the current live list so we can remember its
    title/detail even if the underlying data later changes (so History still
    reads sensibly six months later)."""
    for c in build_insights(email, include_decided=True):
        if c["id"] == insight_id:
            return {k: c[k] for k in ("title", "icon", "detail", "has_download") if k in c}
    return {}


def set_decision(email: str, insight_id: str, decision: str) -> None:
    import pandas as pd
    decisions = user_store.get_key(email, "smart_decisions", {}) or {}
    prev = decisions.get(insight_id) or {}
    snapshot = prev.get("snapshot") if isinstance(prev, dict) else None
    if not snapshot:
        snapshot = _decision_snapshot(email, insight_id)
    decisions[insight_id] = {
        "state": decision,
        "at": pd.Timestamp.now().isoformat(timespec="seconds"),
        "snapshot": snapshot,
    }
    user_store.set_key(email, "smart_decisions", decisions)


def reset_decision(email: str, insight_id: str) -> None:
    """Undo — pull the item back into the active Approval panel."""
    decisions = user_store.get_key(email, "smart_decisions", {}) or {}
    decisions.pop(insight_id, None)
    user_store.set_key(email, "smart_decisions", decisions)


# ---------------------------------------------------------
# Approve == execute -> produce the Excel deliverable
# ---------------------------------------------------------
def _combo_message(item: str, pair: str, discount: int = 15) -> str:
    return (f"NEW combo alert! Grab a {item} + {pair} together and save {discount}%. "
            f"The perfect pair — only this week. See you at the counter!")


def insight_excel(email: str, insight_id: str) -> tuple[str, io.BytesIO] | None:
    """Build the ready-to-use Excel for an approved insight. Returns
    (filename, BytesIO) or None if the underlying data has gone."""
    if str(insight_id).startswith("reorder"):
        from backend.core import supply as _supply
        po = _supply.po_for_insight(email, insight_id)
        return _supply.po_excel(email, po) if po else None

    txns = load_sales(email)
    review = load_review(email)

    if insight_id == "winback" and txns is not None:
        rows = templates.build_winback_messages(analytics.at_risk_cached(email, txns))
        if not rows:
            return None
        df = pd.DataFrame(rows).rename(columns={
            "customer_id": "Customer ID", "customer_name": "Customer Name",
            "recency_days": "Days Since Last Visit", "frequency": "Total Orders",
            "monetary": "Total Spend", "last_purchase_date": "Last Purchase Date",
            "favorite_item": "Favorite Item", "price_tier": "Spend Tier",
            "coupon_code": "Coupon Code", "discount_pct": "Discount %", "message": "AI Message",
        })
        cols = ["Customer ID", "Customer Name", "Last Purchase Date", "Days Since Last Visit",
                "Total Orders", "Total Spend", "Favorite Item", "Spend Tier",
                "Coupon Code", "Discount %", "AI Message"]
        df = df[[c for c in cols if c in df.columns]]
        return "smart_cafex_winback_campaign.xlsx", _to_xlsx(df, "Win-back Campaign")

    if insight_id == "reputation" and review is not None:
        pos = positioning.analyze_reviews(review, "en", product_type=get_product_type(email))
        if not pos.get("available"):
            return None
        df = pd.DataFrame([{
            "Priority": i + 1,
            "Insight": ins.get("text", ""),
            "Recommended Action": ins.get("action", ""),
        } for i, ins in enumerate(pos.get("insights", []))])
        return "smart_cafex_positioning_plan.xlsx", _to_xlsx(df, "Positioning Plan")

    if insight_id == "complaints" and review is not None:
        comp = complaints.analyze_complaints(review, product_type=get_product_type(email))
        focus = (comp.get("focus") or {}).get("focus_now") or []
        if not focus:
            return None
        df = pd.DataFrame([{
            "Rank": i + 1, "Theme": x.get("theme", ""), "Severity": x.get("severity", ""),
            "Complaints": x.get("count", 0), "Share %": x.get("share_pct", ""),
            "Fix-First Action": x.get("action", ""),
        } for i, x in enumerate(focus)])
        return "smart_cafex_complaint_fix_plan.xlsx", _to_xlsx(df, "Complaint Fix Plan")

    return None


def _to_xlsx(df: pd.DataFrame, sheet: str) -> io.BytesIO:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet[:31])
        ws = writer.sheets[sheet[:31]]
        for i, col in enumerate(df.columns):
            width = min(70, max(12, int(df[col].astype(str).str.len().max() if len(df) else 12) + 2, len(str(col)) + 2))
            ws.column_dimensions[chr(65 + i) if i < 26 else "A"].width = width
    buf.seek(0)
    return buf


# ---------------------------------------------------------
# Task list (per account)
# ---------------------------------------------------------
# One lock around every read-then-write of the task list. user_store locks a
# single write, not a read followed by a write, and the setup journey's
# reconcile (onboarding.py) ticks tasks while the seller may be ticking one
# too. Without this, the later write silently drops the earlier one. The app
# runs one uvicorn worker (render.yaml); with more workers this becomes a
# per-account file lock. Re-entrant so a helper can call another helper.
TASK_LOCK = threading.RLock()


def get_tasks(email: str) -> list[dict]:
    return user_store.get_key(email, "smart_tasks", []) or []


def add_task(email: str, text: str, ob: str = "") -> list[dict]:
    """`ob` tags a task as belonging to the setup journey ("step:products",
    "part:2"), so the row can open the journey and close itself when done."""
    text = (text or "").strip()
    if not text:
        return get_tasks(email)
    with TASK_LOCK:
        tasks = get_tasks(email)
        tid = hashlib.md5(f"{text}{pd.Timestamp.now().isoformat()}".encode()).hexdigest()[:10]
        row = {"id": tid, "text": text[:280], "done": False}
        if ob:
            row["ob"] = str(ob)[:40]
        tasks.append(row)
        user_store.set_key(email, "smart_tasks", tasks)
        return tasks


def toggle_task(email: str, task_id: str, done: bool) -> list[dict]:
    with TASK_LOCK:
        tasks = get_tasks(email)
        for t in tasks:
            if t["id"] == task_id:
                t["done"] = bool(done)
        user_store.set_key(email, "smart_tasks", tasks)
        return tasks


def delete_task(email: str, task_id: str) -> list[dict]:
    with TASK_LOCK:
        tasks = [t for t in get_tasks(email) if t["id"] != task_id]
        user_store.set_key(email, "smart_tasks", tasks)
        return tasks


# ---------------------------------------------------------
# Post tasks — the work an approved post still needs from the seller
# ---------------------------------------------------------
# A reel cannot be drawn for the seller: approving one creates a task that
# walks them through it (copy the prompt → Google Flow → paste and generate →
# upload the clip → schedule). A photo post whose picture could not be made
# gets a smaller one. These live in the same list as hand-written tasks so
# there is one to-do list, not two, but they carry the post they belong to and
# are closed automatically when that post is scheduled or cancelled (see
# social._sync_tasks), so the seller never has to tick off something the app
# already knows is done.
VIDEO_STEPS = [
    {"id": "copy", "label": "Copy the video prompt"},
    {"id": "flow", "label": "Open Google Flow"},
    {"id": "make", "label": "Paste the prompt, generate, download the clip"},
    {"id": "upload", "label": "Upload the clip here"},
    {"id": "schedule", "label": "Save & schedule"},
]
PHOTO_STEPS = [
    {"id": "picture", "label": "Add a picture (generate one or upload your own)"},
    {"id": "schedule", "label": "Save & schedule"},
]
# The out-of-images fallback, deliberately shaped like the reel task so the two
# feel like one thing. It carries the shot we WOULD have generated as a prompt
# to copy — so a seller who has used the month's 30 pictures knows exactly what
# photo to take (or paste into another tool), instead of being told "add a
# picture" with no idea what picture.
PHOTO_UPLOAD_STEPS = [
    {"id": "copy", "label": "Copy the shot idea"},
    {"id": "shoot", "label": "Take or make a photo of the product"},
    {"id": "upload", "label": "Upload the photo here"},
    {"id": "schedule", "label": "Save & schedule"},
]


def post_tasks(email: str) -> list[dict]:
    return [t for t in get_tasks(email) if t.get("post_id")]


def ensure_post_task(email: str, post: dict, kind: str = "video",
                     reason: str = "", prompt: str = "") -> dict:
    """The open task for this post, creating it if there is none. New post
    tasks go to the TOP of the list — they are the ones with a date on them.

    `prompt` is the shot the app would have generated. It is passed only on the
    out-of-images fallback: when it is present the task becomes the "upload your
    own photo" walkthrough (copy the shot idea, take the photo, upload, schedule)
    that mirrors the reel task, rather than the bare "add a picture" one. An
    existing open task for the post is returned untouched, but if it has no
    prompt yet and one is now available, the prompt is filled in — so a photo
    post that first failed for another reason still gets the shot idea the moment
    the cap is what is blocking it."""
    tasks = get_tasks(email)
    pid = post.get("id") or ""
    for t in tasks:
        if t.get("post_id") == pid and not t.get("done"):
            if prompt and not t.get("ai_prompt"):
                t["ai_prompt"] = str(prompt)[:2000]
                if kind != "video":
                    t["steps"] = PHOTO_UPLOAD_STEPS
                user_store.set_key(email, "smart_tasks", tasks)
            return t
    name = post.get("product_name") or "your post"
    when = post.get("scheduled_at") or ""
    try:
        label = pd.Timestamp(when).strftime("%a %d %b, %I:%M %p").replace(" 0", " ")
    except Exception:  # noqa: BLE001
        label = when
    if kind == "video":
        head = f"Make the reel for {name}"
    elif prompt:
        head = f"Add your own photo to the {name} post"
    else:
        head = f"Add a picture to the {name} post"
    text = head + (f" — goes out {label}" if label else "")
    steps = (VIDEO_STEPS if kind == "video"
             else PHOTO_UPLOAD_STEPS if prompt else PHOTO_STEPS)
    t = {"id": hashlib.md5(f"{pid}{kind}{pd.Timestamp.now().isoformat()}".encode()).hexdigest()[:10],
         "text": text[:280], "done": False, "kind": kind, "post_id": pid,
         "product_name": name, "due": when, "format": post.get("format") or "",
         "reason": (reason or "")[:300],
         "ai_prompt": (prompt or "")[:2000],
         "steps": steps,
         "steps_done": [],
         "created_at": pd.Timestamp.now().isoformat(timespec="seconds")}
    tasks.insert(0, t)
    user_store.set_key(email, "smart_tasks", tasks)
    return t


def close_post_tasks(email: str, post_id: str, remove: bool = False) -> list[dict]:
    """Tick off (or drop, for a cancelled post) every task tied to one post."""
    tasks = get_tasks(email)
    changed = False
    out = []
    for t in tasks:
        if t.get("post_id") == post_id and not t.get("done"):
            changed = True
            if remove:
                continue
            t["done"] = True
            t["steps_done"] = [s["id"] for s in (t.get("steps") or [])]
            t["done_at"] = pd.Timestamp.now().isoformat(timespec="seconds")
        out.append(t)
    if changed:
        user_store.set_key(email, "smart_tasks", out)
    return out


def task_progress(email: str, task_id: str, step: str, done: bool = True) -> list[dict]:
    """Remember which steps of a post task the seller has already done, so the
    popup reopens where they left off (on another device too)."""
    tasks = get_tasks(email)
    for t in tasks:
        if t["id"] == task_id:
            steps = [s for s in (t.get("steps_done") or []) if s != step]
            if done:
                steps.append(step)
            t["steps_done"] = steps
    user_store.set_key(email, "smart_tasks", tasks)
    return tasks

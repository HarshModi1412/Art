"""
Cafe_X — standalone web application (migrated from Streamlit).

Run:  uvicorn backend.main:app --reload
Then open http://localhost:8000

What replaced what:
  st.session_state           -> per-browser session (X-Session-Id header) + login token
  st.file_uploader           -> POST /api/upload
  sidebar radio navigation   -> frontend router (single-page app)
  st.secrets["OPENAI_..."]   -> OPENAI_API_KEY environment variable
  st.plotly_chart            -> JSON chart data rendered with Plotly.js
"""
import datetime as _dt
import hashlib
import io
import hmac
import json
import math
import os
import re
import secrets
import time

import pandas as pd
import logging

from fastapi import FastAPI, File, Header, HTTPException, Request, UploadFile
from fastapi.responses import Response, FileResponse, JSONResponse, RedirectResponse
from fastapi.encoders import jsonable_encoder
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.core import (ad_analytics, ai, analytics, auth, billing, complaints, connectors,
                          content_gen, email_intake, i18n, instagram, joiner, mapper,
                          pos_formats, position_strategy, positioning, pricing, product_config,
                          report_pdf, smart, templates, user_store)
from backend.core import commerce, secrets_store, db, supply, products
from backend.core import sitebuilder, storefront
from backend.core import messaging, password_reset, today as today_mod
from backend.core import winback_proof
from backend.core import loginguard, google_auth, winback_auto, publisher
from backend.core import ratelimit
from backend.core import geo
from backend.core import onboarding
from backend.core import media
from backend.core import cache
from backend.core import cancellations
from backend.core import store_payments
from backend.core import campaigns
from backend.core import brandname
from backend.core import setup_steps
from backend.core import videotools
from backend.core import errors
from backend.core import health
from backend.core import aicaps
from backend.core import legal
from backend.core import legal_html
from backend.core import studio
from backend.core import aiprovider
from backend.core import gst, invoices, invoice_pdf
from backend.core import labels
from backend.core import cancel_requests
from backend.core import social
from backend.core import personas
from backend.core import playbook
from backend.core import autoplan
from backend.core import watermark
from backend.core import publicurl
from backend.core import ailabel as ailabel_mod
from backend.core import localtime
from backend.core import seller_mail
from backend.core import replenish
from backend.core import writer

# ---------------------------------------------------------
# numpy/pandas JSON safety net
# ---------------------------------------------------------
# Several analytics outputs carry numpy scalar types (np.int64 / np.float64) —
# e.g. the sales forecast series. Older FastAPI versions serialized these
# silently; newer ones raise "Object of type int64 is not JSON serializable"
# during response encoding, which would 500 the analytics/RFM pages after a
# routine `pip install -r requirements.txt` (fastapi is unpinned) on redeploy.
# Registering encoders here makes every endpoint numpy-safe regardless of the
# installed FastAPI/numpy versions. Purely additive — never removes behaviour.
try:
    import numpy as _np
    from fastapi import encoders as _enc
    _enc.ENCODERS_BY_TYPE[_np.integer] = int
    _enc.ENCODERS_BY_TYPE[_np.floating] = float
    _enc.ENCODERS_BY_TYPE[_np.bool_] = bool
    _enc.ENCODERS_BY_TYPE[_np.ndarray] = lambda a: a.tolist()
    if hasattr(_enc, "generate_encoders_by_class_tuples"):
        _enc.encoders_by_class_tuples = _enc.generate_encoders_by_class_tuples(_enc.ENCODERS_BY_TYPE)
except Exception:
    pass

# ---------------------------------------------------------------------------
# GATE 1 BLOCKER #1: a NaN anywhere in a response was a 500.
#
# The symptom a seller saw: Sales Analytics loads fine on Monday, and on
# Tuesday — after uploading one file with a blank amount, or after a category
# with no rows in the compare window — the whole page dies with "Server error".
# Nothing they can do about it, nothing explaining it.
#
# The cause is one line inside Starlette: JSONResponse serialises with
# allow_nan=False, so the moment any computed number is NaN or Infinity
# (a mean over an empty group, a 0/0 growth rate, a blank cell that pandas
# reads as NaN) json.dumps raises and FastAPI turns it into a 500.
#
# Patching the handful of places that produce a NaN is whack-a-mole: every new
# division is a new outage. So it is fixed once, at the wire, for every
# endpoint: NaN and Infinity become null, which every chart and card in the
# frontend already handles as "no value". A missing number renders as "—".
# An outage renders as nothing at all.
class SafeJSONResponse(JSONResponse):
    """JSONResponse that renders NaN/Infinity as null instead of 500ing."""

    @staticmethod
    def _clean(v):
        if isinstance(v, float):
            # NaN != NaN, and inf comparisons are cheap. math.isfinite covers both.
            return v if math.isfinite(v) else None
        if isinstance(v, dict):
            return {k: SafeJSONResponse._clean(x) for k, x in v.items()}
        if isinstance(v, (list, tuple)):
            return [SafeJSONResponse._clean(x) for x in v]
        return v

    def render(self, content) -> bytes:
        return json.dumps(
            self._clean(jsonable_encoder(content)),
            ensure_ascii=False, allow_nan=False, separators=(",", ":"),
        ).encode("utf-8")


def _spreadsheet_safe_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Quote formula-shaped user data before it becomes an XLSX export."""
    out = df.copy()
    for col in out.columns:
        if out[col].dtype == object:
            out[col] = out[col].map(
                lambda v: "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v)
    return out


app = FastAPI(title="Cafe_X Intelligence Platform",
              default_response_class=SafeJSONResponse)

# Optional, and the app is fully instrumented without it — the on-disk error log
# in backend/core/errors.py needs no account and no configuration.
errors.init_sentry()

# ---------------------------------------------------------------------------
# Wire-level performance.
#
# The app shipped 404 KB of uncompressed JavaScript and CSS on every single
# load. On a phone on a shop's 4G that is several seconds of blank screen
# before anything renders, and it is the actual reason the app felt slow — the
# API itself answers in single-digit milliseconds.
#
# gzip takes that 404 KB to about 103 KB. Nothing else in this file will ever
# buy a 4x improvement for one line.
# ---------------------------------------------------------------------------
app.add_middleware(GZipMiddleware, minimum_size=800, compresslevel=6)


# ---------------------------------------------------------------------------
# Who may call this API from a browser, and how fast anyone may call it
# ---------------------------------------------------------------------------
# CORS. This app is same-origin: the pages, the seller storefronts and the API
# are all served by this process, so nothing legitimate needs a cross-origin
# XHR and the correct policy is the closed one. It is set explicitly rather
# than left unset because "no CORSMiddleware" and "CORS denied" look identical
# until somebody adds a middleware with allow_origins=["*"] to fix a console
# error, which is exactly the accident this makes visible.
#
# ALLOWED_ORIGINS exists for the real exception: a separate front end, or a
# staging domain, on a deployment that has one. Comma separated, exact origins
# only. A seller's custom domain does NOT belong here and does not need to:
# their shop is rendered by this app on their own host, so those requests are
# same-origin already.
def _allowed_origins() -> list[str]:
    raw = (os.getenv("ALLOWED_ORIGINS") or "").strip()
    out = [o.strip().rstrip("/") for o in raw.split(",") if o.strip()]
    base = publicurl.configured()
    if base and base not in out:
        out.append(base)
    return out


_ORIGINS = _allowed_origins()
if _ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Session-Id",
                       "X-Admin-Token"],
        max_age=600,
    )


# How big a request body this process will accept, by path. The video upload
# streams to disk a megabyte at a time and caps itself, so it gets the room it
# needs; everything else is a form or a spreadsheet.
_BODY_CAP_DEFAULT = 16 * 1024 * 1024
_BODY_CAPS = {"/api/site/image": (int(os.environ.get("MAX_VIDEO_UPLOAD_MB", "24") or 24) + 8) * 1024 * 1024}


def _body_cap(path: str) -> int:
    for prefix, cap in _BODY_CAPS.items():
        if path.startswith(prefix):
            return cap
    return _BODY_CAP_DEFAULT


@app.middleware("http")
async def _body_size(request: Request, call_next):
    """Refuse an oversized body before anything reads it.

    THE HOLE THIS CLOSES: several endpoints do `content = await f.read()` on an
    uploaded file with no ceiling at all — the complaint and positioning PDF
    routes among them. On a 512MB instance one POST of a large enough file is
    the whole box, and it needs no account and no cleverness. The upload paths
    that stream (site/image) cap themselves as they go; this is the floor under
    every other one, including any added later that forgets to.

    Content-Length is what a browser and every HTTP client sends on an upload.
    A chunked request has none, and nothing is guessed from its absence: those
    are bounded by whatever the endpoint itself does, which is why the read-it-
    all endpoints are the ones that matter and why this sits in front of them.
    """
    raw = request.headers.get("content-length")
    if raw and raw.isdigit():
        cap = _body_cap(request.url.path)
        if int(raw) > cap:
            return JSONResponse(
                status_code=413,
                content={"detail": f"That file is too large. The limit is "
                                   f"{cap // (1024 * 1024)}MB."})
    return await call_next(request)


@app.middleware("http")
async def _rate_limit(request: Request, call_next):
    """A ceiling on requests per caller per minute.

    Only /api/ is limited. The HTML, the CSS and the images are cheap, cached
    at the edge, and a person reloading a page hard is not an attack; putting a
    counter in front of them only risks breaking a real seller.

    The preflight is never limited either: answering OPTIONS with a 429 makes
    the browser report a CORS failure instead of a rate limit, which sends
    whoever is debugging it to entirely the wrong place.
    """
    path = request.url.path
    if request.method == "OPTIONS" or not path.startswith("/api/"):
        return await call_next(request)
    caller = loginguard.client_ip(request) or "?"
    ok, retry = ratelimit.check(caller, path, request.method)
    if not ok:
        return JSONResponse(
            status_code=429,
            headers={"Retry-After": str(retry)},
            content={"detail": "That is a lot of requests at once. Wait about "
                               "a minute and try again."},
        )
    return await call_next(request)


@app.get("/healthz")
def healthz():
    """Liveness, for the platform rather than for a person.

    Deliberately NOT /api/admin/health: that one needs the admin token and
    checks whether Supabase and the storage bucket are really wired up, which
    is the right answer to "is this deployment sound" and the wrong answer to
    "is this process alive". A health check that fails because a third party is
    slow will have the platform kill and restart a process that was serving
    every request correctly.

    Render uses this to hold a new deploy until it answers, so the old instance
    keeps taking traffic until the new one is up, and a release that cannot
    start never replaces a release that runs.
    """
    return {"ok": True, "service": "one-tap-manager"}



log = logging.getLogger("onetap")


# ---------------------------------------------------------------------------
# One account read per request, not fifty
# ---------------------------------------------------------------------------
# In Supabase mode every user_store.load_state() is an HTTPS round trip. The
# modules each read a few keys and none of them knew what the others were
# doing, so one home screen made roughly 48 of them: ~2.5s of pure waiting on
# a good connection, and a visible failure whenever one of them timed out.
#
# The window has to be the request. Anything longer needs a TTL and can serve
# one Render instance's stale copy to another; anything shorter does not help.
# ---------------------------------------------------------------------------
@app.middleware("http")
async def _state_scope(request, call_next):
    # The weekly social auto-planner's ticker starts with the first request
    # rather than at import, so importing the app (tests, scripts) never
    # spawns a thread. It is one flag check after that.
    autoplan.ensure_scheduler()
    with user_store.request_scope():
        return await call_next(request)


# ---------------------------------------------------------------------------
# An error the seller can read
# ---------------------------------------------------------------------------
# An unhandled exception used to leave FastAPI to return the string
# "Internal Server Error" as text/plain. The frontend parses JSON, got nothing,
# and fell back to response.statusText - which is ALWAYS empty over HTTP/2,
# which is what Render serves. The seller saw an empty bordered box and no
# clue what had happened.
#
# So: always JSON, always a sentence, and the traceback goes to the Render log
# with the path attached so the cause is findable.
# ---------------------------------------------------------------------------
# It also, now, tells SOMEBODY. Before this, a 500 on the live server produced a
# traceback in a Render log nobody reads and no notification anywhere — the
# seller closed the tab and the only evidence was a signup that went quiet. See
# backend/core/errors.py for the three layers and why the on-disk one is always
# on rather than depending on a Sentry account existing.
@app.exception_handler(Exception)
async def _unhandled(request: Request, exc: Exception):
    log.exception("unhandled error on %s %s", request.method, request.url.path)
    ref, spot = "", ""
    try:
        who = optional_user(request.headers.get("authorization")) or ""
    except Exception:  # noqa: BLE001
        who = ""
    try:
        entry = errors.record(exc, where=f"{request.method} {request.url.path}",
                              email=who) or {}
        ref, spot = entry.get("fingerprint", ""), entry.get("location", "")
    except Exception:  # noqa: BLE001 — reporting must not break the response
        ref = ""
    # The type and line go in the message too. It names no data — only where
    # the code broke — and it turns "send us a screenshot" into a fix, where a
    # bare reference needed someone with the admin token to look it up.
    tag = " · ".join(x for x in (ref, spot) if x)
    return JSONResponse(
        status_code=500,
        content={"detail": "Something went wrong on our side. Try that again in a "
                           "moment — and it has been reported, so we will see it "
                           "even if you do not tell us."
                           + (f" (reference {tag})" if tag else ""),
                 "reference": ref, "location": spot},
    )





@app.middleware("http")
async def _cache_policy(request, call_next):
    """Two rules, and the distinction between them is load-bearing.

    **The HTML shell is never cached.** An old index.html pins a seller to an
    old bundle forever, which is the classic way to ship a bug you cannot fix
    remotely. This is what the original blanket no-store rule was protecting
    against, and it stays.

    **A VERSIONED asset is cached for a year.** `smart.js?v=30` is immutable —
    bumping to v=31 is a different URL, so the browser re-fetches on its own.
    Blanket no-store meant re-downloading 404 KB of JavaScript on every single
    page load, which on a phone in a shop is several seconds of blank screen.
    That was the real reason the app felt slow; the API answers in single-digit
    milliseconds.

    The `v=` check is what makes this safe: an unversioned request for the same
    file still gets no-store, so nothing can be pinned by accident."""
    resp = await call_next(request)
    path = request.url.path
    versioned = bool(request.query_params.get("v"))
    is_asset = path.endswith((".js", ".css", ".woff2", ".woff", ".svg"))

    if is_asset and versioned:
        resp.headers["Cache-Control"] = "public, max-age=31536000, immutable"
        # MutableHeaders has no .pop(); del is the supported removal.
        for h in ("pragma", "expires"):
            if h in resp.headers:
                del resp.headers[h]
    elif (path.startswith("/smart") or path.startswith("/static") or path == "/app"
            or path.startswith("/s/") or path.startswith("/store-static")
            or path.endswith((".js", ".css", ".html"))):
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
    return resp


def _seed_data_dir():
    """On a fresh persistent disk (first deploy), copy the starter user.csv over
    so login works immediately. Never overwrites an existing file — real
    signups on the disk are always left alone."""
    import shutil
    if db.SUPABASE_ENABLED:
        return  # accounts live in Supabase; nothing to seed on disk
    target_dir = auth.BASE_DIR
    os.makedirs(target_dir, exist_ok=True)
    target_users = os.path.join(target_dir, "user.csv")
    seed_users = os.path.join(os.path.dirname(__file__), "..", "data", "user.csv")
    if not os.path.exists(target_users) and os.path.exists(seed_users):
        shutil.copy(seed_users, target_users)

_seed_data_dir()

STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")

# ---------------------------------------------------------
# Per-browser data store (replaces st.session_state's raw_dfs / txns_df)
# ---------------------------------------------------------
class SessionData:
    def __init__(self):
        # Anonymous uploads can be explored before login. Once a seller uses
        # the session while authenticated it is permanently bound to that
        # account, so a leaked browser session id is not enough to read or use
        # another seller's private analysis.
        self.owner: str | None = None
        self.raw_dfs: dict[str, pd.DataFrame] = {}
        self.file_names: dict[str, str] = {}
        self.txns_df: pd.DataFrame | None = None
        self.mapped_file_id: str | None = None
        self.chat_messages: list[dict] = []
        self.used_initial_prompt = False

_data_sessions: dict[str, SessionData] = {}


def get_session(session_id: str | None) -> SessionData:
    if not session_id:
        raise HTTPException(400, "Missing X-Session-Id header")
    if session_id not in _data_sessions:
        _data_sessions[session_id] = SessionData()
    return _data_sessions[session_id]


def bind_session(sess: SessionData, email: str | None) -> SessionData:
    email = (email or "").strip().lower()
    if not email:
        return sess
    if sess.owner and sess.owner != email:
        raise HTTPException(403, "This browser session belongs to another account. Start a new session and try again.")
    sess.owner = email
    return sess


def require_user(authorization: str | None) -> str:
    token = (authorization or "").removeprefix("Bearer ").strip()
    email = auth.user_from_token(token)
    if not email:
        raise HTTPException(401, "Login required")
    return email


def optional_user(authorization: str | None) -> str | None:
    """Email if a valid token is present, else None (never raises)."""
    token = (authorization or "").removeprefix("Bearer ").strip()
    return auth.user_from_token(token) if token else None


# ---------------------------------------------------------
# Schemas
# ---------------------------------------------------------
class LoginBody(BaseModel):
    email: str
    password: str

class RegisterBody(BaseModel):
    email: str
    password: str
    plan: str = "free"
    # What the signup form says the person ticked, and when. Article 7(1) of the
    # GDPR and the DPDP Act both come down to being able to DEMONSTRATE consent
    # rather than assert it, and "they must have clicked something" is not a
    # record. Stored as given, so what was agreed to and when is answerable
    # later. Marketing is a separate field on purpose: bundling it into the same
    # tick would make the consent to the terms worthless, which is exactly the
    # pattern Rule 4(9) of the E-commerce Rules and the 2023 Dark Patterns
    # Guidelines are about.
    consent: dict | None = None
    marketing_opt_in: bool = False

class ForgotBody(BaseModel):
    email: str


class ResetBody(BaseModel):
    email: str
    token: str
    password: str


class DigestBody(BaseModel):
    enabled: bool | None = None
    email: str | None = None
    phone: str | None = None
    hour: int | None = None


class WinbackSentBody(BaseModel):
    customers: list[dict] = []
    channel: str | None = "whatsapp"
    note: str | None = ""


class WinbackUnsentBody(BaseModel):
    campaign_id: str


class StoreGatewayBody(BaseModel):
    key_id: str
    key_secret: str


class ShopPayBody(BaseModel):
    lines: list[dict] = []
    payment: str = "cod"


class SupplierBody(BaseModel):
    name: str
    patch: dict = {}


class CampaignBody(BaseModel):
    rows: list[dict] = []
    template: str | None = ""
    subject: str | None = ""
    channels: list[str] = ["email", "whatsapp"]


class BrandBody(BaseModel):
    patch: dict = {}


class MaterialBody(BaseModel):
    product_id: str
    patch: dict = {}


class StudioPostBody(BaseModel):
    product_id: str
    angle: str | None = ""
    generate_image: bool = False



# --- GST / invoicing -----------------------------------------------------
class GstSettingsBody(BaseModel):
    patch: dict = {}


class IssueInvoiceBody(BaseModel):
    order_id: str
    force: bool = False


class CancelInvoiceBody(BaseModel):
    invoice_id: str
    reason: str | None = ""


# --- labels --------------------------------------------------------------
class LabelBody(BaseModel):
    order_ids: list[str] = []


# --- cancellation requests ----------------------------------------------
class CancelRequestBody(BaseModel):
    order_id: str
    reason_code: str
    reason_text: str | None = ""


class ResolveCancelBody(BaseModel):
    request_id: str
    decision: str
    note: str | None = ""


class PoCancelRequestBody(BaseModel):
    po_number: str
    reason_code: str
    reason_text: str | None = ""


# --- purchase orders -----------------------------------------------------
class ManualPoBody(BaseModel):
    supplier: dict = {}
    lines: list[dict] = []
    expected_on: str | None = ""
    terms: str | None = ""
    note: str | None = ""
    # The form's "Create & send" button asks for this explicitly. It defaults
    # to off so that nothing else — an older client, a script — can put mail
    # in front of a supplier by accident.
    send: bool = False


class PoStatusBody(BaseModel):
    po_number: str
    status: str
    note: str | None = ""


# --- social media manager ------------------------------------------------
class SocialSettingsBody(BaseModel):
    patch: dict = {}


class SocialWeekBody(BaseModel):
    regenerate: bool = False
    weeks: int = 1


class SocialPostBody(BaseModel):
    post_id: str
    patch: dict = {}


class SocialStateBody(BaseModel):
    post_id: str
    state: str


class SocialCloneBody(BaseModel):
    post_id: str


class FestivalCampaignBody(BaseModel):
    festival: str



# --- Product Studio: design language + generation ------------------------
class StudioRefBody(BaseModel):
    url: str


class StudioReadShotsBody(BaseModel):
    product_id: str


class StudioImageOnlyBody(BaseModel):
    product_id: str
    pillar: str | None = ""
    format: str | None = ""
    angle: str | None = ""
    post_id: str | None = ""
    use_reference: bool = True
    strength: float | None = None
    # Which archetype of photograph this beat wants (studio.SHOT_TYPES). Sent
    # by the editor; also resolved from the post when a post_id is given.
    shot_type: str | None = ""
    # Which AI the seller picked for THIS generation. Empty means "use the
    # default"; a named engine that is not usable is an error, never a silent
    # substitution onto a different vendor at a different price.
    engine: str | None = ""


class SocialAttachBody(BaseModel):
    post_id: str
    url: str
    # Kept for older clients. It used to mean "run the watermark remover", which
    # is now switched off by law (see backend/core/ailabel.py), so it no longer
    # changes a pixel and the report says why.
    clean: bool = True
    # The seller's own declaration: was this clip made by an AI tool? True for
    # anything that came out of Google Flow, Kling or Veo, which is most reels,
    # because that is where our own shot-list sends them. False for a clip filmed
    # on a phone. It decides whether we stamp the AI label on it, and both
    # answers matter: labelling real footage as AI is as much a lie as leaving
    # generated footage unlabelled, so we ask rather than guess.
    ai_generated: bool | None = None


class MappingBody(BaseModel):
    file_id: str
    mapping: dict

class ChatBody(BaseModel):
    message: str


# ---------------------------------------------------------
# Auth
# ---------------------------------------------------------
@app.post("/api/login")
def login(body: LoginBody, request: Request):
    """Sync on purpose: verifying a password is ~0.4s of CPU (PBKDF2 at the
    OWASP cost) and Starlette runs a `def` handler in a threadpool. As
    `async def` that work would sit on the event loop and stall every other
    request on the instance for the duration of each login."""
    if not auth.load_users():
        raise HTTPException(401, "No user accounts found. Create user.csv (columns: email,password) in the data/ folder or project root.")
    ip = loginguard.client_ip(request)
    allowed, wait = loginguard.check(body.email, ip)
    if not allowed:
        # The same words as a wrong password. Telling an attacker they have
        # tripped a limit tells them the address is worth attacking.
        raise HTTPException(401, "Invalid credentials")
    if wait:
        time.sleep(min(wait, 8.0))
    token = auth.login(body.email, body.password)
    if not token:
        loginguard.failed(body.email, ip)
        raise HTTPException(401, "Invalid credentials")
    loginguard.succeeded(body.email, ip)
    email = body.email.strip().lower()
    return {"token": token, "email": email, "usage": _usage(email), "plan": billing.get_plan(email)}


@app.post("/api/register")
def register(body: RegisterBody):
    """Signup from the landing page. Free during launch, no card.

    The consent the form collected is written to its own append-only record
    BEFORE the account is reported back, so there is never an account whose
    agreement to the terms cannot be evidenced. See legal.record_consent for why
    a text file rather than a column: a regulator's question should be answerable
    without this application running.
    """
    try:
        auth.register(body.email, body.password, body.plan)
    except ValueError as e:
        raise HTTPException(400, str(e))
    token = auth.login(body.email, body.password)
    email = body.email.strip().lower()
    # The setup journey's record is made here, at sign-up, so "new account"
    # means signed up after the journey shipped, not "has no data yet".
    try:
        onboarding.create_for_new_account(email)
    except Exception:  # noqa: BLE001 - a signup must never fail on this
        pass
    consent = body.consent or {}
    consent_rec = legal.record_consent(
        email,
        terms=bool(consent.get("terms", True)),
        privacy=bool(consent.get("privacy", True)),
        marketing=bool(body.marketing_opt_in),
        source="signup")
    return {"token": token, "email": email, "usage": _usage(email),
            "plan": billing.get_plan(email),
            "consent_recorded": bool(consent_rec.get("stored"))}


class GoogleBody(BaseModel):
    credential: str
    nonce: str = ""
    password: str = ""      # only when linking to an existing password account


@app.get("/api/auth/providers")
def auth_providers():
    """What the sign-in screen may offer. The client id is public by design —
    it is in the page source of every site that uses Google sign-in."""
    return {"google": {"enabled": google_auth.configured(),
                       "client_id": google_auth.client_id()}}


@app.post("/api/auth/google")
def auth_google(body: GoogleBody, request: Request):
    """Sign in, or sign up, with a verified Google identity.

    The three outcomes, and why the third exists:
      * this Google account is already linked here     -> straight in;
      * no account with this address                   -> create one and link;
      * an account exists that was made with a PASSWORD and has never been
        linked -> ask for that password once. Linking on a matching address
        alone is how accounts get stolen: anyone can type any address into a
        signup form, so a local row is not proof of owning the mailbox.
    """
    ip = loginguard.client_ip(request)
    allowed, wait = loginguard.check(body.credential[:40] or "google", ip)
    if not allowed:
        raise HTTPException(429, "Too many attempts. Try again in a few minutes.")
    try:
        claims = google_auth.verify(body.credential, body.nonce)
    except ValueError as e:
        loginguard.failed(body.credential[:40] or "google", ip)
        raise HTTPException(401, str(e))

    email = claims["email"]
    users = auth.load_users()
    existing = users.get(email)
    linked = (google_auth.identity(email) or {}).get("sub")

    if existing is not None and not linked:
        # The account is real and was made with a password. One of two things
        # is true and we cannot tell which: this is the same person, or someone
        # registered their address first. The password settles it.
        if not body.password:
            raise HTTPException(409, "An account already uses this email. "
                                     "Enter its password once to connect Google to it.")
        if not auth.verify_password(body.password.strip(), existing):
            loginguard.failed(email, ip)
            raise HTTPException(401, "That password does not match the existing account.")

    if existing is None:
        # No password is ever set for a Google-only account. A random one is
        # stored so the row has the same shape as every other, and it is not
        # written down anywhere — the seller uses "Forgot password" if they
        # later want to sign in without Google.
        auth.register(email, secrets.token_urlsafe(24), "free")
        try:
            onboarding.create_for_new_account(email)
        except Exception:  # noqa: BLE001 - a signup must never fail on this
            pass

    google_auth.remember(email, claims)
    loginguard.succeeded(email, ip)
    token = auth.start_session(email)
    return {"token": token, "email": email, "usage": _usage(email),
            "plan": billing.get_plan(email), "new_account": existing is None}


@app.post("/api/forgot")
def forgot_password(body: ForgotBody, request: Request):
    """Always answers the same way, whether or not the address has an account —
    telling an attacker which emails exist is not a feature."""
    return password_reset.request_seller(body.email, _public_base_url(request))


@app.post("/api/admin/reset-link")
def admin_reset_link(body: ForgotBody, request: Request,
                     x_admin_token: str | None = Header(default=None)):
    """Support's recovery path for a locked-out seller while email is not set up.

    Gated on ADMIN_TOKEN, which must be set in the environment — with no token
    configured this endpoint refuses everyone rather than defaulting open.
    """
    _require_admin(x_admin_token)
    try:
        return password_reset.admin_reset_link(body.email, _public_base_url(request))
    except password_reset.ResetError as e:
        raise HTTPException(404, str(e))


@app.exception_handler(aicaps.CapReached)
async def _cap_reached(request: Request, exc: aicaps.CapReached):
    """429, and worded as a ceiling rather than a paywall.

    The seller has done nothing wrong: they have used a lot of an expensive thing
    and it resets. Routing this through one handler means every generation
    endpoint says the same thing in the same words, and none of them can
    accidentally turn it into a 500.

    The monthly picture allowance carries a different `code` so the browser can
    respond differently: the daily cap says "come back tomorrow", the monthly one
    sends the seller to upload their own photo (and the routes above have already
    put the shot on their task list).
    """
    monthly = isinstance(exc, aicaps.MonthlyImageCapReached)
    return JSONResponse(status_code=429,
                        content={"detail": str(exc),
                                 "code": "monthly_image_cap" if monthly else "daily_cap"})


def _require_admin(x_admin_token: str | None) -> None:
    """Shared gate for the operator-only endpoints.

    Refuses everyone when ADMIN_TOKEN is unset rather than defaulting open, and
    compares in constant time so the token cannot be guessed a character at a
    time from response timings.
    """
    want = (os.environ.get("ADMIN_TOKEN") or "").strip()
    if not want:
        raise HTTPException(503, "Admin endpoints are not enabled on this server. "
                                 "Set ADMIN_TOKEN to turn them on.")
    if not secrets.compare_digest((x_admin_token or "").strip(), want):
        raise HTTPException(403, "Not allowed.")


@app.get("/api/admin/errors")
def admin_errors(limit: int = 50, detail: bool = False,
                 x_admin_token: str | None = Header(default=None),
                 token: str | None = None):
    """Every failure the app has hit, newest first, grouped by cause.

    This is the answer to "how would I know?". `detail=true` returns the raw
    entries with tracebacks; the default returns groups, which is what you
    actually want to look at — fifty occurrences of one bug is one line, not
    fifty.

    `?token=` works as well as the header: this is the endpoint you reach for
    when something is broken, and at that moment the fastest thing anyone has
    is a browser tab. It is a read, and the token is the same either way.
    """
    _require_admin(x_admin_token or token)
    if detail:
        return {"errors": errors.recent(limit)}
    return errors.summary(limit)


@app.post("/api/admin/errors/clear")
def admin_errors_clear(x_admin_token: str | None = Header(default=None)):
    _require_admin(x_admin_token)
    return {"cleared": errors.clear()}


@app.get("/api/admin/health")
def admin_health(x_admin_token: str | None = Header(default=None)):
    """Is this deployment actually wired up, or quietly running on fallbacks?

    A deploy that is missing a Supabase table or a storage bucket does not fail
    loudly — it falls back to local files, works perfectly in testing, and then
    loses everything on the next redeploy because Render rebuilds the disk. That
    class of problem has bitten this app twice. This endpoint makes it visible in
    one request instead of being discovered a week later.
    """
    _require_admin(x_admin_token)
    return health.report()


@app.post("/api/reset")
def reset_password(body: ResetBody):
    try:
        return password_reset.reset_seller(body.email, body.token, body.password)
    except password_reset.ResetError as e:
        raise HTTPException(400, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/api/today")
def today_strip(authorization: str | None = Header(default=None)):
    """The three things worth the seller's time. Same rows the digest sends."""
    email = require_user(authorization)
    items = today_mod.build(email, limit=4)
    return {"items": items,
            "empty": today_mod.empty_state(email) if not items else None,
            "digest": today_mod.get_prefs(email)}


@app.post("/api/digest")
def digest_settings(body: DigestBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    patch = {k: v for k, v in body.dict().items() if v is not None}
    return {"digest": today_mod.set_prefs(email, patch),
            "email_ready": messaging.smtp_configured(),
            "whatsapp_ready": messaging.whatsapp_enabled()}


@app.post("/api/digest/test")
def digest_test(authorization: str | None = Header(default=None)):
    """Send one now, so a seller can see the digest before trusting it."""
    return today_mod.send_digest(require_user(authorization), force=True)


@app.post("/api/digest/run")
def digest_run(hour: int | None = None,
               x_admin_token: str | None = Header(default=None)):
    """Cron target: send every seller whose digest hour is now.

    This is an operator job, not a public endpoint: otherwise anyone on the
    internet can cause a batch of seller emails to be sent.
    """
    _require_admin(x_admin_token)
    return today_mod.run_due(hour)


@app.get("/api/dev/outbox")
def dev_outbox(x_admin_token: str | None = Header(default=None)):
    """What we tried to send but had nowhere to send it — visible only while
    SMTP is unconfigured, so a first deploy can still test password reset."""
    _require_admin(x_admin_token)
    if messaging.smtp_configured():
        raise HTTPException(404, "Not available once SMTP is configured.")
    return {"outbox": messaging.outbox()}


@app.post("/api/logout")
def logout(authorization: str | None = Header(default=None)):
    auth.logout((authorization or "").removeprefix("Bearer ").strip())
    return {"ok": True}


def _usage(email: str) -> dict:
    return {
        "chatbot": auth.get_remaining_usage(email, "chatbot"),
        "analyst_ai": auth.get_remaining_usage(email, "analyst_ai"),
        "ai_credits": billing.credit_balance(email, "ai_topup"),
        "winback_credits": billing.credit_balance(email, "winback_campaign"),
        "positioning_credits": billing.credit_balance(email, "positioning_report"),
        "plan": billing.get_plan(email),
        "launch_mode": pricing.launch_mode(),
    }


def _paywall(product_id: str, message: str = "") -> HTTPException:
    """402 with a structured detail the frontend recognises to open the pricing
    modal. The body names BOTH ways past it — the tier that includes this, and
    what it costs in credits — because a seller who works in bursts should not
    be told a monthly subscription is their only option."""
    detail = billing.paywall(product_id)
    if message:
        detail["message"] = message
    return HTTPException(status_code=402, detail=detail)


@app.post("/api/cache/clear")
def cache_clear(authorization: str | None = Header(default=None)):
    """What the Refresh button on every page calls first.

    Without this, Refresh would re-read the same cached computations and the
    seller would be told their data is "up to date" when nothing had been
    recomputed. Scoped to the caller's own account.
    """
    email = require_user(authorization)
    return {"cleared": cache.clear(email)}


# ---------------------------------------------------------
# Product Studio
# ---------------------------------------------------------
@app.get("/api/studio/state")
def studio_state(authorization: str | None = Header(default=None)):
    """The brand profile plus every product with how much material it has.

    The completeness score is not decoration: it decides which product is worth
    posting about next, and names the one missing piece that would help most.
    """
    email = require_user(authorization)
    brand = studio.get_brand(email)
    rows = []
    for p in products.get_products(email):
        mat = studio.get_material(email, p["id"])
        rows.append({
            "id": p["id"], "name": p["name"], "category": p.get("category") or "",
            "price": p.get("price"), "image_url": p.get("image_url") or "",
            "material": mat,
            "completeness": studio.completeness(p, mat),
        })
    rows.sort(key=lambda r: r["completeness"]["score"], reverse=True)
    return {
        "brand": brand,
        "brand_ready": studio.brand_ready(brand),
        "looks": studio.LOOKS,
        "voices": studio.VOICES,
        "products": rows,
        "ai_ready": studio.openai_ready(),
        "media_durable": media.durable(),
    }


@app.post("/api/studio/brand")
def studio_brand(body: BrandBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    return {"brand": studio.save_brand(email, body.patch or {})}


@app.get("/api/studio/product")
def studio_product(product_id: str, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    p = next((x for x in products.get_products(email) if x["id"] == product_id), None)
    if not p:
        raise HTTPException(404, "That product no longer exists.")
    mat = studio.get_material(email, product_id)
    return {"product": p, "material": mat,
            "completeness": studio.completeness(p, mat),
            "angles": studio.angles(p, mat)}


@app.post("/api/studio/product")
def studio_product_save(body: MaterialBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    mat = studio.save_material(email, body.product_id, body.patch or {})
    p = next((x for x in products.get_products(email) if x["id"] == body.product_id), {})
    return {"material": mat, "completeness": studio.completeness(p, mat),
            "angles": studio.angles(p, mat)}


@app.post("/api/studio/post")
def studio_post(body: StudioPostBody, authorization: str | None = Header(default=None)):
    """One ready-to-post draft, generated against the brand profile."""
    email = require_user(authorization)
    try:
        return studio.make_post(email, body.product_id, body.angle or "",
                                bool(body.generate_image))
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(503, str(e))


@app.get("/api/icons")
def icon_set():
    """The one stroke icon set, shared by the app and every storefront it
    publishes. The app used to draw its modules with emoji while the sites it
    produced used these — which is why the published site looked like software
    and the app looked like a prototype."""
    return {"icons": sitebuilder.ICONS}


@app.get("/api/pricing")
def get_pricing():
    """Public catalog + launch-mode flag — drives both landing page and in-app pricing UI."""
    return pricing.public_catalog()


@app.get("/api/connectors")
def list_connectors():
    """POS connectors available, plus which file exports we auto-recognise."""
    return {"connectors": connectors.available(),
            "supported_exports": pos_formats.describe_supported()}


@app.post("/api/intake/email")
async def intake_email(request: Request):
    """Inbound-email webhook — SendGrid Inbound Parse / Mailgun Routes both
    POST multipart/form-data with roughly this shape (field names differ
    slightly between providers; both send 'from'/'sender' + attachmentN
    files, which is what we read here). This is where a café's POS-scheduled
    report lands once its recipient is set to our address — zero upload,
    zero login, the owner never touches this product's UI at all.
    """
    form = await request.form()
    sender = str(form.get("from") or form.get("sender") or "")
    attachments = []
    for key, value in form.multi_items():
        if hasattr(value, "filename") and value.filename:
            attachments.append((value.filename, await value.read()))
    if not attachments:
        raise HTTPException(400, "No attachments found in the inbound email.")
    try:
        result = email_intake.process_inbound_email(sender, attachments)
    except email_intake.IntakeError as e:
        raise HTTPException(422, str(e))
    report_url = f"/api/intake/report/{result['token']}"
    email_intake.send_report_email(sender, result["token"], report_url)
    return {**result, "report_url": report_url}


@app.get("/api/intake/report/{token}")
def intake_report(token: str):
    """Magic link: the café owner (or whoever the report was emailed to)
    opens this to view/download their processed PDF — no account needed."""
    pdf_bytes = email_intake.get_report(token)
    if not pdf_bytes:
        raise HTTPException(404, "This report link has expired or doesn't exist.")
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": 'inline; filename="cafex_sales_report.pdf"'})


class PullBody(BaseModel):
    connector: str
    credentials: dict = {}
    days: int = 90


@app.post("/api/connectors/pull")
def connector_pull(body: PullBody, x_session_id: str | None = Header(default=None),
                   authorization: str | None = Header(default=None)):
    """Pull orders from a POS into this session, exactly as if a file had been
    uploaded — the data lands in the same place, so every existing feature
    (analytics, RFM, menu engineering) works on it unchanged."""
    from datetime import date, timedelta
    sess = get_session(x_session_id)
    end = date.today()
    start = end - timedelta(days=max(1, min(body.days, 730)))
    try:
        df = connectors.pull(body.connector, body.credentials, start, end)
    except connectors.ConnectorError as e:
        raise HTTPException(400, str(e))
    fid = "pos_" + body.connector
    sess.raw_dfs[fid] = df
    sess.file_names[fid] = f"🔌 {body.connector} ({start} → {end})"
    # already canonical, so map it straight through — no mapping step for the user
    sess.txns_df, _ = mapper.build_transactions(df, {c: c for c in df.columns})
    # SHARED DATA: persist to the account so Smart mode sees it too.
    email = optional_user(authorization)
    if email:
        smart.save_sales(email, sess.txns_df, {"files": sess.file_names[fid]})
        replenish.after_sales(email, "sales upload")
    return {"file": _file_info(fid, sess), "rows": int(len(df)),
            "from": start.isoformat(), "to": end.isoformat(), "mapped": True}


@app.get("/api/report/pdf")
def download_report(lang: str = "en", x_session_id: str | None = Header(default=None),
                    authorization: str | None = Header(default=None)):
    """Proper PDF report of the dashboard: prescriptive actions first, KPIs,
    forecast, charts — disclaimer on every page."""
    sess = get_session(x_session_id)
    txns = _require_txns(sess, authorization)
    data = analytics.sales_analytics(txns)
    rendered = i18n.render_all(data["insights"], lang)
    try:
        pdf_bytes = report_pdf.build_sales_report(data, rendered)
    except ImportError:
        raise HTTPException(503, "PDF engine not installed on the server, run: pip install reportlab matplotlib")
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": 'attachment; filename="cafex_sales_report.pdf"'})


@app.post("/api/complaints/pdf")
async def complaints_pdf(product_type: str | None = None,
                         files: list[UploadFile] = File(...),
                         x_session_id: str | None = Header(default=None),
                         authorization: str | None = Header(default=None)):
    """PDF of the Complaint Trends page — Focus Framework, monthly volume, table."""
    pt = _resolve_product_type(authorization, product_type)
    f = files[0]
    content = await f.read()
    try:
        parsed = _read_any_table(f.filename or "reviews", content)
        if not parsed:
            raise ValueError("Could not read the file.")
        data = complaints.analyze_complaints(parsed[0][1], product_type=pt)
        pdf_bytes = report_pdf.build_complaints_report(data)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except ImportError:
        raise HTTPException(503, "PDF engine not installed, run: pip install reportlab matplotlib")
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": 'attachment; filename="cafex_complaint_report.pdf"'})


@app.post("/api/positioning/pdf")
async def positioning_pdf(lang: str = "en", product_type: str | None = None,
                          files: list[UploadFile] = File(...),
                          x_session_id: str | None = Header(default=None),
                          authorization: str | None = Header(default=None)):
    """PDF of the Positioning page — actions first, theme share for your brand."""
    pt = _resolve_product_type(authorization, product_type)
    f = files[0]
    content = await f.read()
    try:
        parsed = _read_any_table(f.filename or "reviews", content)
        if not parsed:
            raise ValueError("Could not read the file.")
        data = positioning.analyze_reviews(parsed[0][1], lang, product_type=pt)
        if not data.get("available"):
            raise ValueError(data.get("reason", "Not enough data for a positioning report."))
        pdf_bytes = report_pdf.build_positioning_report(data)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except ImportError:
        raise HTTPException(503, "PDF engine not installed, run: pip install reportlab matplotlib")
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": 'attachment; filename="cafex_positioning_report.pdf"'})


@app.post("/api/complaints")
async def analyze_complaints_endpoint(product_type: str | None = None,
                                      files: list[UploadFile] = File(...),
                                      x_session_id: str | None = Header(default=None),
                                      authorization: str | None = Header(default=None)):
    """Complaint Trends Report: raw reviews in -> prescriptive fix-first
    actions, monthly complaint trends, severity quadrant, deep table.
    Free during launch and free forever after — part of the Free plan."""
    sess = get_session(x_session_id)
    if not pricing.launch_mode():
        email = require_user(authorization)
        if not billing.check_and_consume(email, "complaints"):
            raise _paywall("complaints")
    pt = _resolve_product_type(authorization, product_type)
    f = files[0]
    content = await f.read()
    try:
        parsed = _read_any_table(f.filename or "reviews", content)
        if not parsed:
            raise ValueError("Could not read the file, use CSV, Excel, TSV or JSON.")
        _, df = parsed[0]
        # SHARED DATA: save reviews to the account so Smart mode sees them too.
        email = optional_user(authorization)
        if email:
            smart.save_review(email, df, {})
        return complaints.analyze_complaints(df, product_type=pt)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/api/me")
def me(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {"email": email, "usage": _usage(email), "plan": billing.get_plan(email),
            "product_type": smart.get_product_type(email)}


# ---------------------------------------------------------
# Product type — what the seller sells (drives keyword tracking)
# ---------------------------------------------------------
# ---------------------------------------------------------
# Instagram (real Meta Graph API integration)
#
# Two connection paths:
#   1) OAuth via the platform's own Meta Business App  (recommended for end users)
#      — enabled when META_APP_ID + META_APP_SECRET are set as env vars.
#      The seller clicks "Connect Instagram" and never sees a token.
#   2) Manual paste  (fallback when env vars aren't set, or for dev/testing).
#      Same UI as before — an access token + IG user id form.
# ---------------------------------------------------------
class IGConnectBody(BaseModel):
    access_token: str
    ig_user_id: str


# Short-lived state → email map for the OAuth handshake. Kept in-memory
# because it lasts seconds; a restart during a user's login just makes them
# click Connect again.
_ig_oauth_state: dict[str, dict] = {}


def _ig_redirect_url(request: Request) -> str:
    """Where Meta should send the browser back to after login.
    Env var wins (so a Render app can pin a stable HTTPS URL); otherwise we
    derive it from the incoming request."""
    from os import environ as _env
    from_env = _env.get("META_REDIRECT_URL")
    if from_env:
        return from_env
    return f"{request.url.scheme}://{request.url.netloc}/api/instagram/oauth/callback"


@app.get("/api/instagram/status")
def instagram_status(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {**instagram.status(email), "oauth_available": instagram.oauth_configured()}


@app.get("/api/instagram/oauth/start")
def instagram_oauth_start(request: Request,
                          authorization: str | None = Header(default=None)):
    """Start the OAuth handshake. The frontend opens this in a popup; we
    reply with the Facebook login URL to redirect the popup to."""
    email = require_user(authorization)
    if not instagram.oauth_configured():
        raise HTTPException(400, "OAuth isn't configured on this server yet, the admin needs to set META_APP_ID and META_APP_SECRET.")
    state = secrets.token_urlsafe(16)
    _ig_oauth_state[state] = {"email": email,
                              "created_at": pd.Timestamp.now().isoformat()}
    # prune old states so this dict never grows unbounded
    _prune_states()
    redirect_url = _ig_redirect_url(request)
    return {"login_url": instagram.build_login_url(redirect_url, state),
            "redirect_url": redirect_url}


def _prune_states() -> None:
    cutoff = pd.Timestamp.now() - pd.Timedelta(minutes=15)
    for k in list(_ig_oauth_state.keys()):
        try:
            if pd.Timestamp(_ig_oauth_state[k]["created_at"]) < cutoff:
                _ig_oauth_state.pop(k, None)
        except Exception:
            _ig_oauth_state.pop(k, None)


@app.get("/api/instagram/oauth/callback")
def instagram_oauth_callback(request: Request, code: str | None = None,
                             state: str | None = None, error: str | None = None,
                             error_description: str | None = None):
    """Meta redirects the popup here after the seller approves. We exchange
    the code for a long-lived user token, find their IG Business account
    via the connected Facebook Page, save the Page access token + IG user id
    to their account, then close the popup with a postMessage the parent
    picks up to refresh the status card."""
    from fastapi.responses import HTMLResponse

    def _reply(ok: bool, message: str, username: str | None = None) -> HTMLResponse:
        # Post the result back to the parent (the Instagram module in Smart)
        # and self-close. `*` for targetOrigin is safe here because the popup
        # was opened by us and we don't send any secrets in the message.
        payload = {"ok": ok, "message": message, "username": username}
        html = f"""<!doctype html><meta charset='utf-8'><title>Instagram connect</title>
<style>body{{font:14px/1.5 Inter,system-ui,sans-serif;padding:40px;text-align:center;color:#111827}}
.ok{{color:#0a7a4d}}.err{{color:#c02626}}</style>
<h2 class='{'ok' if ok else 'err'}'>{'✅' if ok else '⚠️'} {message}</h2>
<p class='muted'>{('You can close this window.' if ok else 'You can close this window and try again.')}</p>
<script>
try {{ if (window.opener) {{ window.opener.postMessage({{type:'ig-oauth', payload:{json.dumps(payload)}}}, '*'); }} }} catch(e){{}}
setTimeout(function(){{ try{{window.close();}}catch(e){{}} }}, 900);
</script>"""
        return HTMLResponse(html)

    if error:
        return _reply(False, error_description or error)
    if not code or not state:
        return _reply(False, "Missing code or state from Instagram.")
    st = _ig_oauth_state.pop(state, None)
    if not st:
        return _reply(False, "This login attempt expired — please try again from the app.")
    email = st["email"]
    redirect_url = _ig_redirect_url(request)

    tok = instagram.exchange_code(code, redirect_url)
    if not tok.get("ok"):
        return _reply(False, tok.get("error", "Could not exchange the code with Instagram."))
    user_token = tok["access_token"]
    ig_user_id = tok.get("user_id")
    if not ig_user_id:
        return _reply(False, "Instagram didn't return an account id. Make sure the account is "
                             "switched to Business or Creator (Instagram app > Settings > "
                             "Account type and tools), then try again.")

    # Instagram Login's token response already tells us the account — no
    # Facebook Pages lookup needed. Just confirm it and grab the username.
    check = instagram.test_connection(user_token, ig_user_id)
    if not check.get("ok"):
        return _reply(False, check.get("error", "Could not verify the connected account."))
    instagram.save_credentials(email, user_token, ig_user_id,
                               account_username=check.get("username"),
                               granted=tok.get("granted"))
    return _reply(True, f"Connected @{check.get('username','—')}", username=check.get("username"))


# ---------------------------------------------------------
# Instagram Webhook — required by Meta's "Instagram" product setup even
# though this app doesn't act on realtime events yet. Meta needs:
#   1. A GET handshake to prove we own this URL (the "Verify Token" step).
#   2. A POST receiver for actual events (deauthorization, data-deletion
#      requests, comments, etc.) — we just log & acknowledge for now.
# The Verify Token is a secret string YOU choose (not given by Meta) — set
# it as the IG_WEBHOOK_VERIFY_TOKEN env var, then paste that exact string
# into Meta's "Verify token" field alongside this callback URL:
#   https://<your-domain>/api/instagram/webhook
# ---------------------------------------------------------
@app.get("/api/instagram/webhook")
def instagram_webhook_verify(request: Request):
    from fastapi.responses import PlainTextResponse
    mode = request.query_params.get("hub.mode")
    token = request.query_params.get("hub.verify_token")
    challenge = request.query_params.get("hub.challenge")
    expected = os.environ.get("IG_WEBHOOK_VERIFY_TOKEN", "")
    if mode == "subscribe" and expected and token == expected:
        return PlainTextResponse(challenge or "")
    raise HTTPException(403, "Verification token mismatch.")


def _meta_signature_ok(raw: bytes, header: str | None) -> bool:
    """Whether this body really came from Meta.

    Meta signs every webhook delivery with the app secret as
    X-Hub-Signature-256: sha256=<hex>. Unverified, this endpoint accepted a
    POST from anybody: today that only writes a log line, which is log
    flooding and log injection rather than a breach, but "nothing reacts to
    these events YET" is exactly the note that is still in the file on the day
    somebody adds the handler that does. The check belongs here now, while it
    is cheap, not in the change that starts trusting the payload.

    Compared in constant time, and False when no secret is configured, because
    a signature check that passes when it cannot check anything is worse than
    none: it reads as protection in every audit after this one.
    """
    secret = (os.environ.get("META_APP_SECRET") or "").strip()
    if not secret:
        return False
    sig = (header or "").strip()
    if not sig.startswith("sha256="):
        return False
    expected = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    return secrets.compare_digest(expected, sig[len("sha256="):])


@app.post("/api/instagram/webhook")
async def instagram_webhook_receive(request: Request):
    """Meta expects a fast 200 OK (within a few seconds) or it'll retry and
    eventually flag the webhook as unhealthy. We just log the payload for
    now — nothing in the product currently reacts to these events."""
    raw = await request.body()
    if not _meta_signature_ok(raw, request.headers.get("x-hub-signature-256")):
        # 403 and nothing else. Meta does not retry a 403, which is correct:
        # a delivery we cannot prove came from Meta is not one to ask for
        # again, and an attacker learns only that it was refused.
        raise HTTPException(403, "Bad signature.")
    try:
        body = json.loads(raw or b"{}")
    except Exception:  # noqa: BLE001
        body = {}
    # log, not print: print goes nowhere useful under a process manager and
    # cannot be filtered by level.
    try:
        log.info("[instagram webhook] %s", json.dumps(body)[:2000])
    except Exception:  # noqa: BLE001
        pass
    return {"ok": True}


@app.post("/api/instagram/test")
def instagram_test(body: IGConnectBody, authorization: str | None = Header(default=None)):
    require_user(authorization)
    return instagram.test_connection(body.access_token, body.ig_user_id)


@app.post("/api/instagram/connect")
def instagram_connect(body: IGConnectBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    check = instagram.test_connection(body.access_token, body.ig_user_id)
    if not check.get("ok"):
        raise HTTPException(400, check.get("error") or "Could not verify these credentials with Meta.")
    creds = instagram.save_credentials(email, body.access_token, body.ig_user_id,
                                       account_username=check.get("username"))
    return {"ok": True, "status": instagram.status(email), "username": creds.get("account_username")}


_PREFLIGHT_JPEG: bytes | None = None


@app.get("/preflight-image.jpg")
def preflight_image():
    """A plain square JPEG, on a public URL with no authentication.

    This exists so `POST /api/instagram/preflight` has something real for Meta
    to fetch. It must satisfy Instagram's own rules or the test would fail for
    the wrong reason: JPEG (not PNG, which Instagram refuses), and an aspect
    ratio inside 4:5 to 1.91:1 — square is safely in the middle.

    Served from this app, over the same public HTTPS the seller's real pictures
    go out on, so a successful fetch proves the route Meta will actually use.
    Built once and held in memory: it is the same twelve kilobytes every time."""
    global _PREFLIGHT_JPEG
    if _PREFLIGHT_JPEG is None:
        from PIL import Image, ImageDraw
        img = Image.new("RGB", (1080, 1080), (247, 248, 250))
        d = ImageDraw.Draw(img)
        d.rectangle([40, 40, 1040, 1040], outline=(92, 103, 144), width=6)
        d.text((90, 520), "One Tap Manager - connection test", fill=(60, 66, 86))
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=82)
        _PREFLIGHT_JPEG = buf.getvalue()
    return Response(content=_PREFLIGHT_JPEG, media_type="image/jpeg",
                    headers={"Cache-Control": "public, max-age=86400"})


class IGTestPostBody(BaseModel):
    caption: str = ""
    image_url: str = ""      # one of the seller's own, or blank for the test card
    kind: str = "image"      # "image" or "reel"


@app.post("/api/instagram/test-post")
def instagram_test_post(body: IGTestPostBody, request: Request,
                        authorization: str | None = Header(default=None)):
    """Put something on the account right now, to see it work.

    The preflight proves the chain WITHOUT posting, which is the right default.
    But there is a different question — "does a real post actually appear, with
    my caption, the right way up?" — and the only honest answer to that is a
    real post. So this one is deliberate, explicit, and deletable: it goes out
    immediately, the seller is told it is permanent from Instagram's side, and
    they remove it from the app in two taps if they do not want it.

    With no picture given it uses the same generated test card the preflight
    uses, so a brand-new account with no photos can still try it."""
    email = require_user(authorization)
    base = _public_base_url(request)
    publisher.remember_base_url(base)
    url = (body.image_url or "").strip()
    if url.startswith("/"):
        url = base.rstrip("/") + url
    if not url:
        url = base + "/preflight-image.jpg"
    caption = (body.caption or "").strip() or "Testing our new posting setup."
    kind = "reel" if str(body.kind).lower() in ("reel", "video") else "image"
    try:
        res = instagram.publish(email, kind, url, caption)
    except instagram.InstagramError as e:
        raise HTTPException(400, str(e))
    if not res.get("ok"):
        raise HTTPException(400, res.get("error") or "Instagram refused the post.")
    return res


@app.post("/api/instagram/preflight")
def instagram_preflight(request: Request,
                        authorization: str | None = Header(default=None)):
    """Answer "will this actually post?" in about ten seconds, without posting.

    Connecting proves the LOGIN worked. It proves nothing about publishing, and
    the three things that break publishing all fail silently until a real post
    is due on a Saturday evening. This creates a media container and throws it
    away: Meta validates the publishing permission AND fetches the image before
    it answers, so a container id coming back is proof of the whole chain. An
    unpublished container expires by itself in 24 hours and never appears on
    the seller's profile."""
    email = require_user(authorization)
    probe = _public_base_url(request) + "/preflight-image.jpg"
    res = instagram.preflight(email, probe)
    res["probe_url"] = probe
    return res


class PostNowBody(BaseModel):
    post_id: str


@app.post("/api/social/post-now")
def social_post_now(body: PostNowBody, request: Request,
                    authorization: str | None = Header(default=None)):
    """Publish one post immediately, whatever its scheduled time says.

    WHY THIS EXISTS: the only way to find out whether posting really works was
    to schedule something and wait — for the time to come round AND for the
    fifteen-minute ticker after it. That is a forty-minute feedback loop on a
    thing that either works or does not, and it is the reason "is it posting?"
    went unanswered for so long. This makes it immediate, and it returns the
    real result rather than a cheerful acknowledgement."""
    email = require_user(authorization)
    post = social.get_post(email, body.post_id)
    if not post:
        raise HTTPException(404, "That post is not there any more.")
    if not social.post_ready(post):
        raise HTTPException(400, "This post has no picture or clip yet.")
    if post.get("state") in ("published",):
        raise HTTPException(400, "That one has already gone out.")
    res = publisher.publish_post(email, post, _public_base_url(request))
    return {**res, "post": social.get_post(email, body.post_id)}


@app.post("/api/admin/tick")
@app.get("/api/admin/tick")
def admin_tick(request: Request, x_admin_token: str | None = Header(default=None),
               token: str | None = None):
    """ONE URL that does every scheduled job. Point a cron at this.

    WHY THIS MATTERS MORE THAN IT LOOKS. The in-process ticker lives inside the
    web process, so it only runs while the process does. On Render's free tier
    the service sleeps after fifteen minutes with no traffic; on any tier it
    restarts on deploy, and a single-instance app is asleep most of the night —
    which is exactly when a 7pm-IST post is due on a server in UTC. "It works
    while I have the site open" is the symptom of relying on that thread.

    An external cron calling this every fifteen minutes fixes both halves: the
    jobs run, and the request itself keeps a sleepy instance awake.

    GET is allowed as well as POST because most free cron services only send
    GET, and `?token=` because several cannot set a custom header. The token is
    the same ADMIN_TOKEN either way, and without it this refuses everyone —
    it never defaults open."""
    supplied = x_admin_token or token
    _require_admin(supplied)
    # Learn our own address from this very request, so a deployment whose only
    # traffic is this cron still knows what to hand Meta.
    publisher.remember_base_url(_public_base_url(request))

    out = {"at": pd.Timestamp.now().isoformat(timespec="seconds"),
           "base_url": publisher.base_url()}
    # Each job is caught separately: a failure in one must never stop the other
    # two. A week that cannot be planned is not a reason for today's post to
    # stay unpublished.
    for name, fn in (("publish", lambda: publisher.run_due()),
                     ("autoplan", autoplan.run_due),
                     ("winback", winback_auto.run_due)):
        try:
            out[name] = fn()
        except Exception as e:  # noqa: BLE001
            out[name] = {"error": str(e)[:200]}
    _record_tick(out)
    return out


_TICK_KEY = "last_tick"


def _record_tick(result: dict) -> None:
    """Remember that the jobs ran, so /api/admin/health can say whether the
    schedule is actually alive rather than assuming it is."""
    try:
        from backend.core import db as _db
        _db.upsert("app_config", {"key": _TICK_KEY, "value": json.dumps(result)[:4000]},
                   on_conflict="key")
    except Exception:  # noqa: BLE001
        pass
    global _LAST_TICK
    _LAST_TICK = result


_LAST_TICK: dict = {}


@app.get("/api/admin/schedule")
def admin_schedule(x_admin_token: str | None = Header(default=None),
                   token: str | None = None):
    """Is the background schedule alive, and when did it last do anything.

    Built because "it is not posting" and "the schedule never ran" look
    identical from the outside, and guessing between them wasted days."""
    _require_admin(x_admin_token or token)
    last = _LAST_TICK or {}
    if not last:
        try:
            from backend.core import db as _db
            row = _db.fetch_one("app_config", {"key": _TICK_KEY})
            if row and row.get("value"):
                last = json.loads(row["value"])
        except Exception:  # noqa: BLE001
            last = {}
    age = None
    try:
        age = round((pd.Timestamp.now() - pd.Timestamp(last["at"])).total_seconds() / 60, 1)
    except Exception:  # noqa: BLE001
        age = None
    return {
        "in_process_ticker": autoplan.scheduler_running(),
        "tick_seconds": autoplan.TICK_SECONDS,
        "last_tick": last,
        "minutes_since_last_tick": age,
        # The judgement, said plainly, rather than four numbers to interpret.
        "healthy": bool(age is not None and age < (autoplan.TICK_SECONDS / 60) * 3),
        "public_base_url": publisher.base_url(),
        "advice": ("Point a cron at POST /api/admin/tick every 15 minutes. The "
                   "in-process ticker stops whenever this service sleeps or "
                   "restarts, so on its own it only works while someone is "
                   "using the site."),
    }


@app.get("/api/social/queue")
def social_queue(authorization: str | None = Header(default=None)):
    """Why each post is or is not going out. See publisher.queue_report."""
    email = require_user(authorization)
    return publisher.queue_report(email)


@app.get("/api/admin/queue")
def admin_queue(email: str = "", x_admin_token: str | None = Header(default=None),
                token: str | None = None):
    """The same answer, for one account, without needing their password.

    Built because "it is not posting" took a day to turn into "that post is
    still in `approved` and was never scheduled", and that day should have been
    one request."""
    _require_admin(x_admin_token or token)
    if email:
        return {email: publisher.queue_report(email)}
    out = {}
    for account in (auth.load_users() or {}):
        try:
            if not instagram.is_connected(account):
                continue
            rep = publisher.queue_report(account)
        except Exception as e:  # noqa: BLE001
            out[account] = {"error": str(e)[:160]}
            continue
        # Only accounts with something unfinished are worth printing.
        if rep.get("posts"):
            out[account] = rep
    return out or {"note": "No connected account has any unfinished posts."}


@app.get("/api/social/publisher")
def social_publisher_status(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return publisher.status(email)


@app.post("/api/social/publish-due")
def social_publish_due(request: Request,
                       authorization: str | None = Header(default=None)):
    """Publish this seller's due posts now instead of waiting for the ticker."""
    email = require_user(authorization)
    return publisher.run_for(email, _public_base_url(request))


@app.post("/api/admin/social/publish-due")
def admin_social_publish_due(request: Request,
                             x_admin_token: str | None = Header(default=None)):
    """Cron target, for a deployment that runs the ticker externally."""
    _require_admin(x_admin_token)
    return publisher.run_due(_public_base_url(request))


@app.post("/api/instagram/disconnect")
def instagram_disconnect(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    instagram.clear_credentials(email)
    return {"ok": True}


class IGPostBody(BaseModel):
    image_url: str
    caption: str


def _public_base_url(request: Request) -> str:
    """This app's real public address. See backend/core/publicurl.py.

    It used to be the request's own scheme and host, which behind Render's TLS
    terminator is always http, so every canonical tag, every og:url and every
    media URL handed to Meta was on the wrong scheme.
    """
    return publicurl.from_request(request)


@app.post("/api/instagram/post")
def instagram_post(body: IGPostBody, request: Request,
                   authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    url = body.image_url
    if url.startswith("/"):
        url = _public_base_url(request) + url
    try:
        result = instagram.post_image(email, url, body.caption)
    except instagram.InstagramError as e:
        raise HTTPException(400, str(e))
    if not result.get("ok"):
        raise HTTPException(400, f"Instagram error at {result.get('step','')}: {result.get('error')}")
    return result


# ---------------------------------------------------------
# Content creator / auto-publish
# ---------------------------------------------------------
class ContentGenBody(BaseModel):
    topic: str | None = None
    platform: str | None = "instagram"
    with_image: bool = True


@app.get("/api/content/suggestion")
def content_current_suggestion(authorization: str | None = Header(default=None)):
    """The current 'suggested post' shown in the Approval panel — generated
    lazily on first Details open."""
    email = require_user(authorization)
    stored = user_store.get_key(email, "content_current_suggestion", None) or {}
    return {"suggestion": stored, "openai": content_gen.is_openai_available()}


@app.post("/api/content/suggestion/generate")
def content_suggestion_generate(insight_id: str,
                                authorization: str | None = Header(default=None)):
    """Fill in caption/hashtags/image for a panel content_XXXX id on demand."""
    email = require_user(authorization)
    full = smart.get_or_generate_content(email, insight_id, force=False)
    if not full:
        raise HTTPException(404, "That suggestion is no longer active, refresh the panel.")
    return {"suggestion": full, "openai": content_gen.is_openai_available()}


class ContentEditBody(BaseModel):
    caption: str | None = None
    hashtags: list[str] | None = None
    description: str | None = None
    image_url: str | None = None
    platform: str | None = None
    topic: str | None = None


@app.post("/api/content/suggestion/{insight_id}/edit")
def content_suggestion_edit(insight_id: str, body: ContentEditBody,
                            authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    updated = smart.save_content_suggestion(email, insight_id, body.dict(exclude_none=True))
    if not updated:
        raise HTTPException(404, "That suggestion is no longer active, refresh the panel.")
    return {"ok": True, "suggestion": updated}


@app.post("/api/content/upload-image")
async def content_upload_image(insight_id: str = "",
                               files: list[UploadFile] = File(...),
                               authorization: str | None = Header(default=None)):
    """Accept a user-picked image file, save it under data/generated_images/
    (same folder we serve publicly so Instagram can fetch it), stash the URL
    on the current content suggestion, and return the URL."""
    email = require_user(authorization)
    if not files:
        raise HTTPException(400, "No file uploaded.")
    f = files[0]
    ext = os.path.splitext(f.filename or "")[1].lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp"):
        raise HTTPException(400, "Use a PNG, JPG or WEBP image.")
    content = await f.read()
    if len(content) > 8 * 1024 * 1024:
        raise HTTPException(400, "Image is over 8MB, please compress or use a smaller one.")
    import uuid as _uuid
    saved = media.save(f"{_uuid.uuid4().hex}{ext}", content, email)
    public_url = saved["url"]
    # Attach to the current suggestion so refreshing keeps the uploaded image.
    if insight_id:
        smart.save_content_suggestion(email, insight_id, {"image_url": public_url})
    return {"ok": True, "image_url": public_url, "filename": f.filename,
            "durable": saved["durable"], "warning": saved["warning"]}


@app.post("/api/content/regenerate-image")
def content_regenerate_image(insight_id: str,
                             authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    stored = user_store.get_key(email, "content_current_suggestion", None) or {}
    if stored.get("id") != insight_id:
        raise HTTPException(404, "That suggestion is no longer active.")
    try:
        new_url = content_gen._openai_image(stored.get("product_type", "generic"),
                                            stored.get("topic", ""), email)
    except aicaps.CapReached:
        # The month's (or day's) picture allowance is spent. Let it through to
        # the 429 handler so this button says the same thing as every other
        # generate button, rather than a generic "failed".
        raise
    except Exception as e:
        raise HTTPException(400, f"Image generation failed: {e}")
    if not new_url:
        raise HTTPException(400, "Image generation returned no image.")
    stored["image_url"] = new_url
    user_store.set_key(email, "content_current_suggestion", stored)
    return {"ok": True, "image_url": new_url}


class ContentPostBody(BaseModel):
    insight_id: str
    caption: str
    hashtags: list[str] = []
    image_url: str
    platform: str = "instagram"


def _compose_ig_caption(caption: str, hashtags: list[str]) -> str:
    tags = " ".join("#" + str(t).strip().lstrip("#") for t in (hashtags or []) if str(t).strip())
    return (caption + ("\n\n" + tags if tags else "")).strip()


@app.post("/api/content/post-now")
def content_post_now(body: ContentPostBody, request: Request,
                     authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    url = body.image_url
    if url.startswith("/"):
        url = _public_base_url(request) + url
    try:
        result = instagram.post_image(email, url, _compose_ig_caption(body.caption, body.hashtags))
    except instagram.InstagramError as e:
        raise HTTPException(400, str(e))
    if not result.get("ok"):
        raise HTTPException(400, f"Instagram error at {result.get('step','')}: {result.get('error')}")
    # move suggestion to History (approved) and rotate the panel
    smart.set_decision(email, body.insight_id, "approved")
    smart.clear_content_suggestion(email)
    return {"ok": True, "result": result,
            "insights": smart.build_insights(email),
            "history": smart.build_history(email)}


class ContentScheduleBody(BaseModel):
    insight_id: str
    caption: str
    hashtags: list[str] = []
    image_url: str
    platform: str = "instagram"
    at: str   # ISO timestamp


@app.post("/api/content/schedule")
def content_schedule(body: ContentScheduleBody,
                     authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    entry = content_gen.schedule_post(email, {
        "caption": body.caption, "hashtags": body.hashtags,
        "image_url": body.image_url, "platform": body.platform,
        "source_insight_id": body.insight_id,
    }, body.at)
    smart.set_decision(email, body.insight_id, "approved")
    smart.clear_content_suggestion(email)
    return {"ok": True, "scheduled": entry,
            "insights": smart.build_insights(email),
            "history": smart.build_history(email)}


@app.get("/api/content/scheduled")
def content_list_scheduled(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {"scheduled": content_gen.list_scheduled(email)}


@app.delete("/api/content/scheduled/{entry_id}")
def content_delete_scheduled(entry_id: str,
                             authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {"ok": True, "scheduled": content_gen.delete_scheduled(email, entry_id)}


@app.post("/api/content/scheduled/run")
def content_run_scheduled(request: Request,
                          authorization: str | None = Header(default=None)):
    """Manually fire only this seller's due scheduled posts."""
    email = require_user(authorization)
    fired = content_gen.run_due_posts(base_public_url=_public_base_url(request), email=email)
    return {"ok": True, "fired": fired}


@app.post("/api/admin/content/scheduled/run")
def admin_content_run_scheduled(request: Request,
                                x_admin_token: str | None = Header(default=None)):
    """The authenticated cron target for publishing due posts for all sellers."""
    _require_admin(x_admin_token)
    return {"ok": True,
            "fired": content_gen.run_due_posts(base_public_url=_public_base_url(request))}


# ---------------------------------------------------------
# Ads analytics connectors
# ---------------------------------------------------------
class AdsConnectBody(BaseModel):
    connector: str
    credentials: dict = {}


@app.get("/api/ads/connectors")
def ads_connectors_list(authorization: str | None = Header(default=None)):
    email = optional_user(authorization)
    return {"connectors": ad_analytics.list_connectors(email)}


@app.post("/api/ads/connect")
def ads_connect(body: AdsConnectBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        return ad_analytics.save_connection(email, body.connector, body.credentials)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/ads/disconnect")
def ads_disconnect(body: AdsConnectBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    ad_analytics.disconnect(email, body.connector)
    return {"ok": True}


@app.get("/api/ads/metrics")
def ads_metrics(connector: str, days: int = 30,
                authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        return ad_analytics.get_metrics(email, connector, days=days)
    except ValueError as e:
        raise HTTPException(400, str(e))


# ---------------------------------------------------------
# Uploaded media
#
# Everything a seller uploads keeps the URL it has always had —
# /generated_images/<file> — but the bytes now come from backend.core.media,
# which keeps the durable copy in Supabase Storage and a local cache under the
# writable data dir. The old behaviour wrote into the checked-out repository,
# so every deploy rebuilt that folder from git and silently deleted every image
# and video a seller had ever uploaded. Nothing needs migrating: a file still
# in the old folder is served from there and copied up to storage as it is read.
# ---------------------------------------------------------
_IMG_DIR = media.cache_dir()


# Uploads are content-addressed — a fresh uuid per file — so the bytes behind a
# URL never change and the browser can keep them forever. That one header is
# what stops a storefront re-downloading every photo on every page view.
# Uploaded media is served from this app's OWN origin, so what it is allowed to
# do matters as much as how long it is cached.
#
# THE HOLE THIS CLOSES: .svg is an accepted upload (sellers have SVG logos, and
# refusing them is a real cost), and an SVG is a document, not a picture. It can
# carry <script>. Served as image/svg+xml from our origin with no policy, a
# seller could upload one and anyone who opened that URL would run its script
# with our origin's cookies. Rendering it in an <img> was always safe; opening
# it directly was not.
#
#   sandbox + default-src 'none'  is what the large code hosts serve user
#   content with: an <img> still renders, and a document opened directly can
#   run nothing, reach nothing and inherit no origin.
#   nosniff stops a browser deciding for itself that something we labelled
#   image/png is really HTML.
_MEDIA_CACHE_HEADERS = {
    "Cache-Control": "public, max-age=31536000, immutable",
    "X-Content-Type-Options": "nosniff",
    "Content-Security-Policy": "default-src 'none'; sandbox",
}


@app.get("/generated_images/{filename}")
def serve_media(filename: str, request: Request):
    # A conditional request costs nothing to answer.
    if request.headers.get("if-none-match") == f'"{filename}"':
        return Response(status_code=304, headers={**_MEDIA_CACHE_HEADERS,
                                                  "ETag": f'"{filename}"'})
    path = media.local_path(filename)
    if path:
        # stream from disk rather than reading the whole file into memory
        return FileResponse(path, media_type=media.content_type_for(filename),
                            headers={**_MEDIA_CACHE_HEADERS, "ETag": f'"{filename}"'})
    got = media.read(filename)
    if not got:
        raise HTTPException(404, "That file is no longer available.")
    data, ctype = got
    return Response(content=data, media_type=ctype,
                    headers={**_MEDIA_CACHE_HEADERS, "ETag": f'"{filename}"'})


@app.post("/api/media/backfill")
def media_backfill(authorization: str | None = Header(default=None)):
    """One-shot rescue: push anything still sitting only in the old repo folder
    into durable storage before the next deploy erases it."""
    require_user(authorization)
    return media.backfill()


@app.get("/api/media/status")
def media_status(authorization: str | None = Header(default=None)):
    """Is uploaded media actually safe here? The builder shows this, because a
    seller should not find out at the next redeploy."""
    require_user(authorization)
    # health() actually probes Storage and creates the bucket if it is missing,
    # rather than inferring safety from an environment variable being set.
    # "Configured but the bucket does not exist" looks identical to "working"
    # from the outside and loses every upload, which is the exact failure this
    # endpoint exists to catch.
    return media.health()


@app.get("/api/product-types")
def product_types():
    """Public list for the product-type picker (jewellery / clothes / …)."""
    return {"types": product_config.public_types()}


class ProductTypeBody(BaseModel):
    product_type: str
    label: str | None = None      # the seller's own words, e.g. "Soy wax candles"


@app.get("/api/product-type")
def get_product_type(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    m = smart.product_meta(email)
    return {"product_type": smart.get_product_type(email),
            "label": smart.get_product_label(email),
            # What the copy will actually call it — shown back to the seller so
            # they can see the effect of what they typed before anything posts.
            "display": m["label"], "noun": m["noun"], "nouns": m["nouns"],
            "types": product_config.public_types()}


@app.post("/api/product-type")
def set_product_type(body: ProductTypeBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    pt = smart.set_product_type(email, body.product_type, body.label)
    m = smart.product_meta(email)
    return {"ok": True, "product_type": pt, "label": smart.get_product_label(email),
            "display": m["label"], "noun": m["noun"], "nouns": m["nouns"]}


def _resolve_product_type(authorization: str | None, product_type: str | None) -> str:
    """Prefer an explicit value (and persist it if logged in); else the saved
    account value; else the generic default."""
    email = optional_user(authorization)
    if product_type:
        if email:
            smart.set_product_type(email, product_type)
        return product_config.normalize(product_type)
    if email:
        return smart.get_product_type(email)
    return product_config.DEFAULT_TYPE


# ---------------------------------------------------------
# Upload + mapping
# ---------------------------------------------------------
SUPPORTED_EXTENSIONS = {".csv", ".tsv", ".txt", ".xlsx", ".xls", ".json"}


def _read_any_table(filename: str, content: bytes) -> list[tuple[str, "pd.DataFrame"]]:
    """
    Parse an uploaded file of (almost) any common tabular format into one or
    more (label, DataFrame) pairs. Excel workbooks with multiple sheets
    produce one entry per sheet so each can be mapped independently.
    """
    ext = os.path.splitext(filename)[1].lower()
    buf = io.BytesIO(content)

    if ext in (".xlsx", ".xls"):
        sheets = pd.read_excel(buf, sheet_name=None)  # dict of {sheet_name: df}
        if len(sheets) == 1:
            only_df = next(iter(sheets.values()))
            return [(filename, only_df)]
        return [(f"{filename} — {sheet}", df) for sheet, df in sheets.items()]

    if ext == ".json":
        try:
            df = pd.read_json(buf)
        except ValueError:
            buf.seek(0)
            df = pd.json_normalize(pd.read_json(buf, typ="series"))
        return [(filename, df)]

    if ext == ".tsv":
        return [(filename, pd.read_csv(buf, sep="\t"))]

    # .csv, .txt, or unknown — try comma first, then auto-detect the delimiter
    try:
        return [(filename, pd.read_csv(buf))]
    except Exception:
        buf.seek(0)
        return [(filename, pd.read_csv(buf, sep=None, engine="python"))]


@app.post("/api/upload")
async def upload(files: list[UploadFile] = File(...), x_session_id: str | None = Header(default=None)):
    if len(files) > 100:
        raise HTTPException(400, "Please upload at most 100 files at a time.")
    sess = get_session(x_session_id)
    out = []
    for f in files:
        ext = os.path.splitext(f.filename or "")[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            raise HTTPException(400, f"{f.filename}: unsupported file type. Supported: CSV, TSV, TXT, XLSX, XLS, JSON.")
        content = await f.read()
        try:
            parsed = _read_any_table(f.filename or "file", content)
        except Exception as e:
            raise HTTPException(400, f"Could not read {f.filename}: {e}")
        for label, df in parsed:
            if df.empty or len(df.columns) == 0:
                continue
            fid = secrets.token_hex(6)
            sess.raw_dfs[fid] = df
            sess.file_names[fid] = label
            out.append(_file_info(fid, sess))
    if not out:
        raise HTTPException(400, "No readable data found in the uploaded file(s).")
    # multi-file? try to auto-join into one dataset for mapping & insights
    join_info = None
    user_fids = {f: d for f, d in sess.raw_dfs.items() if f != "joined_auto"}
    if len(user_fids) >= 2:
        result = joiner.auto_join(user_fids, sess.file_names)
        if result:
            joined_df, join_report = result
            sess.raw_dfs["joined_auto"] = joined_df
            sess.file_names["joined_auto"] = "🔗 Joined dataset (auto)"
            join_info = {**join_report, "file": _file_info("joined_auto", sess)}
    return {"files": out, "join": join_info}


def _file_info(fid: str, sess: SessionData) -> dict:
    df = sess.raw_dfs[fid]
    # If this is a recognised POS export (PetPooja, Toast, Square, Posist...),
    # use its known column layout instead of the generic guesser — no mapping
    # step needed and no chance of picking unit price over line total.
    pos = pos_formats.detect_format(df)
    suggested = mapper.suggest_mapping(df)
    if pos and pos["mapping"].get("date") and pos["mapping"].get("amount"):
        suggested = {**suggested, **pos["mapping"]}
    return {
        "id": fid,
        "name": sess.file_names[fid],
        "rows": int(len(df)),
        "columns": [str(c) for c in df.columns],
        "kind": mapper.classify_file(df),
        "suggested_mapping": suggested,
        "pos_format": ({"label": pos["label"], "note": pos["note"],
                        "confidence": pos["confidence"]} if pos else None),
        "preview": df.head(8).astype(str).values.tolist(),
    }


@app.get("/api/files")
def list_files(x_session_id: str | None = Header(default=None)):
    sess = get_session(x_session_id)
    return {"files": [_file_info(fid, sess) for fid in sess.raw_dfs],
            "mapped": sess.txns_df is not None}


@app.delete("/api/files/{file_id}")
def delete_file(file_id: str, x_session_id: str | None = Header(default=None)):
    sess = get_session(x_session_id)
    if file_id not in sess.raw_dfs:
        raise HTTPException(404, "File not found")
    sess.raw_dfs.pop(file_id)
    name = sess.file_names.pop(file_id, file_id)
    if sess.mapped_file_id == file_id:
        sess.txns_df = None
        sess.mapped_file_id = None
    return {"ok": True, "deleted": name, "mapped": sess.txns_df is not None}


@app.post("/api/mapping")
def confirm_mapping(body: MappingBody, x_session_id: str | None = Header(default=None),
                    authorization: str | None = Header(default=None)):
    sess = bind_session(get_session(x_session_id), optional_user(authorization))
    if body.file_id not in sess.raw_dfs:
        raise HTTPException(404, "File not found, upload it first")
    try:
        sess.txns_df, diagnostics = mapper.build_transactions(sess.raw_dfs[body.file_id], body.mapping)
        sess.mapped_file_id = body.file_id
    except ValueError as e:
        raise HTTPException(400, str(e))

    if diagnostics["rows_after"] == 0:
        sess.txns_df = None
        sess.mapped_file_id = None
        raise HTTPException(
            400,
            f"None of the {diagnostics['rows_before']} rows had a readable date and amount. "
            f"Check that the Date and Amount columns you mapped actually contain dates/numbers "
            f"(not blank, header, or text rows)."
        )

    warning = None
    if diagnostics["dropped_rows"] > 0:
        pct = round(diagnostics["dropped_rows"] / diagnostics["rows_before"] * 100, 1)
        reasons = []
        if diagnostics["dropped_bad_date"]:
            reasons.append(f"{diagnostics['dropped_bad_date']} unreadable date(s)")
        if diagnostics["dropped_bad_amount"]:
            reasons.append(f"{diagnostics['dropped_bad_amount']} unreadable amount(s)")
        warning = (
            f"{diagnostics['dropped_rows']} of {diagnostics['rows_before']} rows ({pct}%) were skipped — "
            + " and ".join(reasons) + "."
        )

    # SHARED DATA: persist to the logged-in account so Smart mode (and other
    # devices) see the same sales without a re-upload.
    email = optional_user(authorization)
    if email:
        smart.save_sales(email, sess.txns_df, {"files": sess.file_names.get(body.file_id, "Sales upload")})
        replenish.after_sales(email, "sales upload")

    return {"ok": True, "rows": diagnostics["rows_after"],
            "columns": [str(c) for c in sess.txns_df.columns], "warning": warning}


def _require_txns(sess: SessionData, authorization: str | None = None) -> pd.DataFrame:
    """Return this session's mapped transactions. SHARED DATA: if the browser
    session has none but the logged-in account has saved sales (uploaded on
    another device), hydrate from the account so every device sees the same
    data — upload once, use everywhere."""
    email = optional_user(authorization)
    bind_session(sess, email)
    if sess.txns_df is None:
        if email:
            saved = smart.load_sales(email)
            if saved is not None and len(saved):
                sess.txns_df = saved
                sess.mapped_file_id = "shared_account_sales"
    if sess.txns_df is None:
        raise HTTPException(400, "No sales data yet, upload a sales file and confirm the mapping first.")
    return sess.txns_df


# ---------------------------------------------------------
# Sample data (one-click demo — activation without an upload)
# ---------------------------------------------------------
SAMPLE_FILE = os.path.join(_ROOT_DATA_DIR := os.path.join(os.path.dirname(__file__), "..", "data"),
                           "sample_transactions.csv")


@app.post("/api/demo")
def load_demo(x_session_id: str | None = Header(default=None),
              authorization: str | None = Header(default=None)):
    """Load 90 days of realistic sample transactions, pre-mapped, so nobody has
    to find a CSV on this laptop before they can see what the app does.

    Loads into BOTH stores: the guest session (which is what the landing page
    reads) and, when someone is signed in, their account store — otherwise
    "See it with sample data" appears to do nothing for a signed-in seller.
    """
    sess = get_session(x_session_id)
    if not os.path.exists(SAMPLE_FILE):
        raise HTTPException(503, "Sample dataset missing on the server.")
    df = pd.read_csv(SAMPLE_FILE)
    fid = secrets.token_hex(6)
    sess.raw_dfs[fid] = df
    sess.file_names[fid] = "Sample data (90 days)"
    identity = {c: c for c in ["date", "customer_id", "customer_name", "order_id",
                               "product", "category", "subcategory", "quantity", "amount"]}
    sess.txns_df, _ = mapper.build_transactions(df, identity)
    sess.mapped_file_id = fid

    saved_to_account = False
    email = optional_user(authorization)
    if email and not (smart.data_status(email).get("sales") or {}).get("ready"):
        # never overwrite real data someone has already uploaded
        try:
            smart.save_sales(email, sess.txns_df,
                             {"source": "sample", "name": "Sample data (90 days)"},
                             mode="replace")
            saved_to_account = True
        except Exception:  # noqa: BLE001 — the session copy is still usable
            pass
    return {"files": [_file_info(fid, sess)], "mapped": True,
            "saved_to_account": saved_to_account}


# ---------------------------------------------------------
# Pricing feedback ("would you pay this?") — GTM validation data
# ---------------------------------------------------------
class FeedbackBody(BaseModel):
    product: str
    vote: str  # "yes" | "no"


@app.post("/api/feedback")
def pricing_feedback(body: FeedbackBody, authorization: str | None = Header(default=None)):
    """One-tap pricing validation from the pricing modal. Answers the GTM
    question ('would anyone pay?') with behaviour instead of guesses —
    review data/feedback.csv weekly."""
    if body.vote not in ("yes", "no") or not pricing.get_product(body.product):
        raise HTTPException(400, "Invalid feedback")
    email = auth.user_from_token((authorization or "").removeprefix("Bearer ").strip()) or "guest"
    if db.SUPABASE_ENABLED:
        db.insert("feedback", {"email": email, "product": body.product, "vote": body.vote})
        return {"ok": True}
    fb_file = os.path.join(auth.BASE_DIR, "feedback.csv")
    os.makedirs(os.path.dirname(fb_file), exist_ok=True)
    header = not os.path.exists(fb_file)
    pd.DataFrame([{"email": email, "product": body.product, "vote": body.vote,
                   "timestamp": pd.Timestamp.now().isoformat()}]) \
        .to_csv(fb_file, mode="a", header=header, index=False)
    return {"ok": True}


# ---------------------------------------------------------
# Analytics / SubCategory / RFM  (no login needed, same as original)
# ---------------------------------------------------------
@app.get("/api/languages")
def get_languages():
    return {"languages": i18n.LANGUAGES}


@app.get("/api/analytics")
def get_analytics(lang: str = "en", x_session_id: str | None = Header(default=None),
                  authorization: str | None = Header(default=None)):
    result = analytics.sales_analytics(_require_txns(get_session(x_session_id), authorization))
    result["insights"] = i18n.render_all(result["insights"], lang)
    return result


@app.get("/api/subcategory")
def get_subcategory(lang: str = "en", x_session_id: str | None = Header(default=None),
                    authorization: str | None = Header(default=None)):
    result = analytics.subcategory_trends(_require_txns(get_session(x_session_id), authorization))
    if result.get("insights"):
        result["insights"] = i18n.render_all(result["insights"], lang)
    return result


@app.post("/api/positioning")
async def analyze_positioning(lang: str = "en", product_type: str | None = None,
                              files: list[UploadFile] = File(...),
                              x_session_id: str | None = Header(default=None),
                              authorization: str | None = Header(default=None)):
    """Upload a café's own reviews file -> brand positioning vs the benchmark cafés.
    Free for everyone during launch, and free forever after — part of the
    Free plan."""
    get_session(x_session_id)
    if not pricing.launch_mode():
        email = require_user(authorization)
        if not billing.check_and_consume(email, "positioning"):
            raise _paywall("positioning")
    f = files[0]
    ext = os.path.splitext(f.filename or "")[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(400, f"{f.filename}: unsupported file type. Supported: CSV, TSV, TXT, XLSX, XLS, JSON.")
    pt = _resolve_product_type(authorization, product_type)
    content = await f.read()
    try:
        parsed = _read_any_table(f.filename or "reviews", content)
    except Exception as e:
        raise HTTPException(400, f"Could not read {f.filename}: {e}")
    if not parsed:
        raise HTTPException(400, "No readable data found in that file.")
    # SHARED DATA: save reviews to the account so Smart mode sees them too.
    email = optional_user(authorization)
    if email:
        smart.save_review(email, parsed[0][1], {})
    return positioning.analyze_reviews(parsed[0][1], lang, product_type=pt)


@app.get("/api/subcategory/detail")
def get_subcategory_detail(value: str, lang: str = "en", x_session_id: str | None = Header(default=None),
                           authorization: str | None = Header(default=None)):
    result = analytics.subcategory_detail(_require_txns(get_session(x_session_id), authorization), value)
    if result.get("insights"):
        result["insights"] = i18n.render_all(result["insights"], lang)
    return result


@app.get("/api/rfm")
def get_rfm(x_session_id: str | None = Header(default=None),
            authorization: str | None = Header(default=None)):
    return analytics.calculate_rfm(_require_txns(get_session(x_session_id), authorization))


class WinbackSession:
    """Holds the last generated batch of win-back messages so the Excel
    download endpoint doesn't have to regenerate them (and doesn't burn
    another AI call just to produce the file)."""
    def __init__(self, email: str):
        self.email = email
        self.rows: list[dict] = []

_winback_cache: dict[str, WinbackSession] = {}


@app.post("/api/rfm/winback")
def generate_winback(x_session_id: str | None = Header(default=None),
                     authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    sess = bind_session(get_session(x_session_id), email)
    txns = _require_txns(sess, authorization)

    customers = analytics.at_risk_cached(email, txns)
    if not customers:
        return {"customers": [], "usage": _usage(email)}

    # The at-risk LIST and the ready-to-send campaign are both free forever,
    # part of the Free plan — deliberately NOT charged per campaign, because
    # charging per campaign taxes the exact behaviour that proves the
    # product works and creates the habit worth renewing.
    if not billing.check_and_consume(email, "winback_campaign"):
        raise _paywall("winback_campaign")

    # template + market-basket-analysis based — no OpenAI call, no rate limit needed
    results = templates.build_winback_messages(customers)

    _winback_cache[x_session_id] = WinbackSession(email)
    _winback_cache[x_session_id].rows = results
    return {"customers": results, "usage": _usage(email)}


@app.post("/api/rfm/winback/send")
def winback_send(body: CampaignBody,
                 x_session_id: str | None = Header(default=None),
                 authorization: str | None = Header(default=None)):
    """Actually send the campaign — email now, WhatsApp through a provider when
    one is connected and as tap-to-send links until then. Recording it for
    measurement happens automatically, so the seller never has to remember."""
    email = require_user(authorization)
    rows = body.rows or []
    if not rows:
        cached = _winback_cache.get(x_session_id)
        if cached and cached.email != email:
            cached = None
        rows = (cached.rows if cached else []) or []
    if not rows:
        raise HTTPException(400, "Generate the campaign first, then send it.")
    # GATE 1: never sign a customer-facing message with an email handle.
    try:
        brand = brandname.require(email)
    except ValueError as e:
        raise HTTPException(400, str(e))
    cache.clear(email)
    return campaigns.send(email, rows, brand, body.template or "",
                          tuple(body.channels or ("email", "whatsapp")),
                          body.subject or "")


@app.post("/api/rfm/winback/preview")
def winback_preview(body: CampaignBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    # The PREVIEW is allowed to run without a brand name — that is how the
    # seller discovers they need one — but it says so loudly and shows the gap
    # rather than papering over it with their email handle.
    resolved = brandname.resolve(email)
    brand = resolved["name"] or "[your shop name]"
    return {"preview": campaigns.preview(body.rows or [], brand, body.template or ""),
            "template": body.template or campaigns.default_template(),
            "whatsapp_live": messaging.whatsapp_enabled(),
            "email_ready": messaging.smtp_configured(),
            "brand": resolved["name"],
            "brand_ready": resolved["ready"],
            "brand_prompt": ("" if resolved["ready"] else
                             "Add your shop name first — these messages go out signed with it. "
                             "Set it in Product Studio → Brand, or Site Management.")}


@app.get("/api/rfm/winback/sends")
def winback_sends(authorization: str | None = Header(default=None)):
    return {"sends": campaigns.history(require_user(authorization))}


@app.get("/api/rfm/winback/proof")
def winback_proof_summary(authorization: str | None = Header(default=None)):
    """What every campaign actually recovered — the renewal conversation."""
    return winback_proof.summary(require_user(authorization))


@app.post("/api/rfm/winback/sent")
def winback_mark_sent(body: WinbackSentBody,
                      x_session_id: str | None = Header(default=None),
                      authorization: str | None = Header(default=None)):
    """One tick: this campaign went out. From here the app can measure it."""
    email = require_user(authorization)
    rows = body.customers or []
    if not rows:
        cached = _winback_cache.get(x_session_id)
        if cached and cached.email != email:
            cached = None
        rows = (cached.rows if cached else []) or []
    try:
        winback_proof.mark_sent(email, rows, body.channel or "whatsapp", body.note or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    return winback_proof.summary(email)


@app.post("/api/rfm/winback/confirm")
def winback_confirm(body: WinbackUnsentBody, authorization: str | None = Header(default=None)):
    """"I have sent those WhatsApp messages" — promotes a prepared campaign to
    a real one, and starts its measurement window from now."""
    email = require_user(authorization)
    try:
        winback_proof.confirm_sent(email, body.campaign_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return winback_proof.summary(email)


@app.post("/api/rfm/winback/unsent")
def winback_unmark(body: WinbackUnsentBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    winback_proof.unmark(email, body.campaign_id)
    return winback_proof.summary(email)


@app.get("/api/rfm/winback/download")
def download_winback(x_session_id: str | None = Header(default=None),
                     authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cached = _winback_cache.get(x_session_id)
    if not cached or cached.email != email or not cached.rows:
        raise HTTPException(400, "Generate the messages first, then download.")

    df = _spreadsheet_safe_frame(pd.DataFrame(cached.rows)).rename(columns={
        "customer_id": "Customer ID",
        "customer_name": "Customer Name",
        "recency_days": "Days Since Last Visit",
        "frequency": "Total Orders",
        "monetary": "Total Spend",
        "last_purchase_date": "Last Purchase Date",
        "favorite_item": "Favorite Item",
        "favorite_category": "Favorite Category",
        "price_tier": "Spend Tier",
        "preferred_day": "Preferred Day",
        "trend": "Purchase Trend",
        "coupon_code": "Coupon Code",
        "discount_pct": "Discount %",
        "message": "Win-back Message",
    })
    col_order = ["Customer ID", "Customer Name", "Last Purchase Date", "Days Since Last Visit",
                 "Total Orders", "Total Spend", "Favorite Item", "Favorite Category",
                 "Spend Tier", "Preferred Day", "Purchase Trend", "Coupon Code", "Discount %",
                 "Win-back Message"]
    df = df[[c for c in col_order if c in df.columns]]

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="At-Risk Win-back")
        ws = writer.sheets["At-Risk Win-back"]
        widths = {"A": 16, "B": 18, "C": 16, "D": 14, "E": 12, "F": 14, "G": 20, "H": 18,
                  "I": 12, "J": 14, "K": 26, "L": 14, "M": 11, "N": 65}
        for col, w in widths.items():
            ws.column_dimensions[col].width = w
    buf.seek(0)

    from fastapi.responses import Response, StreamingResponse
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=winback_messages.xlsx"},
    )


class WinbackExportBody(BaseModel):
    # the win-back popup lets the seller edit/remove/add rows before export;
    # we just render whatever they send to a tidy Excel.
    rows: list[dict]


@app.post("/api/rfm/winback/export")
def export_winback_edited(body: WinbackExportBody,
                          authorization: str | None = Header(default=None)):
    """Export the win-back list AS EDITED in the popup — edited fields, removed
    rows, and manually added rows all come through here."""
    require_user(authorization)
    if not body.rows:
        raise HTTPException(400, "Nothing to export, the list is empty.")
    df = _spreadsheet_safe_frame(pd.DataFrame(body.rows))
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Win-back")
        ws = writer.sheets["Win-back"]
        for i, col in enumerate(df.columns):
            try:
                width = min(70, max(12, int(df[col].astype(str).str.len().max()) + 2, len(str(col)) + 2))
            except Exception:
                width = 18
            ws.column_dimensions[chr(65 + i) if i < 26 else "A"].width = width
    buf.seek(0)
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=winback_messages.xlsx"})


# ---------------------------------------------------------
# AI features (login + rate limit, same as original)
# ---------------------------------------------------------
def _consume_ai_use(email: str, feature: str) -> None:
    """Daily free quota first, then paid top-up credits, else paywall.
    Launch mode and Pro are unlimited."""
    if pricing.launch_mode() or billing.is_unlimited(email):
        auth.check_usage_limit(email, feature)  # still log usage for analytics; never blocks here
        return
    if auth.check_usage_limit(email, feature):
        return
    if billing.spend_credits(email, pricing.credits_for("ai_use")):
        return
    quota = pricing.ai_quota(billing.get_plan(email))
    raise _paywall(
        "ai_use",
        f"You've used today's {quota} free AI runs. Max removes the daily limit "
        f"— or spend credits, which never expire.",
    )


@app.post("/api/analyst")
def run_analyst(x_session_id: str | None = Header(default=None),
                authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    sess = bind_session(get_session(x_session_id), email)
    if not sess.raw_dfs:
        raise HTTPException(400, "Upload files first")
    _consume_ai_use(email, "analyst_ai")
    named = {sess.file_names[fid]: df for fid, df in sess.raw_dfs.items()}
    try:
        results = ai.run_business_analyst(named)
    except RuntimeError as e:
        raise HTTPException(500, str(e))
    return {"results": results, "usage": _usage(email)}


@app.post("/api/chat")
def chat(body: ChatBody, x_session_id: str | None = Header(default=None),
         authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    sess = bind_session(get_session(x_session_id), email)
    _consume_ai_use(email, "chatbot")

    sess.chat_messages.append({"role": "user", "content": body.message})
    first = not sess.used_initial_prompt
    try:
        result = ai.run_chat(sess.raw_dfs, sess.chat_messages, first_time=first)
    except RuntimeError as e:
        raise HTTPException(500, str(e))
    sess.used_initial_prompt = True
    sess.chat_messages.append({"role": "assistant", "content": result["reply"]})
    return {**result, "usage": _usage(email)}


@app.get("/api/chat/history")
def chat_history(x_session_id: str | None = Header(default=None),
                 authorization: str | None = Header(default=None)):
    # Chat history can contain sales-derived answers. It is private account
    # data, unlike the anonymous first-run upload preview.
    email = require_user(authorization)
    return {"messages": bind_session(get_session(x_session_id), email).chat_messages}


# ---------------------------------------------------------
# Billing / Payments (Razorpay)
# ---------------------------------------------------------
class OrderBody(BaseModel):
    product: str  # a plan id ("pro", billed as Max) or a credit pack (credits_100 | ...)


class VerifyBody(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str
    product: str | None = None  # server-side pending-order record takes precedence


@app.post("/api/pay/create-order")
def create_order(body: OrderBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    current = billing.get_plan(email)
    if body.product == current:
        raise HTTPException(400, f"You are already on {pricing.get_plan(current)['name']}.")
    try:
        return billing.create_order(email, body.product)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        raise HTTPException(503, str(e))


@app.post("/api/pay/verify")
def verify_payment(body: VerifyBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    granted = billing.verify_payment(email, body.razorpay_order_id, body.razorpay_payment_id,
                                     body.razorpay_signature, body.product)
    if not granted:
        raise HTTPException(400, "Payment signature verification failed, contact support if an amount was deducted.")
    return {"ok": True, "product": granted, "usage": _usage(email)}


@app.post("/api/pay/cancel")
def cancel_subscription(authorization: str | None = Header(default=None)):
    """Cancel the paid subscription and return to Free. See
    billing.cancel_subscription for why this is just a plan-flag revert."""
    email = require_user(authorization)
    res = billing.cancel_subscription(email)
    return {**res, "usage": _usage(email), "plan": billing.get_plan(email)}


# ---------------------------------------------------------
# Position Strategy  (login required; state persisted per account)
# ---------------------------------------------------------
def _ps_view(email: str) -> dict:
    """Assemble everything the Position Strategy page needs from saved state."""
    st = user_store.get_key(email, "position_strategy", {}) or {}
    current_id = st.get("current_id")
    out = {
        "detected": bool(current_id),
        "current_id": current_id,
        "n_reviews": st.get("n_reviews"),
        "detected_at": st.get("detected_at"),
        "current": position_strategy.position_card(current_id) if current_id else None,
        "options": position_strategy.target_options(current_id) if current_id else [],
        "target_id": st.get("target_id"),
        "plan": None,
    }
    target_id = st.get("target_id")
    # target may now equal current (a "stay & strengthen" plan)
    if current_id and target_id:
        try:
            plan = position_strategy.build_plan(current_id, target_id)
        except ValueError:
            plan = None
        if plan:
            checked = set(st.get("checked", []))
            for item in plan["checklist"]:
                item["done"] = item["id"] in checked
            done = sum(1 for i in plan["checklist"] if i["done"])
            plan["progress"] = {"done": done, "total": len(plan["checklist"])}
            # per-level progress, so the UI can gate Level N+1 on Level N
            level_prog = {}
            for it in plan["checklist"]:
                lv = it.get("level", 1)
                d = level_prog.setdefault(lv, {"done": 0, "total": 0})
                d["total"] += 1
                if it["done"]:
                    d["done"] += 1
            plan["level_progress"] = level_prog
            out["plan"] = plan
    return out


@app.get("/api/position-strategy")
def ps_get(authorization: str | None = Header(default=None)):
    return _ps_view(require_user(authorization))


@app.post("/api/position-strategy/detect")
async def ps_detect(lang: str = "en", files: list[UploadFile] = File(...),
                    authorization: str | None = Header(default=None)):
    """Auto-detect the café's current position from its reviews, reusing the
    Positioning engine, and persist it to the account."""
    email = require_user(authorization)
    f = files[0]
    ext = os.path.splitext(f.filename or "")[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(400, f"{f.filename}: unsupported file type. Supported: CSV, TSV, TXT, XLSX, XLS, JSON.")
    pt = _resolve_product_type(authorization, None)
    content = await f.read()
    try:
        parsed = _read_any_table(f.filename or "reviews", content)
    except Exception as e:
        raise HTTPException(400, f"Could not read {f.filename}: {e}")
    if not parsed:
        raise HTTPException(400, "No readable data found in that file.")
    # SHARED DATA: save reviews to the account so Smart mode sees them too.
    smart.save_review(email, parsed[0][1], {})
    data = positioning.analyze_reviews(parsed[0][1], lang, product_type=pt)
    if not data.get("available"):
        raise HTTPException(400, data.get("reason", "Not enough review data to detect a position."))
    quadrant = (data.get("perceptual_map", {}).get("you", {}) or {}).get("quadrant")
    current_id = position_strategy.QUADRANT_TO_ID.get(quadrant)
    if not current_id:
        raise HTTPException(400, "Couldn't map your reviews to a position, try a file with more reviews.")

    st = user_store.get_key(email, "position_strategy", {}) or {}
    # a fresh detection that lands in a different position invalidates an old
    # target/checklist; a re-detection to the same position keeps the progress.
    if st.get("current_id") != current_id:
        st["target_id"] = None
        st["checked"] = []
    st.update({
        "current_id": current_id,
        "n_reviews": data.get("n_reviews"),
        "detected_at": pd.Timestamp.now().isoformat(timespec="seconds"),
    })
    user_store.set_key(email, "position_strategy", st)
    return _ps_view(email)


class PSTargetBody(BaseModel):
    target_id: str


@app.post("/api/position-strategy/target")
def ps_target(body: PSTargetBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    st = user_store.get_key(email, "position_strategy", {}) or {}
    if not st.get("current_id"):
        raise HTTPException(400, "Detect your current position first.")
    try:
        # target may equal current (strengthen-in-place)
        position_strategy.build_plan(st["current_id"], body.target_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # switching target starts a fresh checklist
    if st.get("target_id") != body.target_id:
        st["checked"] = []
    st["target_id"] = body.target_id
    user_store.set_key(email, "position_strategy", st)
    return _ps_view(email)


class PSCheckBody(BaseModel):
    item_id: str
    done: bool


@app.post("/api/position-strategy/check")
def ps_check(body: PSCheckBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    st = user_store.get_key(email, "position_strategy", {}) or {}
    checked = set(st.get("checked", []))
    if body.done:
        checked.add(body.item_id)
    else:
        checked.discard(body.item_id)
    st["checked"] = sorted(checked)
    user_store.set_key(email, "position_strategy", st)
    return {"ok": True, "checked_count": len(checked)}


@app.post("/api/position-strategy/reset")
def ps_reset(authorization: str | None = Header(default=None)):
    """Clear the saved position strategy for this account (start over)."""
    email = require_user(authorization)
    user_store.set_key(email, "position_strategy", {})
    return {"ok": True}


# ---------------------------------------------------------
# Smart CafeX  (Odoo-style workspace — login required, data persisted)
# ---------------------------------------------------------
SMART_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Smart CafeX")

REVIEW_ROLES = ("review", "rating", "date")


def _smart_status_payload(email: str, sess) -> dict:
    smart.hydrate_session(email, sess)
    return {
        "email": email,
        "data": smart.data_status(email),
        "insights": smart.build_insights(email),
        "history": smart.build_history(email),
        "tasks": smart.get_tasks(email),
        # What is still not set up, and the single next thing worth doing. The
        # home screen leads with this for a seller who has just signed up, and
        # hides it entirely once they are through it.
        "setup": setup_steps.progress(email),
        # The first-run journey (core/onboarding.py). A compact read; the
        # journey's own screens fetch /api/onboarding for the full picture.
        "onboarding": onboarding.summary(email),
        # When the Social Media Manager plans next week on its own.
        "autoplan": _safe_autoplan_status(email),
    }


def _safe_autoplan_status(email: str) -> dict | None:
    try:
        return autoplan.status(email)
    except Exception:  # noqa: BLE001 — the home screen must never fail on this
        return None


def _home_fingerprint(email: str) -> str:
    """Everything else the home screen shows that cache.stamp() cannot see.

    BUG THIS FIXES: the ETag was the data fingerprint alone — datasets and
    order count. Approving a post, ticking a task or a new auto-planned week
    changed none of those, so the browser was told "304, nothing changed" and
    kept painting the Approval panel and task list from before the action."""
    try:
        posts = [(p.get("id"), p.get("state"), bool(p.get("image_url")),
                  bool(p.get("video_url")), p.get("scheduled_at"))
                 for p in social._posts(email)]
        tasks = [(t.get("id"), t.get("done"), tuple(t.get("steps_done") or []))
                 for t in smart.get_tasks(email)]
        dec = user_store.get_key(email, "smart_decisions", {}) or {}
        ap = user_store.get_key(email, autoplan.STATE_KEY, {}) or {}
        try:
            pos = [(p.get("po_number"), p.get("status"), p.get("n_items"))
                   for p in supply.get_purchase_orders(email)]
        except Exception:  # noqa: BLE001
            pos = []
        # Not the content-suggestion id: the payload itself creates one on the
        # first read, which would make every first 200 look stale. Deciding a
        # suggestion changes smart_decisions, which is already in here.
        try:
            ob = onboarding.fingerprint(email)
        except Exception:  # noqa: BLE001
            ob = None
        return json.dumps([posts, tasks, sorted((k, str(v)) for k, v in dec.items()),
                           ap.get("last_run_at"), social.get_settings(email).get("auto_plan_day"),
                           pos, ob], default=str)
    except Exception:  # noqa: BLE001 — a fingerprint failure only costs a 200
        return secrets.token_hex(4)


@app.get("/api/smart/state")
def smart_state(response: Response,
                x_session_id: str | None = Header(default=None),
                if_none_match: str | None = Header(default=None),
                authorization: str | None = Header(default=None)):
    """The home screen's payload, with a conditional GET on top.

    WHY: this is the first thing every page load asks for, and a browser that
    reclaims the tab (switch apps on a phone, come back) throws the whole page
    away and asks again. cache.stamp() is already an exact fingerprint of the
    account's data — row counts, updated_at, order count — so it makes a
    correct ETag for free: when nothing has changed the browser gets a 304 with
    no body, and the app repaints from what it already had instead of
    re-downloading and re-rendering the same screen.

    The stamp changes the moment a dataset, an order or an upload changes, so
    a seller can never be shown a stale figure waiting for a timer."""
    email = require_user(authorization)
    # A missed weekly plan (the server slept through Saturday) catches up in
    # the background the moment the seller opens the app. Never blocks this.
    try:
        autoplan.kick(email)
    except Exception:  # noqa: BLE001
        pass
    # Same for the weekly win-back scan: a missed Monday catches up here rather
    # than waiting a whole week for the next one.
    try:
        winback_auto.kick(email)
    except Exception:  # noqa: BLE001
        pass
    # AND publishing. This was the gap: the two jobs above caught up the moment
    # a seller opened the app, and publishing did not — it waited for the
    # fifteen-minute ticker, which dies with the process. So a seller sitting in
    # front of the app watching a post's time come and go saw nothing happen,
    # and had no reason to think opening it would help.
    try:
        publisher.kick(email)
    except Exception:  # noqa: BLE001
        pass
    tag = f'W/"{hashlib.md5((cache.stamp(email) + _home_fingerprint(email)).encode()).hexdigest()}"'
    # Private: this is one seller's data and must never be held by a shared
    # proxy. no-cache means "revalidate every time", not "do not store" — the
    # browser keeps the body and we answer 304 when it is still good.
    response.headers["Cache-Control"] = "private, no-cache"
    response.headers["ETag"] = tag
    if if_none_match and if_none_match.strip() == tag:
        return Response(status_code=304, headers={
            "ETag": tag, "Cache-Control": "private, no-cache"})
    return _smart_status_payload(email, bind_session(get_session(x_session_id), email))


@app.get("/api/smart/history")
def smart_history(authorization: str | None = Header(default=None)):
    """Full approved + dismissed history, newest first."""
    email = require_user(authorization)
    return smart.build_history(email)


@app.post("/api/smart/upload")
async def smart_upload(kind: str, files: list[UploadFile] = File(...),
                       x_session_id: str | None = Header(default=None),
                       authorization: str | None = Header(default=None)):
    """Stage one or more Sales (or Review) files for mapping. Multiple files are
    combined: Sales via the auto-joiner, Reviews by stacking rows."""
    email = require_user(authorization)
    if kind not in ("sales", "review", "supply_sales"):
        raise HTTPException(400, "kind must be 'sales', 'supply_sales' or 'review'")
    if len(files) > 100:
        raise HTTPException(400, "Please upload at most 100 files at a time.")
    sess = bind_session(get_session(x_session_id), email)
    dfs = []
    names = []
    for f in files:
        ext = os.path.splitext(f.filename or "")[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            raise HTTPException(400, f"{f.filename}: unsupported type. Use CSV, TSV, Excel or JSON.")
        content = await f.read()
        try:
            parsed = _read_any_table(f.filename or "file", content)
        except Exception as e:
            raise HTTPException(400, f"Could not read {f.filename}: {e}")
        for label, df in parsed:
            if df.empty or len(df.columns) == 0:
                continue
            dfs.append(df)
            names.append(label)
    if not dfs:
        raise HTTPException(400, "No readable data found in the uploaded file(s).")

    if kind in ("sales", "supply_sales"):
        if len(dfs) == 1:
            combined = dfs[0]
        else:
            raw = {f"f{i}": d for i, d in enumerate(dfs)}
            nm = {f"f{i}": names[i] for i in range(len(dfs))}
            joined = joiner.auto_join(raw, nm)
            combined = joined[0] if joined else pd.concat(dfs, ignore_index=True)
        pending_key = "smart_pending_supply_sales" if kind == "supply_sales" else "smart_pending_sales"
        sess.raw_dfs[pending_key] = combined
        pos = pos_formats.detect_format(combined)
        suggested = mapper.suggest_mapping(combined)
        if pos and pos["mapping"].get("date") and pos["mapping"].get("amount"):
            suggested = {**suggested, **pos["mapping"]}
        try:
            _st = smart.data_status(email).get(kind, {})
            existing_rows = int(_st.get("rows", 0)) if _st.get("ready") else 0
        except Exception:
            existing_rows = 0
        return {"kind": kind, "files": names, "rows": int(len(combined)),
                "columns": [str(c) for c in combined.columns],
                "roles": list(mapper.ROLE_KEYWORDS), "required": ["date", "amount"],
                "suggested_mapping": suggested, "existing_rows": existing_rows,
                # Named when we recognised the export outright, so the mapping
                # screen can say "this is a Shopify export, here is the whole
                # mapping" instead of showing column-by-column guesses.
                "preset": suggested.get("_preset_name", ""),
                "preview": combined.head(6).astype(str).values.tolist()}
    else:
        combined = pd.concat(dfs, ignore_index=True) if len(dfs) > 1 else dfs[0]
        sess.raw_dfs["smart_pending_review"] = combined
        suggested = {
            "review": positioning.detect_review_column(combined),
            "rating": positioning.detect_rating_column(combined),
            "date": None,
        }
        for c in combined.columns:
            if "date" in str(c).lower():
                suggested["date"] = str(c); break
        try:
            _st = smart.data_status(email).get("review", {})
            existing_rows = int(_st.get("rows", 0)) if _st.get("ready") else 0
        except Exception:
            existing_rows = 0
        return {"kind": "review", "files": names, "rows": int(len(combined)),
                "columns": [str(c) for c in combined.columns],
                "roles": REVIEW_ROLES, "required": ["review"],
                "suggested_mapping": suggested, "existing_rows": existing_rows,
                "preview": combined.head(6).astype(str).values.tolist()}


class SmartMapBody(BaseModel):
    kind: str
    mapping: dict
    mode: str = "replace"   # "replace" overwrites saved data; "append" adds records


@app.post("/api/smart/map")
def smart_map(body: SmartMapBody, x_session_id: str | None = Header(default=None),
              authorization: str | None = Header(default=None)):
    """Confirm the mapping, build the dataset and persist it to the account."""
    email = require_user(authorization)
    sess = bind_session(get_session(x_session_id), email)
    if body.kind in ("sales", "supply_sales"):
        is_supply = body.kind == "supply_sales"
        pending_key = "smart_pending_supply_sales" if is_supply else "smart_pending_sales"
        pending = sess.raw_dfs.get(pending_key)
        if pending is None:
            raise HTTPException(400, "Upload a sales file first.")
        try:
            txns, diag = mapper.build_transactions(pending, body.mapping)
        except ValueError as e:
            raise HTTPException(400, str(e))
        if diag["rows_after"] == 0:
            raise HTTPException(400, "None of the rows had a readable date and amount, check your mapping.")
        if is_supply:
            smart.save_supply_sales(email, txns,
                                    {"files": sess.file_names.get(pending_key, "Supply sales upload")},
                                    mode=body.mode)
            combined = smart.load_supply_sales(email)
            total = int(len(combined)) if combined is not None else diag["rows_after"]
            replenish.after_sales(email, "past sales uploaded")
        else:
            smart.save_sales(email, txns,
                             {"files": sess.file_names.get(pending_key, "Sales upload")},
                             mode=body.mode)
            replenish.after_sales(email, "sales upload")
            combined = smart.load_sales(email)
            sess.txns_df = combined if combined is not None else txns
            sess.mapped_file_id = "smart_sales"
            total = int(len(sess.txns_df)) if sess.txns_df is not None else diag["rows_after"]
        sess.raw_dfs.pop(pending_key, None)
        return {"ok": True, "kind": body.kind, "rows": total,
                "added": diag["rows_after"], "mode": body.mode,
                "data": smart.data_status(email), "insights": smart.build_insights(email)}
    elif body.kind == "review":
        pending = sess.raw_dfs.get("smart_pending_review")
        if pending is None:
            raise HTTPException(400, "Upload a Review file first.")
        m = body.mapping or {}
        if not m.get("review"):
            raise HTTPException(400, "Map the review-text column (required).")
        rename = {}
        if m.get("review"): rename[m["review"]] = "Review"
        if m.get("rating"): rename[m["rating"]] = "Rating"
        if m.get("date"): rename[m["date"]] = "Date"
        df = pending.copy()
        # When re-mapping already-saved data, drop stale canonical columns so
        # we don't end up with two columns both named "Review"/"Rating"/"Date".
        for src, tgt in ((m.get("review"), "Review"), (m.get("rating"), "Rating"), (m.get("date"), "Date")):
            if tgt in df.columns and src != tgt:
                df = df.drop(columns=[tgt])
        df = df.rename(columns=rename)
        smart.save_review(email, df, {}, mode=body.mode)
        sess.raw_dfs.pop("smart_pending_review", None)
        combined = smart.load_review(email)
        total = int(len(combined)) if combined is not None else int(len(df))
        return {"ok": True, "kind": "review", "rows": total,
                "added": int(len(df)), "mode": body.mode,
                "data": smart.data_status(email), "insights": smart.build_insights(email)}
    raise HTTPException(400, "kind must be 'sales' or 'review'")


@app.get("/api/smart/remap")
def smart_remap(kind: str, x_session_id: str | None = Header(default=None),
                authorization: str | None = Header(default=None)):
    """Re-open the column mapping for data already saved to the account, so the
    user can adjust which column is which later without re-uploading a file."""
    email = require_user(authorization)
    sess = bind_session(get_session(x_session_id), email)
    if kind in ("sales", "supply_sales"):
        df = smart.load_supply_sales(email) if kind == "supply_sales" else smart.load_sales(email)
        if df is None or getattr(df, "empty", True):
            raise HTTPException(400, "Upload a sales file first.")
        sess.raw_dfs["smart_pending_supply_sales" if kind == "supply_sales" else "smart_pending_sales"] = df
        suggested = mapper.suggest_mapping(df)
        pos = pos_formats.detect_format(df)
        if pos and pos["mapping"].get("date") and pos["mapping"].get("amount"):
            suggested = {**suggested, **pos["mapping"]}
        return {"kind": kind, "files": [], "rows": int(len(df)),
                "columns": [str(c) for c in df.columns],
                "roles": list(mapper.ROLE_KEYWORDS), "required": ["date", "amount"],
                "suggested_mapping": suggested,
                "preview": df.head(6).astype(str).values.tolist()}
    elif kind == "review":
        df = smart.load_review(email)
        if df is None or getattr(df, "empty", True):
            raise HTTPException(400, "Upload a Review file first.")
        sess.raw_dfs["smart_pending_review"] = df
        suggested = {
            "review": positioning.detect_review_column(df),
            "rating": positioning.detect_rating_column(df),
            "date": None,
        }
        for c in df.columns:
            if "date" in str(c).lower():
                suggested["date"] = str(c); break
        return {"kind": "review", "files": [], "rows": int(len(df)),
                "columns": [str(c) for c in df.columns],
                "roles": REVIEW_ROLES, "required": ["review"],
                "suggested_mapping": suggested,
                "preview": df.head(6).astype(str).values.tolist()}
    raise HTTPException(400, "kind must be 'sales' or 'review'")


@app.post("/api/smart/clear")
def smart_clear(kind: str, x_session_id: str | None = Header(default=None),
                authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    smart.clear(email, kind)
    # Cascade: also wipe the data from the live browser session so it disappears
    # from every module immediately, not just from the saved copy.
    try:
        sess = bind_session(get_session(x_session_id), email)
        if kind == "sales":
            sess.txns_df = None
            sess.mapped_file_id = None
            for k in list(sess.raw_dfs.keys()):
                if k.startswith("smart_pending_sales") or k.startswith("pos_"):
                    sess.raw_dfs.pop(k, None)
        elif kind == "review":
            sess.raw_dfs.pop("smart_pending_review", None)
        elif kind == "supply_sales":
            sess.raw_dfs.pop("smart_pending_supply_sales", None)
    except HTTPException:
        pass
    return {"ok": True, "data": smart.data_status(email)}


# ---------------------------------------------------------
# Manual record entry — type new rows into the saved schema and append them
# ---------------------------------------------------------
def _smart_columns(df) -> list[dict]:
    """Describe a saved dataset's columns for the Add-record grid."""
    cols = []
    for c in df.columns:
        srs = df[c]
        if pd.api.types.is_datetime64_any_dtype(srs):
            t = "date"
        elif pd.api.types.is_numeric_dtype(srs):
            t = "number"
        else:
            t = "text"
        cols.append({"name": str(c), "type": t})
    return cols


@app.get("/api/smart/schema")
def smart_schema(kind: str, authorization: str | None = Header(default=None)):
    """Columns of the account's saved Sales/Review data, for the type-in grid."""
    email = require_user(authorization)
    if kind not in ("sales", "review"):
        raise HTTPException(400, "kind must be 'sales' or 'review'")
    df = smart.load_sales(email) if kind == "sales" else smart.load_review(email)
    if df is None or getattr(df, "empty", True):
        raise HTTPException(400, "No saved data yet, upload a file first.")
    required = ["date", "amount"] if kind == "sales" else ["Review"]
    return {"kind": kind, "columns": _smart_columns(df),
            "required": [r for r in required if r in df.columns]}


class SmartRecordsBody(BaseModel):
    kind: str
    rows: list[dict]


@app.post("/api/smart/records/add")
def smart_records_add(body: SmartRecordsBody,
                      x_session_id: str | None = Header(default=None),
                      authorization: str | None = Header(default=None)):
    """Append manually-typed rows to the saved Sales/Review dataset."""
    email = require_user(authorization)
    if body.kind not in ("sales", "review"):
        raise HTTPException(400, "kind must be 'sales' or 'review'")
    saved = smart.load_sales(email) if body.kind == "sales" else smart.load_review(email)
    if saved is None or getattr(saved, "empty", True):
        raise HTTPException(400, "No saved data yet, upload a file first.")

    cols = list(saved.columns)
    clean = []
    for r in (body.rows or []):
        row = {c: (r.get(str(c)) if r.get(str(c)) not in ("", None) else None) for c in cols}
        if all(v is None for v in row.values()):
            continue
        clean.append(row)
    if not clean:
        raise HTTPException(400, "Please fill in at least one row.")
    new_df = pd.DataFrame(clean, columns=cols)

    if body.kind == "sales":
        if "date" in new_df.columns:
            new_df["date"] = mapper._parse_dates_robust(new_df["date"])
        if "amount" in new_df.columns:
            new_df["amount"] = mapper._clean_numeric(new_df["amount"])
        if "quantity" in new_df.columns:
            new_df["quantity"] = mapper._clean_numeric(new_df["quantity"])
        need = [c for c in ("date", "amount") if c in new_df.columns]
        if need:
            new_df = new_df.dropna(subset=need)
        if new_df.empty:
            raise HTTPException(400, "Each row needs a valid date and amount.")
        smart.save_sales(email, new_df, {"files": "Manual entry"}, mode="append")
        replenish.after_sales(email, "sales added by hand")
        combined = smart.load_sales(email)
        try:
            sess = bind_session(get_session(x_session_id), email)
            sess.txns_df = combined
            sess.mapped_file_id = "smart_sales"
        except HTTPException:
            pass
    else:
        if "Rating" in new_df.columns:
            new_df["Rating"] = pd.to_numeric(new_df["Rating"], errors="coerce")
        if "Review" in new_df.columns:
            new_df = new_df[new_df["Review"].astype(str).str.strip() != ""]
        if new_df.empty:
            raise HTTPException(400, "Each row needs review text.")
        smart.save_review(email, new_df, {}, mode="append")
        combined = smart.load_review(email)

    total = int(len(combined)) if combined is not None else int(len(new_df))
    return {"ok": True, "kind": body.kind, "added": int(len(new_df)), "rows": total,
            "data": smart.data_status(email), "insights": smart.build_insights(email)}


# ---------------------------------------------------------
# Commerce connectors (Shopify / Amazon) — encrypted, per-account linking
# ---------------------------------------------------------
class CommerceConnectBody(BaseModel):
    connector: str
    credentials: dict


class CommercePullBody(BaseModel):
    connector: str
    days: int = 90


@app.get("/api/commerce/status")
def commerce_status(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    out = []
    for c in commerce.catalog():
        meta = secrets_store.connection_meta(email, c["id"]) or {}
        out.append({**c, "connected": secrets_store.is_connected(email, c["id"]),
                    "account": meta.get("account"), "connected_at": meta.get("connected_at")})
    return {"connectors": out}


@app.post("/api/commerce/connect")
def commerce_connect(body: CommerceConnectBody,
                     authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    creds = {k: (str(v).strip() if v is not None else "") for k, v in (body.credentials or {}).items()}
    try:
        info = commerce.test_connection(body.connector, creds)
    except commerce.CommerceError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Could not reach {body.connector}: {e}")
    secrets_store.save_connection(email, body.connector, creds, {
        "account": info.get("account") or info.get("name"),
        "connected_at": pd.Timestamp.now().isoformat(timespec="seconds"),
    })
    return {"ok": True, "connector": body.connector, "account": info.get("account") or info.get("name")}


@app.post("/api/commerce/disconnect")
def commerce_disconnect(body: CommerceConnectBody,
                        authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    secrets_store.delete_connection(email, body.connector)
    return {"ok": True}


@app.post("/api/commerce/pull")
def commerce_pull(body: CommercePullBody, x_session_id: str | None = Header(default=None),
                  authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    creds = secrets_store.get_credentials(email, body.connector)
    if not creds:
        raise HTTPException(400, f"Connect {body.connector} first.")
    try:
        df = commerce.pull_orders(body.connector, creds, days=body.days)
    except commerce.CommerceError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Pull failed: {e}")
    # Build canonical transactions and save as the account's Sales dataset.
    mapping = {c: c for c in df.columns}
    try:
        txns, diag = mapper.build_transactions(df, mapping)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if diag["rows_after"] == 0:
        raise HTTPException(400, "Orders pulled but none had a usable date + amount.")
    smart.save_sales(email, txns, {"files": f"🔌 {body.connector} ({body.days}d)"})
    replenish.after_sales(email, f"orders pulled from {body.connector}")
    sess = get_session(x_session_id)
    sess.txns_df = txns
    sess.mapped_file_id = "smart_sales"
    return {"ok": True, "connector": body.connector, "rows": diag["rows_after"],
            "data": smart.data_status(email), "insights": smart.build_insights(email)}


# ---------------------------------------------------------
# Content — export the approved post to the seller's device (image + caption)
# ---------------------------------------------------------
@app.get("/api/content/asset")
def content_asset(insight_id: str, kind: str = "image", request: Request = None,
                  authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    sug = smart.get_or_generate_content(email, insight_id, force=False)
    if not sug:
        raise HTTPException(404, "That suggestion is no longer active, refresh the panel.")
    topic = (sug.get("topic") or "post").strip().replace(" ", "_")[:40] or "post"
    if kind == "text":
        tags = " ".join("#" + str(t).strip().lstrip("#") for t in (sug.get("hashtags") or []) if str(t).strip())
        body = (sug.get("caption") or "")
        if tags:
            body += "\n\n" + tags
        if sug.get("description"):
            body += "\n\n---\n" + sug["description"]
        return Response(content=body.strip() + "\n", media_type="text/plain; charset=utf-8",
                        headers={"Content-Disposition": f'attachment; filename="{topic}.txt"'})
    # image
    url = sug.get("image_url") or ""
    if not url:
        raise HTTPException(400, "This post has no image yet, open the editor to generate or upload one.")
    data = None
    ctype = "image/png"
    ext = "png"
    if url.startswith("/generated_images/"):
        got = media.read(os.path.basename(url))
        if got:
            data, _ct = got
            ext = (os.path.splitext(url)[1].lstrip(".") or "png").lower()
    if data is None:
        # remote or app-absolute URL — fetch it server-side
        try:
            import requests as _rq
            full = url if url.startswith("http") else (_public_base_url(request) + url if request else url)
            rr = _rq.get(full, timeout=25)
            rr.raise_for_status()
            data = rr.content
            ctype = rr.headers.get("Content-Type", "image/png").split(";")[0]
            ext = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp"}.get(ctype, "png")
        except Exception as e:
            raise HTTPException(400, f"Could not fetch the image: {e}")
    ctype = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp"}.get(ext, ctype)
    return Response(content=data, media_type=ctype,
                    headers={"Content-Disposition": f'attachment; filename="{topic}.{ext}"'})


@app.get("/api/smart/positioning")
def smart_positioning(lang: str = "en", authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    df = smart.load_review(email)
    if df is None:
        return _NEEDS_REVIEWS
    return positioning.analyze_reviews(df, lang, product_type=smart.get_product_type(email))


@app.get("/api/smart/complaints")
def smart_complaints(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    df = smart.load_review(email)
    if df is None:
        return _NEEDS_REVIEWS
    return complaints.analyze_complaints(df, product_type=smart.get_product_type(email))


@app.post("/api/smart/strategy/detect")
def smart_strategy_detect(lang: str = "en", authorization: str | None = Header(default=None)):
    """Auto-detect the current position from the account's SAVED reviews
    (no re-upload) and persist it, then return the full strategy view."""
    email = require_user(authorization)
    df = smart.load_review(email)
    if df is None:
        return _NEEDS_REVIEWS
    data = positioning.analyze_reviews(df, lang, product_type=smart.get_product_type(email))
    if not data.get("available"):
        raise HTTPException(400, data.get("reason", "Not enough review data to detect a position."))
    quadrant = (data.get("perceptual_map", {}).get("you", {}) or {}).get("quadrant")
    current_id = position_strategy.QUADRANT_TO_ID.get(quadrant)
    if not current_id:
        raise HTTPException(400, "Couldn't map your reviews to a position.")
    st = user_store.get_key(email, "position_strategy", {}) or {}
    if st.get("current_id") != current_id:
        st["target_id"] = None
        st["checked"] = []
    st.update({"current_id": current_id, "n_reviews": data.get("n_reviews"),
               "detected_at": pd.Timestamp.now().isoformat(timespec="seconds")})
    user_store.set_key(email, "position_strategy", st)
    return _ps_view(email)


class SmartDecisionBody(BaseModel):
    decision: str  # approve | disapprove | reset


@app.post("/api/smart/insight/{insight_id}/decision")
def smart_decision(insight_id: str, body: SmartDecisionBody,
                   authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    # Social posts are decided here too (one Approval panel, not two), but
    # their state lives in social.py's own post store, not smart_decisions --
    # the post's state field IS the decision, so there's nothing to snapshot
    # into History and no "insight" bookkeeping to do. Both branches return
    # early with the same shape the normal path returns.
    if str(insight_id).startswith("po_"):
        # A purchase order the replenishment check drafted. Approve sends it
        # (the email as last drafted or edited in Details); Cancel cancels it.
        po_number = insight_id[len("po_"):]
        send = None
        if body.decision == "approve":
            try:
                send = replenish.send_po(email, po_number)
            except ValueError as e:
                raise HTTPException(400, str(e))
        elif body.decision in ("disapprove", "cancel"):
            out = replenish.cancel_po(email, po_number)
            if out.get("error"):
                raise HTTPException(404, out["error"])
        cache.clear(email)
        return {"ok": True, "download": False, "download_url": None, "send": send,
                "insights": smart.build_insights(email),
                "history": smart.build_history(email),
                "tasks": smart.get_tasks(email)}
    if str(insight_id).startswith("autoplan_"):
        # The header card over an auto-planned week. Approve runs every one of
        # its posts through the same approve-and-make-ready path as the single
        # card; Cancel turns the whole week down.
        week = insight_id[len("autoplan_"):]
        results = []
        if body.decision == "approve":
            for p in list(social._posts(email)):
                if (p.get("source") == "autoplan" and p.get("autoplan_week") == week
                        and p.get("state") == "draft"):
                    results.append(_approve_post_ready(email, p["id"]))
        elif body.decision in ("disapprove", "cancel"):
            autoplan.cancel_week(email, week)
        cache.clear(email)
        return {"ok": True, "download": False, "download_url": None,
                "results": [{"post_id": r["post"]["id"], "state": r["post"]["state"],
                             "is_reel": r["is_reel"], "media_error": r["media_error"]}
                            for r in results if r.get("post")],
                "insights": smart.build_insights(email),
                "history": smart.build_history(email),
                "tasks": smart.get_tasks(email)}
    if str(insight_id).startswith("post_"):
        post_id = insight_id[len("post_"):]
        if body.decision == "approve":
            p = social.set_state(email, post_id, "scheduled")
        elif body.decision == "disapprove":
            p = social.set_state(email, post_id, "failed")
        elif body.decision == "cancel":
            p = social.set_state(email, post_id, "cancelled")
        else:
            return {"ok": True, "insights": smart.build_insights(email),
                    "history": smart.build_history(email)}
        if p.get("error"):
            raise HTTPException(404, p["error"])
        return {"ok": True, "download": False, "download_url": None,
                "insights": smart.build_insights(email),
                "history": smart.build_history(email),
                "tasks": smart.get_tasks(email)}
    if body.decision == "approve":
        # Capture the title BEFORE flipping the state, because after set_decision
        # this insight is no longer in the active list.
        title = next((i["title"] for i in smart.build_insights(email) if i["id"] == insight_id), None)
        if insight_id == "reorder":
            # Draft one PO per supplier through the same replenishment path an
            # order triggers — they come back as purchase-order cards to check
            # and send, instead of a download nobody sends.
            replenish.check(email, trigger="insight")
        if insight_id == "winback_auto":
            # This card is the only one that puts a message in front of a
            # customer, so it reports what actually happened rather than a
            # cheerful "approved". A partial send (some had no email, WhatsApp
            # not connected) is normal and is stated, not hidden.
            try:
                res = winback_auto.approve(email)
            except ValueError as e:
                raise HTTPException(400, str(e))
            smart.set_decision(email, insight_id, "approved")
            return {"ok": True, "download": False, "download_url": None,
                    "sent": res.get("summary", ""), "result": res,
                    "insights": smart.build_insights(email),
                    "history": smart.build_history(email),
                    "tasks": smart.get_tasks(email)}
        smart.set_decision(email, insight_id, "approved")
        if str(insight_id).startswith("content_"):
            smart.clear_content_suggestion(email)   # rotate a fresh suggestion in
        if title:
            smart.add_task(email, f"Execute: {title}")
        has_file = smart.insight_excel(email, insight_id) is not None
        return {"ok": True, "download": has_file,
                "download_url": f"/api/smart/insight/{insight_id}/download" if has_file else None,
                "insights": smart.build_insights(email),
                "history": smart.build_history(email),
                "tasks": smart.get_tasks(email)}
    elif body.decision == "disapprove":
        if insight_id == "reorder":
            supply.mark_reorder_handled(email, "dismissed")
        smart.set_decision(email, insight_id, "dismissed")
        return {"ok": True,
                "insights": smart.build_insights(email),
                "history": smart.build_history(email)}
    else:
        if insight_id == "reorder":
            supply.clear_reorder_handled(email)
        smart.reset_decision(email, insight_id)
        return {"ok": True,
                "insights": smart.build_insights(email),
                "history": smart.build_history(email)}


class WinbackAutoBody(BaseModel):
    enabled: bool | None = None
    day: int | None = None
    hour: int | None = None


@app.get("/api/winback/auto")
def winback_auto_status(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {**winback_auto.status(email), "day_names": winback_auto.DAY_NAMES}


@app.post("/api/winback/auto")
def winback_auto_save(body: WinbackAutoBody,
                      authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    patch = {k: v for k, v in body.dict().items() if v is not None}
    return {**winback_auto.save_config(email, patch),
            "day_names": winback_auto.DAY_NAMES}


@app.post("/api/winback/auto/run")
def winback_auto_run_now(authorization: str | None = Header(default=None)):
    """Run this week's scan now instead of waiting for the trigger. Prepares
    the batch; it still waits for approval before anything is sent."""
    email = require_user(authorization)
    res = winback_auto.run_if_due(email, trigger="manual")
    return {"run": res, "status": winback_auto.status(email),
            "insights": smart.build_insights(email)}


@app.post("/api/winback/auto/skip")
def winback_auto_skip(authorization: str | None = Header(default=None)):
    """Throw this week's batch away without sending it. The customers in it are
    NOT marked as contacted, so they are eligible again next week."""
    email = require_user(authorization)
    winback_auto.clear_pending(email)
    return {"ok": True, "status": winback_auto.status(email),
            "insights": smart.build_insights(email)}


@app.get("/api/smart/insight/{insight_id}/download")
def smart_insight_download(insight_id: str, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    result = smart.insight_excel(email, insight_id)
    if not result:
        raise HTTPException(400, "Nothing to export for this insight, the data may have changed.")
    filename, buf = result
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"})


class SmartTaskBody(BaseModel):
    action: str          # add | toggle | delete | progress
    text: str | None = None
    task_id: str | None = None
    done: bool | None = None
    step: str | None = None


@app.post("/api/smart/tasks")
def smart_tasks(body: SmartTaskBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    if body.action == "add":
        tasks = smart.add_task(email, body.text or "")
    elif body.action == "toggle":
        tasks = smart.toggle_task(email, body.task_id or "", bool(body.done))
    elif body.action == "delete":
        tasks = smart.delete_task(email, body.task_id or "")
    elif body.action == "progress":
        tasks = smart.task_progress(email, body.task_id or "", body.step or "",
                                    True if body.done is None else bool(body.done))
    else:
        raise HTTPException(400, "action must be add, toggle, delete or progress")
    return {"ok": True, "tasks": tasks}


# ---------------------------------------------------------
# The first-run journey ("Set up your shop in 3 parts")
# ---------------------------------------------------------
# Design: docs/designs/first-run-journey.md. The journey has its own simple
# screens, but every save below writes the same data the modules own, and a
# step only counts as done when that data says so (core/onboarding.py).
class OnboardingActBody(BaseModel):
    action: str
    path: str | None = None
    step: str | None = None
    part: int | None = None
    lang: str | None = None


def _journey(email: str, fresh: dict | None = None) -> dict:
    prog = fresh if fresh is not None else onboarding.progress(email)
    return {**prog, "facts": onboarding.journey_facts(email)}


@app.get("/api/onboarding")
def onboarding_get(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return _journey(email)


@app.post("/api/onboarding")
def onboarding_act(body: OnboardingActBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        prog = onboarding.act(email, body.action, path=body.path, step=body.step,
                              part=body.part, lang=body.lang)
    except onboarding.OnboardingError as e:
        raise HTTPException(400, str(e))
    return {**_journey(email, prog), "tasks": smart.get_tasks(email)}


@app.post("/api/onboarding/save/{what}")
def onboarding_save(what: str, body: dict, authorization: str | None = Header(default=None)):
    """The journey's simple screens. Each writes the real module data."""
    email = require_user(authorization)
    cache.clear(email)
    try:
        if what == "shop":
            onboarding.save_shop(email, body.get("name") or "", body.get("product_type") or "",
                                 body.get("label") or "")
        elif what == "site":
            onboarding.save_site(email, body or {})
        elif what == "publish":
            sitebuilder.set_published(email, True)
        elif what == "payment":
            onboarding.save_payment(email, body.get("upi_id") or "", bool(body.get("rupees")))
        elif what == "photo":
            onboarding.set_product_photo(email, body.get("product_id") or "", body.get("url") or "")
        elif what == "stock":
            onboarding.save_stock(email, body.get("supplier") or {}, body.get("counts") or {})
        elif what == "import":
            onboarding.import_sales_products(email)
        else:
            raise HTTPException(404, "Unknown step.")
    except (onboarding.OnboardingError, ValueError) as e:
        raise HTTPException(400, str(e))
    return {**_journey(email, onboarding.reconcile(email)), "tasks": smart.get_tasks(email)}


class UpiConfirmBody(BaseModel):
    order_id: str
    received: bool


@app.post("/api/orders/upi")
def orders_upi(body: UpiConfirmBody, authorization: str | None = Header(default=None)):
    """The seller checked their own UPI app: the money arrived, or it did not."""
    email = require_user(authorization)
    cache.clear(email)
    try:
        order = storefront.confirm_upi_payment(email, body.order_id, body.received)
    except storefront.StoreError as e:
        raise HTTPException(400, str(e))
    return {"order": order}


# ---------------------------------------------------------
# Supply Management  (inventory -> EOQ/MOQ reorder -> purchase order PDF)
# ---------------------------------------------------------
class SupplyItemBody(BaseModel):
    id: str | None = None
    name: str
    category: str | None = ""
    unit_label: str | None = "unit"
    current_stock: float | None = 0
    lead_time_days: float | None = 0
    safety_stock: float | None = 0
    moq: float | None = 0
    ordering_cost: float | None = None
    holding_cost: float | None = None
    unit_cost: float | None = None
    reorder_qty: float | None = None
    supplier_name: str | None = ""
    supplier_phone: str | None = ""
    supplier_email: str | None = ""
    # Add Item picks the product this raw material goes into (from Product
    # Management) and how much of it one unit of that product uses; saving the
    # item also saves that link, which is what turns product sales into
    # raw-material consumption.
    link_product: str | None = ""
    qty_per_unit: float | None = None


class SupplyIdBody(BaseModel):
    id: str


class SupplyWasteBody(BaseModel):
    inventory_id: str
    qty: float
    reason: str | None = ""


class SupplyMapBody(BaseModel):
    product: str
    inventory_id: str
    qty_per_unit: float | None = 1


class SupplyMapIdBody(BaseModel):
    id: str


class SupplyPOBody(BaseModel):
    item_ids: list[str] | None = None


def _supply_payload(email: str) -> dict:
    comp = supply.compute_inventory(email)
    try:
        covered = replenish.covered_item_ids(email)
    except Exception:  # noqa: BLE001
        covered = set()
    for r in comp["items"]:
        r["on_order"] = r["id"] in covered
    return {
        "inventory": comp["items"], "below": comp["below"], "meta": comp["meta"],
        "n_below": comp["n_below"],
        # items below the DOS rule that are NOT already on an active PO — the
        # ones that still need an order form
        "suggestions": [r for r in comp["below"] if r["id"] not in covered],
        "n_on_order": sum(1 for r in comp["below"] if r["id"] in covered),
        "products": supply.get_products(email),
        # Product Management's own records, for the Add Item product picker
        "catalog": [{"id": p["id"], "name": p["name"], "category": p.get("category") or ""}
                    for p in products.get_products(email) if p.get("status") != "archived"],
        "suppliers": supply.get_suppliers(email),
        "maps": supply.get_maps(email),
        "waste": supply.get_waste(email),
        "purchase_orders": supply.get_purchase_orders(email),
        "replenish_log": replenish.recent_log(email),
        "signature": supply.get_signature(email),
        "mail_account": seller_mail.status(email),
        "po_flow": {"statuses": supply.PO_STATUSES, "next": supply.PO_NEXT,
                    "labels": supply.PO_STATUS_LABELS},
        "email_ready": messaging.smtp_configured(),
        "rule": {"dos_multiple": supply.DOS_LEAD_MULTIPLE,
                 "eoq_min_days": supply.EOQ_MIN_DAYS,
                 "window_days": supply.RECENT_WINDOW_DAYS},
        "insights": smart.build_insights(email),
    }


@app.get("/api/supply/suppliers")
def supply_suppliers(authorization: str | None = Header(default=None)):
    """Suppliers, derived from the inventory items they stock."""
    return {"suppliers": supply.get_suppliers(require_user(authorization))}


@app.post("/api/supply/supplier")
def supply_supplier_save(body: SupplierBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    try:
        return {"suppliers": supply.upsert_supplier(email, body.name, body.patch or {})}
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/supply/supplier/detach")
def supply_supplier_detach(body: SupplierBody, authorization: str | None = Header(default=None)):
    """Clears the supplier from every item and hands back the ids, so the undo
    can put them back — once the last item is cleared there is no supplier left
    to look up by name."""
    email = require_user(authorization)
    cache.clear(email)
    return supply.detach_supplier(email, body.name)


@app.post("/api/supply/supplier/attach")
def supply_supplier_attach(body: SupplierBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    ids = (body.patch or {}).get("item_ids") or []
    return {"suppliers": supply.attach_supplier(email, ids, body.patch or {})}


@app.get("/api/supply/state")
def supply_state(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return _supply_payload(email)


class LocaleBody(BaseModel):
    country: str


@app.get("/api/settings/locale")
def locale_get(authorization: str | None = Header(default=None)):
    """Which country this account schedules in, and the list to pick from."""
    email = require_user(authorization)
    return {**localtime.get(email), "label": localtime.label(email),
            "now": localtime.now(email).strftime("%a %d %b, %I:%M %p").replace(" 0", " "),
            "options": localtime.options()}


@app.post("/api/settings/locale")
def locale_set(body: LocaleBody, authorization: str | None = Header(default=None)):
    """Change it. Every scheduled time in the app is wall-clock time here, so
    this moves the weekly planner's trigger and every new post's slot with it."""
    email = require_user(authorization)
    try:
        localtime.set_country(email, body.country)
    except ValueError as e:
        raise HTTPException(400, str(e))
    cache.clear(email)
    return {**localtime.get(email), "label": localtime.label(email),
            "now": localtime.now(email).strftime("%a %d %b, %I:%M %p").replace(" 0", " "),
            "options": localtime.options()}


# =========================================================================
# The Account tab — every setup setting in one place
# =========================================================================
class AccountSettingsBody(BaseModel):
    country: str | None = None
    selling_country: str | None = None
    currency: str | None = None


class AiKeyBody(BaseModel):
    provider: str            # "openai" | "gemini"
    api_key: str | None = ""


@app.get("/api/account")
def account_get(authorization: str | None = Header(default=None)):
    """One payload for the whole Account tab: where the seller is, where and in
    what currency they sell, their sender email, Instagram, payment gateway and
    any own AI keys — each as a connected/not-connected state, never a secret."""
    from backend.core import account
    return account.summary(require_user(authorization))


@app.post("/api/account/settings")
def account_settings(body: AccountSettingsBody,
                     authorization: str | None = Header(default=None)):
    """Save the market settings. Changing the currency also re-prices the
    seller's own storefront in it, and moving out of India clears any GST line
    (no tax outside India, by policy) so the two can never disagree."""
    from backend.core import account, currency as _ccy
    email = require_user(authorization)
    try:
        loc = localtime.set_settings(email, country=body.country,
                                     selling_country=body.selling_country,
                                     currency_code=body.currency)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # Keep the storefront's own currency and tax in step with the account.
    try:
        site = sitebuilder.get_site(email)
        c = dict(site.get("commerce") or {})
        changed = False
        if c.get("currency") != loc["currency"]:
            c["currency"] = loc["currency"]; changed = True
        if not loc["charges_tax"] and float(c.get("gst_percent") or 0) != 0:
            c["gst_percent"] = 0.0; changed = True     # no tax line outside India
        if changed:
            sitebuilder.save_site(email, {"commerce": c})
    except Exception:  # noqa: BLE001 — a seller with no storefront yet is fine
        pass
    cache.clear(email)
    return account.summary(email)


@app.post("/api/account/ai-key")
def account_ai_key(body: AiKeyBody, authorization: str | None = Header(default=None)):
    from backend.core import account
    email = require_user(authorization)
    try:
        return {"ok": True, "ai_keys": account.save_ai_key(email, body.provider, body.api_key or "")}
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.delete("/api/account/ai-key/{provider}")
def account_ai_key_delete(provider: str, authorization: str | None = Header(default=None)):
    from backend.core import account
    email = require_user(authorization)
    return {"ok": True, "ai_keys": account.remove_ai_key(email, provider)}


@app.post("/api/account/reset")
def account_reset(authorization: str | None = Header(default=None)):
    """Start over: wipe settings, storefront, products, tasks and uploaded data.
    The login and any purchased credits are kept, so the seller stays signed in
    on an empty workspace. Irreversible — the UI confirms before calling this."""
    from backend.core import account
    email = require_user(authorization)
    return account.reset(email)


@app.delete("/api/account/delete")
def account_delete(authorization: str | None = Header(default=None)):
    """Permanently remove the account and everything belonging to it, including
    the login. Irreversible — the UI requires a typed confirmation, and signs the
    seller out afterwards because their session no longer exists."""
    from backend.core import account
    email = require_user(authorization)
    return account.delete(email)


class SignatureBody(BaseModel):
    url: str = ""


@app.post("/api/supply/signature")
def supply_signature(body: SignatureBody, authorization: str | None = Header(default=None)):
    """The signature image printed on every purchase order. Optional — a PO
    without one still carries the shop's name and "authorised signatory"."""
    email = require_user(authorization)
    supply.set_signature(email, body.url)
    cache.clear(email)
    return _supply_payload(email)


# What the three review-based modules answer before any reviews exist. It
# used to be an HTTP 400, which the app drew as "Could not load this": an
# error screen for something that is simply not uploaded yet. A 200 with
# needs="review" lets the app draw an empty state with an upload button, and
# keeps a real 400 for a real problem (too few reviews to find a position).
_NEEDS_REVIEWS = {"needs": "review",
                  "message": "Upload your customer reviews once, and Review Analytics, "
                             "Complaint Analysis and Position Strategy all fill in from them."}


class SellerMailBody(BaseModel):
    address: str
    password: str
    host: str | None = ""
    port: int | None = 0
    display_name: str | None = ""
    provider: str | None = ""   # the button picked in the guide; see seller_mail.connect


@app.get("/api/mail/account")
def mail_account(authorization: str | None = Header(default=None)):
    """Which address this seller's purchase orders go out from."""
    email = require_user(authorization)
    st = seller_mail.status(email)
    # `providers` is the step-by-step guide the Account box draws, one entry per
    # provider button. The browser has no table of its own any more.
    return {**st, "guess": seller_mail.guess(st.get("address") or email),
            "providers": seller_mail.providers(),
            "domains": seller_mail.DOMAINS,
            "server_fallback": messaging.smtp_configured()}


@app.post("/api/mail/account")
def mail_account_connect(body: SellerMailBody,
                         authorization: str | None = Header(default=None)):
    """Connect the seller's own email. Saves only after a real login and a real
    test message to themselves, so "connected" means something arrived."""
    email = require_user(authorization)
    try:
        st = seller_mail.connect(email, body.address, body.password,
                                 body.host or "", int(body.port or 0),
                                 body.display_name or "", body.provider or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    cache.clear(email)
    return {**st, "server_fallback": messaging.smtp_configured()}


@app.delete("/api/mail/account")
def mail_account_disconnect(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    st = seller_mail.disconnect(email)
    cache.clear(email)
    return {**st, "server_fallback": messaging.smtp_configured()}


class PoCancelBody(BaseModel):
    po_number: str
    tell_supplier: bool = True
    note: str | None = ""


@app.post("/api/supply/po/cancel")
def supply_po_cancel(body: PoCancelBody, authorization: str | None = Header(default=None)):
    """Cancel a purchase order — including one already sent, in which case the
    supplier is told in writing rather than left to deliver it."""
    email = require_user(authorization)
    out = replenish.cancel_po(email, body.po_number, bool(body.tell_supplier),
                              body.note or "")
    if out.get("error"):
        raise HTTPException(404, out["error"])
    cache.clear(email)
    return {**_supply_payload(email), "told_supplier": out["told_supplier"],
            "was": out["was"], "po": out["po"]}


class PoMoveBody(BaseModel):
    po_number: str
    status: str
    note: str | None = ""


@app.post("/api/supply/po/move")
def supply_po_move(body: PoMoveBody, authorization: str | None = Header(default=None)):
    """Move a PO along its track: mailed → replied → confirmed → received.
    Receiving posts the ordered quantities back into stock."""
    email = require_user(authorization)
    po = supply.get_po(email, body.po_number)
    if not po:
        raise HTTPException(404, "Purchase order not found")
    allowed = supply.PO_NEXT.get(supply.po_status(po), [])
    if body.status not in allowed:
        raise HTTPException(400, f"A {supply.PO_STATUS_LABELS.get(supply.po_status(po), 'that')} "
                                 f"order can only go to: {', '.join(allowed) or 'nowhere, it is finished'}.")
    try:
        supply.set_po_status(email, body.po_number, body.status, body.note or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    cache.clear(email)
    payload = _supply_payload(email)
    payload["po"] = supply.get_po(email, body.po_number)
    return payload


@app.post("/api/supply/item")
def supply_item(body: SupplyItemBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    data = body.dict()
    link, qpu = (data.pop("link_product", "") or "").strip(), data.pop("qty_per_unit", None)
    try:
        cache.clear(email)
        before = {it["id"] for it in supply.get_inventory(email)}
        items = supply.upsert_item(email, data)
        if link:
            saved = next((it for it in items if it["id"] == body.id), None) if body.id else None
            if saved is None:
                new = [it for it in items if it["id"] not in before]
                saved = next((it for it in new if it["name"] == data["name"].strip()),
                             new[0] if new else None)
            if saved:
                supply.upsert_map(email, link, saved["id"], qpu if qpu and qpu > 0 else 1)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _supply_payload(email)


class SupplyDoqBody(BaseModel):
    id: str
    doq: float | None = None       # None/0 = go back to the worked-out DOQ


@app.post("/api/supply/doq")
def supply_doq(body: SupplyDoqBody, authorization: str | None = Header(default=None)):
    """The seller's own default order quantity for one raw material. Blank
    returns it to the worked-out value (MOQ, or EOQ when it applies)."""
    email = require_user(authorization)
    it = next((x for x in supply.get_inventory(email) if x["id"] == body.id), None)
    if not it:
        raise HTTPException(404, "Item not found.")
    it = dict(it)
    it["reorder_qty"] = body.doq if body.doq and body.doq > 0 else None
    supply.upsert_item(email, it)
    cache.clear(email)
    return _supply_payload(email)


@app.post("/api/supply/replenish/check")
def supply_replenish_check(authorization: str | None = Header(default=None)):
    """Run the days-of-supply check on every raw material now, drafting
    purchase orders where it fails — the same check every order triggers."""
    email = require_user(authorization)
    res = replenish.check(email, trigger="manual")
    return {**_supply_payload(email), "check": res}


class PoLinesBody(BaseModel):
    qty: dict = {}


class PoEmailBody(BaseModel):
    subject: str | None = None
    body: str | None = None
    to: str | None = None


def _po_or_404(email: str, po_number: str) -> dict:
    po = supply.get_po(email, po_number)
    if not po:
        raise HTTPException(404, "Purchase order not found.")
    return po


@app.get("/api/supply/po/{po_number}/detail")
def supply_po_detail(po_number: str, authorization: str | None = Header(default=None)):
    """Everything behind a drafted PO: the lines with each item's days of
    supply and how its quantity was worked out, the supplier, and the email
    the content writer drafted to send it with."""
    email = require_user(authorization)
    po = _po_or_404(email, po_number)
    rows = {r["id"]: r for r in supply.compute_inventory(email)["items"]}
    lines = []
    for ln in po.get("lines") or []:
        r = rows.get(ln.get("inventory_id")) or {}
        lines.append({**ln, "now": {k: r.get(k) for k in (
            "current_stock", "dos", "dos_threshold", "avg_daily_consumption",
            "effective_lead_time_days", "doq", "doq_basis", "eoq", "moq",
            "eoq_missing", "reason", "linked_products")}})
    try:
        draft = replenish.email_draft(email, po_number)
    except Exception as e:  # noqa: BLE001 — details still open without an email
        draft = {"subject": "", "body": "", "to": "", "error": str(e)}
    return {"po": {**po, "lines": lines}, "email": draft,
            "pdf_url": f"/api/supply/po/{po_number}/pdf?supplier=1",
            "email_ready": messaging.smtp_configured()}


@app.post("/api/supply/po/{po_number}/lines")
def supply_po_lines(po_number: str, body: PoLinesBody,
                    authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    _po_or_404(email, po_number)
    try:
        po = supply.set_po_line_qty(email, po_number, body.qty or {})
    except ValueError as e:
        raise HTTPException(400, str(e))
    cache.clear(email)
    return {"po": po}


@app.post("/api/supply/po/{po_number}/email")
def supply_po_email(po_number: str, body: PoEmailBody,
                    authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    _po_or_404(email, po_number)
    return {"email": replenish.save_email_draft(email, po_number, body.dict())}


@app.post("/api/supply/po/{po_number}/email/rewrite")
def supply_po_email_rewrite(po_number: str, authorization: str | None = Header(default=None)):
    """Ask the content writer for a fresh draft of the supplier email."""
    email = require_user(authorization)
    _po_or_404(email, po_number)
    return {"email": replenish.email_draft(email, po_number, refresh=True)}


@app.post("/api/supply/po/{po_number}/approve")
def supply_po_approve(po_number: str, body: PoEmailBody,
                      authorization: str | None = Header(default=None)):
    """Approve a drafted PO: the email (as edited, or as the writer drafted
    it) goes to the supplier with the PO attached as a PDF."""
    email = require_user(authorization)
    _po_or_404(email, po_number)
    try:
        res = replenish.send_po(email, po_number, body.subject or "", body.body or "",
                                body.to or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {**res, "insights": smart.build_insights(email)}


@app.post("/api/supply/item/delete")
def supply_item_delete(body: SupplyIdBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    supply.delete_item(email, body.id)
    return _supply_payload(email)


@app.post("/api/supply/import-products")
def supply_import_products(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    supply.import_products_from_sales(email)
    return _supply_payload(email)


@app.post("/api/supply/waste")
def supply_waste(body: SupplyWasteBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        supply.record_waste(email, body.inventory_id, body.qty, body.reason or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _supply_payload(email)


@app.post("/api/supply/map")
def supply_map(body: SupplyMapBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        supply.upsert_map(email, body.product, body.inventory_id, body.qty_per_unit)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _supply_payload(email)


@app.post("/api/supply/map/delete")
def supply_map_delete(body: SupplyMapIdBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    supply.delete_map(email, body.id)
    return _supply_payload(email)


@app.post("/api/supply/reorder/generate")
def supply_generate_po(authorization: str | None = Header(default=None)):
    """One order form per supplier for everything running low, ready to send."""
    email = require_user(authorization)
    pos = supply.create_pos_by_supplier(email)
    if not pos:
        raise HTTPException(400, "Nothing is running low right now, so there is "
                                 "nothing to order.")
    smart.set_decision(email, "reorder", "approved")
    for po in pos:
        who = po.get("supplier_name") or "an unassigned supplier"
        smart.add_task(email, f"Send order {po['po_number']} to {who}")
    payload = _supply_payload(email)
    payload["orders"] = [{
        "po_number": p["po_number"],
        "supplier_name": p.get("supplier_name") or "",
        "supplier_phone": p.get("supplier_phone") or "",
        "supplier_email": p.get("supplier_email") or "",
        "unassigned_supplier": bool(p.get("unassigned_supplier")),
        "n_items": p["n_items"], "total_qty": p["total_qty"],
        "total_amount": p.get("total_amount"),
        "download_url": f"/api/supply/po/{p['po_number']}/pdf",
        "excel_url": f"/api/supply/po/{p['po_number']}/download",
    } for p in pos]
    # kept for older clients
    payload["po_number"] = pos[0]["po_number"]
    payload["download_url"] = f"/api/supply/po/{pos[0]['po_number']}/pdf"
    payload["excel_url"] = f"/api/supply/po/{pos[0]['po_number']}/download"
    return payload


@app.post("/api/supply/po/create")
def supply_po_create(body: SupplyPOBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    po = supply.create_po(email, item_ids=body.item_ids or None)
    if not po:
        raise HTTPException(400, "Nothing to order for the selected item(s).")
    smart.add_task(email, f"Execute: Purchase order {po['po_number']}")
    payload = _supply_payload(email)
    payload["po_number"] = po["po_number"]
    payload["download_url"] = f"/api/supply/po/{po['po_number']}/pdf"
    payload["excel_url"] = f"/api/supply/po/{po['po_number']}/download"
    return payload


@app.get("/api/supply/po/{po_number}/pdf")
def supply_po_pdf(po_number: str, supplier: int = 0,
                  authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    po = supply.get_po(email, po_number)
    if not po:
        raise HTTPException(404, "Purchase order not found.")
    fname, buf = supply.po_pdf_bytes(email, po, for_supplier=bool(supplier))
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        buf, media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={fname}"})


@app.get("/api/supply/po/{po_number}/download")
def supply_po_download(po_number: str, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    po = supply.get_po(email, po_number)
    if not po:
        raise HTTPException(404, "Purchase order not found.")
    fname, buf = supply.po_excel(email, po)
    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={fname}"})


# ---------------------------------------------------------
# Product Management  (canonical products + platform aliases)
# ---------------------------------------------------------
class ProductBody(BaseModel):
    id: str | None = None
    name: str
    category: str | None = ""
    sku: str | None = ""
    price: float | None = None
    unit_cost: float | None = None
    status: str | None = "active"
    # ---- storefront (Website Builder) ----
    description: str | None = ""
    image_url: str | None = ""
    images: list[str] = []
    highlights: list[str] = []
    mrp: float | None = None
    stock: int | None = 0
    track_stock: bool | None = True
    listed: bool | None = True
    unit_label: str | None = ""
    video_url: str | None = ""
    # ---- variants ----
    # `options` are the axes (Size, Colour); `variants` is the matrix they
    # expand into. The seller sends whichever they edited — the backend
    # rebuilds the matrix from the axes and carries existing cells over.
    options: list[dict] = []
    variants: list[dict] = []
    # which sections of the storefront this product appears in
    featured: bool | None = False
    spotlight: bool | None = False


class ProductIdBody(BaseModel):
    id: str


class AliasBody(BaseModel):
    product_id: str
    alias: str
    platform: str | None = ""


class AliasIdBody(BaseModel):
    id: str


def _products_payload(email: str) -> dict:
    return {
        "products": products.get_products(email),
        "unmatched": products.unmatched_sales_names(email),
        "sales_products": products.sales_product_names(email),
    }


@app.get("/api/products/state")
def products_state(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return _products_payload(email)


@app.post("/api/products/item")
def products_item(body: ProductBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    try:
        products.upsert_product(email, body.dict())
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _products_payload(email)


@app.post("/api/products/item/delete")
def products_item_delete(body: ProductIdBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    products.delete_product(email, body.id)
    return _products_payload(email)


@app.post("/api/products/alias")
def products_alias(body: AliasBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        products.add_alias(email, body.product_id, body.alias, body.platform or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _products_payload(email)


@app.post("/api/products/alias/delete")
def products_alias_delete(body: AliasIdBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    products.delete_alias(email, body.id)
    return _products_payload(email)


# =========================================================================
# WEBSITE BUILDER — seller side (Site Management module)
# =========================================================================
class SiteSaveBody(BaseModel):
    site: dict


class PublishBody(BaseModel):
    published: bool


class ChannelBody(BaseModel):
    channel: str
    enabled: bool


class OrderStatusBody(BaseModel):
    order_id: str
    status: str
    reason: str | None = ""


class ListedBody(BaseModel):
    id: str
    listed: bool


def _site_state(email: str) -> dict:
    site = sitebuilder.get_site(email)
    listed = products.listed_products(email)
    all_prods = products.get_products(email)
    return {
        "site": site,
        "themes": sitebuilder.theme_catalog(),
        "fonts": sitebuilder.FONTS,
        "resolved": sitebuilder.resolved_style(site),
        "suggested_handle": site.get("handle") or sitebuilder.suggest_handle(
            sitebuilder.company_name(site), email),
        "counts": {
            "listed": len(listed),
            "products": len(all_prods),
            "no_image": len([p for p in listed if not p.get("image_url")]),
            "no_price": len([p for p in listed if p.get("price") in (None, "")]),
        },
        "icons": sitebuilder.ICONS,
        "promise_icons": sitebuilder.PROMISE_ICONS,
        "stats": storefront.order_stats(email),
        # The address to show and share: onetapmanager.com/<company>. Decided
        # here rather than in the browser because only the server knows which
        # words are routes the app answers on, and a handle that is one of
        # them is only reachable at /s/<handle>.
        "public_path": ((f"/s/{site.get('handle')}"
                         if sitebuilder.handle_reserved(site.get("handle"))
                         else f"/{site.get('handle')}")
                        if site.get("handle") else ""),
    }


@app.get("/api/site/state")
def site_state(authorization: str | None = Header(default=None)):
    return _site_state(require_user(authorization))


@app.get("/api/site/gateway")
def site_gateway(authorization: str | None = Header(default=None)):
    """Every gateway this seller can connect (Razorpay, Stripe, PayPal), which
    one is active, and each one's connected state and last four. Never a secret.
    The old flat Razorpay shape is kept under `razorpay` for any older caller."""
    email = require_user(authorization)
    ps = store_payments.provider_status(email)
    # Back-compat: keep the pre-multi-gateway keys the Razorpay-only UI read.
    return {**ps, **store_payments.status(email)}


@app.post("/api/site/gateway")
def site_gateway_save(body: StoreGatewayBody, authorization: str | None = Header(default=None)):
    """Save Razorpay keys (kept for the existing India flow)."""
    email = require_user(authorization)
    try:
        store_payments.save_keys(email, body.key_id, body.key_secret)
        store_payments.set_provider(email, "razorpay")
        return store_payments.provider_status(email)
    except ValueError as e:
        raise HTTPException(400, str(e))


class StripeGatewayBody(BaseModel):
    secret_key: str
    publishable_key: str


class PaypalGatewayBody(BaseModel):
    client_id: str
    client_secret: str


class GatewayProviderBody(BaseModel):
    provider: str            # razorpay | stripe | paypal


@app.post("/api/site/gateway/stripe")
def site_gateway_stripe(body: StripeGatewayBody,
                        authorization: str | None = Header(default=None)):
    """Save the seller's own Stripe keys — for US, UK and Europe. Money settles
    into their Stripe account; we never hold it."""
    email = require_user(authorization)
    try:
        return store_payments.save_stripe_keys(email, body.secret_key, body.publishable_key)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/site/gateway/paypal")
def site_gateway_paypal(body: PaypalGatewayBody,
                        authorization: str | None = Header(default=None)):
    """Save the seller's own PayPal app credentials."""
    email = require_user(authorization)
    try:
        return store_payments.save_paypal_keys(email, body.client_id, body.client_secret)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/site/gateway/provider")
def site_gateway_provider(body: GatewayProviderBody,
                          authorization: str | None = Header(default=None)):
    """Choose which connected gateway the storefront checkout uses."""
    email = require_user(authorization)
    try:
        return store_payments.set_provider(email, body.provider)
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/site/gateway/disconnect")
def site_gateway_disconnect(provider: str = "razorpay",
                            authorization: str | None = Header(default=None)):
    """Disconnect one gateway. Defaults to Razorpay so the old no-argument call
    (from the Razorpay-only UI) still does what it always did."""
    email = require_user(authorization)
    return store_payments.disconnect_provider(email, provider)


@app.get("/api/site/pairings")
def site_pairings(theme: str = "", authorization: str | None = Header(default=None)):
    """Curated font pairings, the ones suiting this theme first."""
    require_user(authorization)
    return {"pairings": sitebuilder.pairings_for(theme), "fonts": sitebuilder.FONTS}


@app.post("/api/site/seed")
def site_seed(authorization: str | None = Header(default=None), force: bool = False):
    """Fill an untouched site from the seller's own catalogue, so the builder
    opens on a finished site rather than five steps of blank fields. Only
    writes where the seller has left a field empty."""
    email = require_user(authorization)
    was = bool(sitebuilder.get_site(email).get("seeded"))
    try:
        sitebuilder.seed_from_catalogue(email, force=force)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {**_site_state(email), "seeded_now": (not was) or bool(force)}


@app.post("/api/site/save")
def site_save(body: SiteSaveBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    try:
        sitebuilder.save_site(email, body.site or {})
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _site_state(email)


@app.post("/api/site/publish")
def site_publish(body: PublishBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    try:
        sitebuilder.set_published(email, body.published)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _site_state(email)


@app.post("/api/site/resolve")
def site_resolve(body: SiteSaveBody, authorization: str | None = Header(default=None)):
    """Resolve a draft site to its final palette, fonts and motion WITHOUT
    saving it. The builder calls this as the seller types so the live canvas
    repaints from the same resolver the published site uses — no guessing in
    the browser, and no half-finished edit ever reaching the database."""
    email = require_user(authorization)
    draft = body.site or {}
    return {
        "style": sitebuilder.resolved_style(draft),
        "categories": sitebuilder._payload(email, draft)["categories"],
    }


@app.get("/api/site/handle-check")
def site_handle_check(handle: str, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    h = sitebuilder.normalise_handle(handle)
    return {"handle": h, "available": sitebuilder.handle_available(h, email)}


@app.get("/api/site/domain-check")
def site_domain_check(domain: str, request: Request,
                      authorization: str | None = Header(default=None)):
    """Is this domain pointed here yet, and if not, what is wrong with it.

    Three things have to be true before a seller's own address works, and they
    fail in different places: the name has to be valid, DNS has to point at this
    app, and the host has to be told to answer for it. A single "not working
    yet" would leave the seller guessing which one."""
    email = require_user(authorization)
    d = sitebuilder.normalise_domain(domain)
    if not sitebuilder.valid_domain(d):
        return {"domain": d, "ok": False,
                "message": "Enter it like korastudio.com — no https://, no slashes."}
    taken = sitebuilder.domain_owner(d, email)
    if taken:
        return {"domain": d, "ok": False,
                "message": "That domain is already pointed at another shop here."}
    import socket
    here = (request.url.hostname or "").lower()
    try:
        mine = {a[4][0] for a in socket.getaddrinfo(here, None)}
    except OSError:
        mine = set()
    try:
        theirs = {a[4][0] for a in socket.getaddrinfo(d, None)}
    except OSError:
        return {"domain": d, "ok": False, "dns": False,
                "message": f"{d} does not resolve yet. Add the DNS record at your domain "
                           f"provider, then check again — it can take a few hours."}
    if mine and not (theirs & mine):
        return {"domain": d, "ok": False, "dns": True,
                "message": f"{d} resolves, but not to this app yet. Check the CNAME points "
                           f"to {here}, and that your host is set to accept this domain."}
    return {"domain": d, "ok": True, "dns": True,
            "message": f"{d} points here. Save, and your shop answers on it."}


@app.get("/api/site/preview")
def site_preview(authorization: str | None = Header(default=None)):
    return sitebuilder.preview_site(require_user(authorization))


_IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".avif")
_VIDEO_EXT = (".mp4", ".webm", ".mov", ".m4v")

# The biggest clip an upload may be. Kept modest on purpose: the web service
# runs on a 512MB Render box, and the storage client buffers the whole file
# while sending it, so a large video is what pushed the box out of memory. A
# Reel is ~8 seconds at 1080p — a few MB — so 24MB is generous. Tunable by env
# for a bigger instance, floored so it can never be set uselessly small.
try:
    _MAX_VIDEO_MB = max(4, int(os.environ.get("MAX_VIDEO_UPLOAD_MB", "24") or 24))
except (TypeError, ValueError):
    _MAX_VIDEO_MB = 24


@app.post("/api/site/image")
async def site_image(files: list[UploadFile] = File(...),
                     authorization: str | None = Header(default=None)):
    """One upload endpoint for every piece of media the seller adds — logos,
    hero art, hero video, story stills, lookbook clips and product photos —
    stored durably by backend.core.media so a redeploy cannot erase it.

    Video is allowed and gets a larger budget than stills: a background clip is
    the single biggest upgrade a storefront can have, and asking sellers to host
    it somewhere else is how that never happens."""
    email = require_user(authorization)
    if not files:
        raise HTTPException(400, "No file uploaded.")
    f = files[0]
    ext = os.path.splitext(f.filename or "")[1].lower()
    is_video = ext in _VIDEO_EXT
    if ext not in _IMAGE_EXT and not is_video:
        raise HTTPException(400, "Use a PNG, JPG, WEBP, GIF or SVG image, or an MP4/WEBM video.")
    import uuid as _uuid

    # VIDEO takes the memory-safe path. THE BUG THIS FIXES: a clip used to be
    # read whole into the server's memory (and copied again by the storage
    # client) before it was stored, which on a 512MB Render box is exactly the
    # "uploading a video exceeded the memory limit" the seller saw. Now it is
    # streamed straight to a file on disk a megabyte at a time and pushed to
    # storage from that path, so the clip is never held whole in this process.
    if is_video:
        cap = _MAX_VIDEO_MB * 1024 * 1024
        import tempfile
        fd, tmp = tempfile.mkstemp(suffix=ext, prefix="upload_")
        size = 0
        try:
            with os.fdopen(fd, "wb") as out:
                while True:
                    chunk = await f.read(1024 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > cap:
                        raise HTTPException(400,
                            f"That clip is over {_MAX_VIDEO_MB}MB. Export it "
                            f"shorter — about 8 seconds at 1080p is plenty for a "
                            f"Reel — and upload it again.")
                    out.write(chunk)
        except BaseException:
            # A rejected or aborted upload must not leave a temp file behind.
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise
        saved = media.save_file(f"{_uuid.uuid4().hex}{ext}", tmp, email)
        url = saved["url"]
        return {"ok": True, "image_url": url, "url": url, "kind": "video",
                "filename": f.filename, "durable": saved["durable"],
                "warning": saved["warning"], "compression": {}}

    # IMAGES stay on the in-memory path: they are capped small and have to be
    # read whole to be resized (media.compress_upload), which is the single
    # biggest win a storefront's load time gets. A photo off a phone is ~4000px
    # and several MB and used to be stored and served exactly as it arrived, to
    # every shopper, for a card shown 400px wide.
    cap = 10 * 1024 * 1024
    parts, size = [], 0
    while True:
        chunk = await f.read(1024 * 1024)
        if not chunk:
            break
        size += len(chunk)
        if size > cap:
            raise HTTPException(400, f"That file is over {cap // (1024 * 1024)}MB, "
                                     f"please compress it first.")
        parts.append(chunk)
    content = b"".join(parts)
    parts = []

    content, shrunk_name, shrink = media.compress_upload(content, f.filename or "")
    ext = os.path.splitext(shrunk_name)[1].lower() or ext
    saved = media.save(f"{_uuid.uuid4().hex}{ext}", content, email)
    url = saved["url"]
    return {"ok": True, "image_url": url, "url": url, "kind": "image",
            "filename": f.filename, "durable": saved["durable"],
            "warning": saved["warning"],
            # Reported so the UI can say "13MB photo saved as 670KB" rather than
            # leaving a seller wondering why their upload looks different.
            "compression": shrink}


@app.post("/api/products/listed")
def products_listed(body: ListedBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        cache.clear(email)
        products.set_listed(email, body.id, body.listed)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _products_payload(email)


# ---------------------------------------------------------
# Listed Platforms strip
# ---------------------------------------------------------
@app.get("/api/channels")
def channels_state(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    site = sitebuilder.get_site(email)
    connected = {}
    try:
        for c in commerce.catalog():
            connected[c["id"]] = bool(secrets_store.get_credentials(email, c["id"]))
    except Exception:  # noqa: BLE001
        connected = {}
    rows = [{
        "id": "site", "label": site.get("brand") or "My website", "icon": "globe",
        "kind": "own", "status": "live" if site.get("published") else "draft",
        "detail": (f"/s/{site['handle']}" if site.get("handle") else "Not set up yet"),
        "enabled": storefront.channel_enabled(email, "site"),
        "toggleable": bool(site.get("handle")),
        "orders": storefront.order_stats(email)["orders"],
    }]
    # Every live commerce connector (Shopify, WooCommerce, Wix, Amazon …) —
    # built from the catalog so a new connector shows up here automatically.
    for c in commerce.catalog():
        cid = c["id"]
        rows.append({
            "id": cid, "label": c["label"], "icon": c.get("icon", "bag"), "kind": "marketplace",
            "status": "connected" if connected.get(cid) else "available",
            "detail": "Connected - pulling orders" if connected.get(cid) else "Connect to pull orders",
            "enabled": storefront.channel_enabled(email, cid),
            "toggleable": bool(connected.get(cid)), "orders": None,
        })
    # Flipkart / Myntra rows removed -- "yet to come" placeholders were
    # taking up space without anything a seller could act on. Re-add them
    # here (same shape as the shopify/amazon loop above) once they're real.
    return {"channels": rows}


@app.post("/api/channels/toggle")
def channels_toggle(body: ChannelBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cache.clear(email)
    storefront.set_channel(email, body.channel, body.enabled)
    return channels_state(authorization)


# ---------------------------------------------------------
# Orders module (seller side)
# ---------------------------------------------------------
@app.get("/api/store/orders")
def store_orders(status: str = "", authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {
        "orders": storefront.get_orders(email, status=status),
        "stats": storefront.order_stats(email),
        "statuses": [{"id": s, "label": storefront.STATUS_LABELS[s]} for s in storefront.STATUSES],
        "site": {"handle": sitebuilder.get_site(email).get("handle"),
                 "published": sitebuilder.get_site(email).get("published")},
    }


@app.post("/api/store/orders/status")
def store_order_status(body: OrderStatusBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        cache.clear(email)
        storefront.set_status(email, body.order_id, body.status, reason=body.reason or "")
    except storefront.StoreError as e:
        raise HTTPException(400, str(e))
    return store_orders("", authorization)


@app.get("/api/store/orders/export")
def store_orders_export(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    csv = storefront.orders_csv(email)
    return Response(content=csv, media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=site_orders.csv"})


@app.get("/api/cancellations")
def cancellation_analysis(authorization: str | None = Header(default=None)):
    """Cancellations, from the seller's own storefront orders.

    Cancelled orders are already excluded from the sales dataset and from every
    insight built on it — this is the one place they are counted, which is why
    the numbers here will not tie to Sales Analytics and should not.
    """
    email = require_user(authorization)
    res = cache.memo(
        "cancellations", email,
        lambda: cancellations.analyse(storefront.get_orders(email, status="all")),
        ttl=120)
    return {**res, "headline": cancellations.headline(res),
            "reason_options": cancellations.REASONS}


@app.get("/api/store/customers")
def store_customers(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    rows = [storefront._public_customer(c) for c in storefront._customers(email)]
    orders = storefront.get_orders(email)
    spend: dict = {}
    for o in orders:
        if o.get("status") == "cancelled":
            continue
        cid = o.get("customer_id")
        agg = spend.setdefault(cid, {"orders": 0, "spend": 0.0, "last": ""})
        agg["orders"] += 1
        agg["spend"] += float(o.get("total") or 0)
        agg["last"] = max(agg["last"], o.get("created_at") or "")
    for r in rows:
        r.update(spend.get(r["id"], {"orders": 0, "spend": 0.0, "last": ""}))
    rows.sort(key=lambda r: r.get("spend") or 0, reverse=True)
    return {"customers": rows}


# =========================================================================
# STOREFRONT — public, shopper side
# =========================================================================
class ShopAuthBody(BaseModel):
    email: str
    password: str
    name: str | None = ""
    phone: str | None = ""


class ShopCartBody(BaseModel):
    lines: list[dict] = []


class ShopOrderBody(BaseModel):
    lines: list[dict] = []
    address: dict = {}
    payment: str = "cod"
    note: str | None = ""
    # Guest checkout: a shopper with no account still gives us these, because
    # the parcel cannot be delivered without them.
    guest: bool = False
    name: str | None = ""
    phone: str | None = ""
    email: str | None = ""
    # Razorpay hands these back after a successful payment; the server verifies
    # the signature against the seller's own secret before any order is created.
    razorpay_order_id: str | None = ""
    razorpay_payment_id: str | None = ""
    razorpay_signature: str | None = ""



class ShopForgotBody(BaseModel):
    email: str


class ShopResetBody(BaseModel):
    token: str
    password: str



def _seller_for(handle: str) -> str:
    owner = sitebuilder.resolve_handle(handle)
    if not owner:
        raise HTTPException(404, "No store at this address.")
    site = sitebuilder.get_site(owner)
    if not site.get("published"):
        raise HTTPException(404, "This store is not open yet.")
    return owner


def _shopper(handle: str, x_store_token: str | None):
    seller = _seller_for(handle)
    cust = storefront.customer_from_token(seller, (x_store_token or "").strip())
    if not cust:
        raise HTTPException(401, "Log in to continue.")
    return seller, cust


@app.get("/api/shop/{handle}/site")
def shop_site(handle: str, x_preview_token: str | None = Header(default=None)):
    """The storefront's own data. Normally only a published site answers; the
    owner's live preview passes their session token so they can see the site
    exactly as shoppers will before switching it on."""
    owner = sitebuilder.resolve_handle(handle)
    if not owner:
        raise HTTPException(404, "No store at this address.")
    if x_preview_token and auth.user_from_token(x_preview_token.strip()) == owner:
        payload = sitebuilder.preview_site(owner)
    else:
        payload = sitebuilder.public_site(handle)
    if not payload:
        raise HTTPException(404, "This store is not open yet.")
    payload.pop("seller", None)
    return payload


@app.post("/api/shop/{handle}/register")
def shop_register(handle: str, body: ShopAuthBody):
    seller = _seller_for(handle)
    try:
        cust = storefront.register(seller, body.email, body.password,
                                   body.name or "", body.phone or "")
    except storefront.StoreError as e:
        raise HTTPException(400, str(e))
    return {"token": storefront.issue_token(seller, cust["id"]),
            "customer": storefront._public_customer(cust)}


@app.post("/api/shop/{handle}/login")
def shop_login(handle: str, body: ShopAuthBody):
    seller = _seller_for(handle)
    try:
        cust = storefront.login(seller, body.email, body.password)
    except storefront.StoreError as e:
        raise HTTPException(401, str(e))
    return {"token": storefront.issue_token(seller, cust["id"]),
            "customer": storefront._public_customer(cust)}


@app.post("/api/shop/{handle}/logout")
def shop_logout(handle: str, x_store_token: str | None = Header(default=None)):
    seller = _seller_for(handle)
    storefront.revoke_token(seller, x_store_token or "")
    return {"ok": True}


@app.get("/api/shop/{handle}/me")
def shop_me(handle: str, x_store_token: str | None = Header(default=None)):
    seller, cust = _shopper(handle, x_store_token)
    return {"customer": storefront._public_customer(cust),
            "orders": _flag_cancel_requests(seller,
                storefront.get_orders(seller, customer_id=cust["id"]))}


@app.post("/api/shop/{handle}/cart")
def shop_cart(handle: str, body: ShopCartBody):
    seller = _seller_for(handle)
    return storefront.price_cart(seller, body.lines or [])


@app.post("/api/shop/{handle}/pay")
def shop_pay(handle: str, body: ShopPayBody):
    """Open a payment on the seller's own Razorpay account.

    Priced server-side from the same cart resolver checkout uses, so the amount
    can never be set by the browser. Returns only what Razorpay's checkout
    widget needs — the seller's public key id and the order id.
    """
    seller = _seller_for(handle)
    site = sitebuilder.get_site(seller)
    priced = storefront.price_cart(seller, body.lines or [])
    if not priced["items"]:
        raise HTTPException(400, "Your cart is empty.")
    pay = "prepaid" if body.payment == "prepaid" else "cod"
    due = store_payments.split_due(site["commerce"], priced["total"], pay)
    if due["online"] <= 0:
        raise HTTPException(400, "Nothing to pay online for this order.")
    if pay == "cod" and not priced["cod_enabled"]:
        raise HTTPException(400, "Cash on delivery is not available for this store.")
    if pay == "prepaid" and not priced["online_enabled"]:
        raise HTTPException(400, "Online payment is not available for this store.")
    try:
        out = store_payments.create_order(
            seller, due["online"], handle,
            note="advance" if due["kind"] == "cod_advance" else "full",
            intent={"fingerprint": storefront.cart_fingerprint(priced, pay), "payment": pay})
    except (ValueError, RuntimeError) as e:
        raise HTTPException(400, str(e))
    return {**out, "due": due, "brand": site.get("brand") or handle,
            "total": priced["total"]}


@app.post("/api/shop/{handle}/order")
def shop_order(handle: str, body: ShopOrderBody,
               x_store_token: str | None = Header(default=None)):
    """Place an order — signed in, or as a guest.

    A guest is not a lesser record: they become a real customer keyed on the
    phone number they had to give us anyway, and they show up in the seller's
    RFM and Win-Back lists like anyone else. They can claim the account later
    by setting a password.
    """
    seller = _seller_for(handle)
    cust = storefront.customer_from_token(seller, (x_store_token or "").strip())
    signed_in = cust is not None
    if not cust:
        addr = body.address or {}
        try:
            cust = storefront.guest_customer(
                seller,
                name=body.name or addr.get("name") or "",
                phone=body.phone or addr.get("phone") or "",
                email=body.email or addr.get("email") or "",
            )
        except storefront.StoreError as e:
            raise HTTPException(400, str(e))
    # Verify the payment here, server-side, against the seller's own secret —
    # everything the browser sent is attacker-controlled until this passes.
    paid = False
    priced = storefront.price_cart(seller, body.lines or [])
    pay = "prepaid" if body.payment == "prepaid" else "cod"
    due = store_payments.split_due(sitebuilder.get_site(seller)["commerce"], priced["total"], pay)
    if body.razorpay_payment_id:
        paid = store_payments.verify(seller, body.razorpay_order_id or "",
                                     body.razorpay_payment_id or "",
                                     body.razorpay_signature or "", due["online"],
                                     storefront.cart_fingerprint(priced, pay), pay)
        if not paid:
            raise HTTPException(400, "We could not verify that payment. "
                                     "Nothing has been charged twice, please try again.")
    try:
        order = storefront.place_order(seller, cust, body.lines or [], body.address or {},
                                       body.payment or "cod", body.note or "",
                                       payment_ok=paid,
                                       payment_ref=body.razorpay_payment_id or "")
    except storefront.StoreError as e:
        raise HTTPException(400, str(e))
    if paid:
        store_payments.consume_verified(seller, body.razorpay_order_id or "",
                                        body.razorpay_payment_id or "")
    # a guest gets a session too, so "your orders" works on the thank-you page
    token = ((x_store_token or "").strip() if signed_in
             else storefront.issue_token(seller, cust["id"]))
    return {"order": order, "token": token,
            "customer": storefront._public_customer(cust)}


@app.post("/api/shop/{handle}/forgot")
def shop_forgot(handle: str, body: ShopForgotBody, request: Request):
    seller = _seller_for(handle)
    site = sitebuilder.get_site(seller) or {}
    return password_reset.request_shopper(
        seller, body.email, _public_base_url(request), handle,
        store_name=(site.get("brand") or {}).get("name") if isinstance(site.get("brand"), dict)
        else str(site.get("brand") or handle))


@app.post("/api/shop/{handle}/reset")
def shop_reset(handle: str, body: ShopResetBody):
    seller = _seller_for(handle)
    try:
        return password_reset.reset_shopper(seller, body.token, body.password)
    except password_reset.ResetError as e:
        raise HTTPException(400, str(e))


# ---------------------------------------------------------
# Frontend
# ---------------------------------------------------------
if os.path.isdir(SMART_DIR):
    app.mount("/smart-static", StaticFiles(directory=SMART_DIR), name="smart-static")


STORE_DIR = os.path.join(SMART_DIR, "storefront")
if os.path.isdir(STORE_DIR):
    app.mount("/store-static", StaticFiles(directory=STORE_DIR), name="store-static")


def _meta_tags(meta: dict, url: str, indexable: bool = True) -> str:
    """The head a crawler and a WhatsApp link preview actually read.

    The storefront is a one-page app, so without this every page of every store
    is `<title>Store</title>` and a pasted link arrives as naked grey text —
    which, in a market where the share sheet is the shopfront, is the whole
    difference between a link that sells and one that does not.
    """
    def esc(v: str) -> str:
        return (str(v or "").replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace('"', "&quot;"))

    img = meta.get("image") or ""
    if img and img.startswith("/"):
        img = url.split("/s/")[0].rstrip("/") + img
    tags = [
        f"<title>{esc(meta['title'])}</title>",
        f'<meta name="description" content="{esc(meta["description"])}" />',
        f'<link rel="canonical" href="{esc(url)}" />',
        f'<meta property="og:type" content="website" />',
        f'<meta property="og:site_name" content="{esc(meta["site_name"])}" />',
        f'<meta property="og:title" content="{esc(meta["title"])}" />',
        f'<meta property="og:description" content="{esc(meta["description"])}" />',
        f'<meta property="og:url" content="{esc(url)}" />',
        f'<meta name="twitter:card" content="{"summary_large_image" if img else "summary"}" />',
        f'<meta name="twitter:title" content="{esc(meta["title"])}" />',
        f'<meta name="twitter:description" content="{esc(meta["description"])}" />',
        # Explicit, because a shop that is live wants to be found and a shop
        # that is not must never be. The caller passes indexable=False for an
        # owner preview of an unpublished site: that URL is reachable with a
        # token, and a crawler that somehow followed it must not keep the page.
        ('<meta name="robots" content="index, follow" />' if indexable else
         '<meta name="robots" content="noindex, nofollow" />'),
    ]
    if img:
        tags.append(f'<meta property="og:image" content="{esc(img)}" />')
        tags.append(f'<meta name="twitter:image" content="{esc(img)}" />')
    if meta.get("keywords"):
        tags.append(f'<meta name="keywords" content="{esc(meta["keywords"])}" />')
    return "\n".join(tags)


def _render_store(handle: str, request: Request, product_id: str = "") -> Response:
    index = os.path.join(STORE_DIR, "store.html")
    if not os.path.exists(index):
        raise HTTPException(404, "Storefront UI not found.")
    owner = sitebuilder.resolve_handle(handle)
    if not owner:
        raise HTTPException(404, "No store at this address.")

    site = sitebuilder.get_site(owner)
    product = None
    if product_id:
        product = next((p for p in products.storefront_payload(owner)
                        if p["id"] == product_id), None)
    meta = sitebuilder.seo_meta(handle, site, product)
    base = _public_base_url(request)
    # Three addresses reach a shop: the seller's own domain (the shop is at the
    # root), onetapmanager.com/<company> (the default public address, which the
    # router rewrites onto /s/ and marks with store_base), and /s/<handle>, which
    # every link shared before the short form existed uses. Every link on the
    # page is written in the form this request arrived on, so a crawler walking
    # it stays on one form.
    pretty_base = getattr(request.state, "store_base", "") or ""
    on_own_domain = not pretty_base and not request.url.path.startswith("/s/")
    store_path = pretty_base or ("" if on_own_domain else f"/s/{handle}")
    # The canonical, though, is ONE address whichever form was requested,
    # because two URLs for one page is the thing a canonical tag exists to
    # settle. On the app's host that is the short /<company> form, unless the
    # handle collides with a route the app itself answers on, where /s/ is the
    # only address that reaches the shop.
    public_path = ("" if on_own_domain
                   else f"/s/{handle}" if sitebuilder.handle_reserved(handle)
                   else f"/{handle}")
    url = (base + public_path) + (
        f"/p/{sitebuilder.product_slug(product)}" if product else "")

    with open(index, encoding="utf-8") as fh:
        html = fh.read()
    # An unpublished shop is still reachable by its owner with a preview token.
    # That page must never be indexed: a half-built shop in a search result is
    # a bad first impression that outlives the launch.
    html = html.replace("<title>Store</title>",
                        _meta_tags(meta, url, indexable=bool(site.get("published"))))

    # Structured data and a plain-HTML copy of the page, both server-rendered.
    # The storefront is a one-page app, so without these the first thing a
    # crawler is handed is an empty div and a spinner, and every crawler that
    # does not run JavaScript (WhatsApp's link preview, Facebook's, Bing's) sees
    # nothing at all. See sitebuilder.storefront_jsonld for the full reasoning.
    catalogue = products.storefront_payload(owner)
    try:
        ld = sitebuilder.storefront_jsonld(handle, site, catalogue, product,
                                          base, store_path or f"/s/{handle}")
        html = html.replace("</head>",
                            f'<script type="application/ld+json">{ld}</script>\n</head>', 1)
    except Exception as e:                                       # noqa: BLE001
        errors.record(e, where=f"storefront schema for {handle}")

    try:
        fallback = sitebuilder.storefront_fallback_html(
            handle, site, catalogue, product, store_path or f"/s/{handle}")
        html = html.replace('<div id="app" hidden></div>',
                            f'<div id="app" hidden></div>{fallback}', 1)
    except Exception as e:                                       # noqa: BLE001
        errors.record(e, where=f"storefront fallback for {handle}")

    # On the seller's own domain the path carries no handle, so the page says
    # which shop it is. Harmless under /s/<handle>, where it agrees.
    html = html.replace("</head>",
                        f"<script>window.__STORE_HANDLE__={json.dumps(handle)};</script></head>", 1)
    return Response(content=html, media_type="text/html",
                    headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"})


@app.get("/s/{handle}")
def storefront_page(handle: str, request: Request):
    """A seller's own website. One page app; it fetches /api/shop/<handle>/site."""
    return _render_store(handle, request)


@app.get("/s/{handle}/p/{product_id}")
def storefront_product_page(handle: str, product_id: str, request: Request):
    """A product's own address, so a shopper can share the thing, not the shop.

    Takes either form: the bare id, which is what every link shared before slugs
    existed looks like, or `readable-name-<id>`. The id is the last piece either
    way, so renaming a product never breaks a link somebody already sent.
    """
    return _render_store(handle, request,
                         sitebuilder.product_id_from_slug(product_id))


@app.get("/s/{handle}/legal/{slug}", response_class=Response)
def storefront_legal(handle: str, slug: str, request: Request):
    """A shop's privacy policy, terms of sale, and returns policy.

    Server-rendered, not drawn by the storefront bundle. A policy that only
    exists after JavaScript has run is not published in any sense a regulator or
    a crawler would accept, and these are exactly the pages a shopper opens on a
    bad connection when they are already unsure about buying.
    """
    owner = sitebuilder.resolve_handle(handle)
    if not owner:
        raise HTTPException(404, "No store at this address.")
    site = sitebuilder.get_site(owner)
    html = legal_html.seller_page(
        shop_name=str(site.get("brand") or "") or handle,
        handle=handle,
        legal_details=sitebuilder.legal_details(site),
        slug=slug,
        base_url=_public_base_url(request),
        store_path=f"/s/{handle}")
    if not html:
        raise HTTPException(404, "No such document.")
    return Response(content=html, media_type="text/html")


@app.get("/api/shop/{handle}/legal")
def storefront_legal_config(handle: str):
    """What the shop's footer needs: who runs it, and its policy links.

    Consumer Protection (E-commerce) Rule 5(4) makes displaying the seller's
    legal name, address and contact our duty as the platform, so the storefront
    is given them rather than left to decide whether to show them.
    """
    owner = sitebuilder.resolve_handle(handle)
    if not owner:
        raise HTTPException(404, "No store at this address.")
    site = sitebuilder.get_site(owner)
    d = sitebuilder.legal_details(site)
    return {
        "shop": str(site.get("brand") or "") or handle,
        "seller": {"legal_name": d["legal_name"], "address": d["address"],
                   "email": d["email"], "phone": d["phone"],
                   "grievance_name": d["grievance_name"],
                   "gstin": d["gstin"]},
        "refund": legal.refund_choice(d["refund_policy"]),
        "documents": [
            {"slug": "privacy", "title": "Privacy Policy",
             "url": f"/s/{handle}/legal/privacy"},
            {"slug": "terms", "title": "Terms of Sale",
             "url": f"/s/{handle}/legal/terms"},
            {"slug": "refunds", "title": "Returns and Refunds",
             "url": f"/s/{handle}/legal/refunds"},
        ],
        "gaps": sitebuilder.legal_gaps(site),
        "platform": {"name": legal.PRODUCT_NAME, "legal_url": "/legal"},
    }


@app.get("/api/site/legal-options")
def site_legal_options(authorization: str | None = Header(default=None)):
    """The refund policies a seller may choose between, and what is still blank.

    A fixed list rather than a free-text box: a seller typing their own refund
    policy is how a shop ends up publishing something unenforceable, or nothing.
    """
    email = require_user(authorization)
    site = sitebuilder.get_site(email)
    return {"choices": legal.REFUND_CHOICES,
            "selected": sitebuilder.legal_details(site)["refund_policy"],
            "gaps": sitebuilder.legal_gaps(site),
            "required": [{"key": k, "label": l} for k, l in legal.SELLER_REQUIRED]}


@app.get("/s/{handle}/sitemap.xml")
def storefront_sitemap(handle: str, request: Request):
    owner = sitebuilder.resolve_handle(handle)
    if not owner or not sitebuilder.get_site(owner).get("published"):
        raise HTTPException(404, "No store at this address.")
    # The same address the canonical tag names, so the map and the pages agree.
    base = (f"{_public_base_url(request)}/s/{handle}"
            if sitebuilder.handle_reserved(handle)
            else f"{_public_base_url(request)}/{handle}")
    urls = ([base]
            + [f"{base}/p/{sitebuilder.product_slug(p)}"
               for p in products.storefront_payload(owner)]
            # The legal pages are real, indexable pages on the shop's own
            # address, so they belong in its map. They are also the pages a
            # shopper searches for by name when deciding whether to trust a shop
            # they have not bought from before.
            + [f"{base}/legal/{slug}" for slug in ("privacy", "terms", "refunds")])
    body = "".join(f"<url><loc>{u}</loc></url>" for u in urls)
    return Response(
        content=f'<?xml version="1.0" encoding="UTF-8"?>'
                f'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{body}</urlset>',
        media_type="application/xml")


# ---------------------------------------------------------------------------
# Proving to Google that this site is ours
# ---------------------------------------------------------------------------
# Search Console will not show a single thing about a site until the site proves
# it belongs to whoever is asking. There are two ways that do not need DNS:
# upload a file at a path Google names, or put a meta tag in the home page's
# head. Both are supported here, because which one is available depends on where
# the domain is registered and how much of it the operator controls.
#
# The file route is the one that keeps working after a domain move, so it is
# listed first in the launch checklist. Both read from the environment: nothing
# about verification belongs in git, because the token identifies the account
# that will receive the site's search data.
@app.get("/google{token}.html")
def google_site_verification(token: str):
    """Serve the file Search Console asks for, when one is configured.

    GOOGLE_SITE_VERIFICATION holds the value Google gives, with or without the
    "google" prefix and the ".html" suffix, because both forms are what people
    copy. Anything else 404s, so this cannot be used to probe what is set.
    """
    want = (os.getenv("GOOGLE_SITE_VERIFICATION") or "").strip()
    want = want.removeprefix("google").removesuffix(".html")
    if not want or token != want:
        raise HTTPException(404, "Not found")
    return Response(content=f"google-site-verification: google{want}.html",
                    media_type="text/html")


@app.get("/.well-known/security.txt")
def security_txt_well_known(request: Request):
    """The path RFC 9116 actually specifies."""
    return _security_txt(request)


@app.get("/security.txt")
def security_txt_root(request: Request):
    """The path people try first. Same answer, so neither 404s."""
    return _security_txt(request)


def _security_txt(request: Request):
    """Where to report a security problem.

    RFC 9116. Not a legal requirement, and it is the cheapest possible way for
    somebody who finds a hole to tell the operator instead of telling everybody
    else. It reads the same support address the legal pages use, so there is one
    place to change it.
    """
    from backend.core import legal as _legal
    email = (_legal.business().get("support_email") or "").strip()
    if not email:
        raise HTTPException(404, "Not configured")
    import datetime as _d
    expires = (_d.datetime.now(_d.timezone.utc)
               + _d.timedelta(days=365)).replace(microsecond=0).isoformat()
    base = _public_base_url(request)
    return Response(
        content=(f"Contact: mailto:{email}\n"
                 f"Expires: {expires}\n"
                 f"Preferred-Languages: en, hi\n"
                 f"Canonical: {base}/.well-known/security.txt\n"),
        media_type="text/plain")


@app.get("/robots.txt")
def robots(request: Request):
    """What a crawler may read, and where the map is.

    THE BUG THIS FIXES: this already advertised /sitemap.xml, and /sitemap.xml
    did not exist. Only /s/<handle>/sitemap.xml did. So every crawler that
    followed the Sitemap line got a 404, which is a worse signal than having no
    Sitemap line at all, and it is one of the reasons Google had nothing to
    show. The sitemap below now exists.

    The app itself is disallowed. /smart and /app are behind a login and hold one
    seller's private figures; there is nothing there for a crawler and no reason
    to let it try.
    """
    # The AI crawlers are named one by one (see core/geo.py): a crawler that
    # finds a group naming it follows only that group, so each carries the same
    # private-path rules, and nobody can later drop us out of AI answers with a
    # blanket rule without seeing the list first.
    return Response(content=geo.robots_txt(_public_base_url(request)),
                    media_type="text/plain")


# Pages a crawler should know about. Deliberately short and hand-kept: this is a
# marketing site plus a legal hub, not a catalogue, and a sitemap listing URLs
# that do not exist is worse than a small one that is true. Each seller shop has
# its own sitemap at /s/<handle>/sitemap.xml.
PUBLIC_PAGES = [
    ("/", "1.0", "weekly"),
    ("/legal", "0.5", "monthly"),
    ("/legal/privacy", "0.4", "monthly"),
    ("/legal/terms", "0.4", "monthly"),
    ("/legal/refunds", "0.4", "monthly"),
    ("/legal/cookies", "0.3", "monthly"),
    ("/legal/acceptable-use", "0.3", "monthly"),
    ("/legal/grievance", "0.4", "monthly"),
    # The pages written for search and AI assistants come from core/geo.py
    # (geo.sitemap_entries), so a new page there cannot be left out of here.
]


# WHY lastmod IS NOT date.today().
#
# It used to be. Every page in the sitemap claimed it had been modified today,
# on every single request, forever. That is not a small inaccuracy: Google
# states plainly that it ignores lastmod when a site's values are demonstrably
# unreliable, and "every URL changed today, again" is the textbook example. The
# sitemap then carries no freshness signal at all, and the one field that tells
# a crawler "this page is worth re-reading" is dead weight.
#
# The honest answer is the mtime of the file the page is actually rendered
# from. It only moves when the content really changes, which is what the field
# means, and it needs no hand-maintained date that would go stale the first
# time somebody forgot it.
_LEGAL_SRC = os.path.join(os.path.dirname(__file__), "core", "legal.py")
_LANDING_SRC = os.path.join(STATIC_DIR, "landing.html")
_GEO_SRC = os.path.join(os.path.dirname(__file__), "core", "geo.py")


def _lastmod(path: str) -> str:
    """The date the source behind this URL last actually changed."""
    src = (_LANDING_SRC if path == "/"
           else _GEO_SRC if path in geo.paths() else _LEGAL_SRC)
    try:
        return _dt.date.fromtimestamp(os.path.getmtime(src)).isoformat()
    except OSError:
        # A missing file is not a reason to serve a broken sitemap; omitting
        # lastmod entirely is valid and honest, so the caller drops the tag.
        return ""


@app.get("/sitemap.xml")
def sitemap(request: Request):
    base = _public_base_url(request).rstrip("/")
    body = ""
    for path, pri, freq in PUBLIC_PAGES + geo.sitemap_entries():
        mod = _lastmod(path)
        body += (f"<url><loc>{base}{path}</loc>"
                 + (f"<lastmod>{mod}</lastmod>" if mod else "")
                 + f"<changefreq>{freq}</changefreq>"
                   f"<priority>{pri}</priority></url>")
    return Response(
        content=('<?xml version="1.0" encoding="UTF-8"?>'
                 '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
                 f"{body}</urlset>"),
        media_type="application/xml")


# An inline SVG favicon. No binary asset to lose, scales to every size a browser
# asks for, and it is one request that cannot 404. A missing favicon is a real
# signal to a person deciding whether a site is finished.
_FAVICON = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
    '<rect width="64" height="64" rx="14" fill="#2f3a57"/>'
    '<path d="M20 40V24h6l6 9 6-9h6v16h-5V32l-5 7h-4l-5-7v8z" fill="#fff"/>'
    '</svg>')


# The social card. Drawn as SVG rather than shipped as a photograph, for three
# reasons that all matter here: there is no image to licence and no photograph of
# a person who did not agree to appear in it; it is under 3KB, so the card renders
# before a slow phone has finished the page; and it shows the product's actual
# output rather than a stock desk with a laptop on it, which is what a seller
# needs to see to know what this is. 1200x630 is the size every platform crops
# from, so nothing important goes near the edges.
_OG_IMAGE = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630" width="1200" height="630" '
    'role="img" aria-label="One Tap Manager: three cards telling a seller what to do today">'
    '<rect width="1200" height="630" fill="#F7F5EF"/>'
    '<rect x="0" y="0" width="1200" height="8" fill="#1E3A8A"/>'
    '<g font-family="-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica, Arial, sans-serif">'
    '<rect x="72" y="66" width="46" height="46" rx="11" fill="#1E3A8A"/>'
    '<text x="82" y="97" font-size="19" font-weight="700" fill="#ffffff">1T</text>'
    '<text x="132" y="98" font-size="25" font-weight="700" fill="#101828">One Tap Manager</text>'
    '<text x="72" y="184" font-size="52" font-weight="800" fill="#101828">Run your shop the way a</text>'
    '<text x="72" y="244" font-size="52" font-weight="800" fill="#101828">big brand runs theirs.</text>'
    '<text x="72" y="300" font-size="24" fill="#475467">It reads your sales and tells you the three things</text>'
    '<text x="72" y="334" font-size="24" fill="#475467">worth doing this morning.</text>'
    # Three cards, the same three the hero shows, so the card and the page agree.
    '<g>'
    '<rect x="72" y="396" width="330" height="150" rx="12" fill="#111827"/>'
    '<text x="96" y="428" font-size="13" font-weight="700" fill="#F5A623" letter-spacing="1.4">STOCK</text>'
    '<text x="96" y="462" font-size="20" font-weight="700" fill="#E5E7EB">4 things are about</text>'
    '<text x="96" y="488" font-size="20" font-weight="700" fill="#E5E7EB">to run out</text>'
    '<text x="96" y="521" font-size="14" fill="#34D399">order form already written</text>'
    '</g><g>'
    '<rect x="432" y="396" width="330" height="150" rx="12" fill="#111827"/>'
    '<text x="456" y="428" font-size="13" font-weight="700" fill="#F5A623" letter-spacing="1.4">CUSTOMERS</text>'
    '<text x="456" y="462" font-size="20" font-weight="700" fill="#E5E7EB">38 buyers have not</text>'
    '<text x="456" y="488" font-size="20" font-weight="700" fill="#E5E7EB">come back</text>'
    '<text x="456" y="521" font-size="14" fill="#34D399">the message is written</text>'
    '</g><g>'
    '<rect x="792" y="396" width="330" height="150" rx="12" fill="#111827"/>'
    '<text x="816" y="428" font-size="13" font-weight="700" fill="#F5A623" letter-spacing="1.4">REVIEWS</text>'
    '<text x="816" y="462" font-size="20" font-weight="700" fill="#E5E7EB">Sizing runs small is</text>'
    '<text x="816" y="488" font-size="20" font-weight="700" fill="#E5E7EB">your top complaint</text>'
    '<text x="816" y="521" font-size="14" fill="#34D399">3 pages to edit</text>'
    '</g>'
    '<text x="72" y="590" font-size="15" fill="#6b7280">Worked examples. Not customer results.</text>'
    '</g></svg>')


# WhatsApp, Twitter/X and LinkedIn all refuse an SVG og:image: the preview simply
# does not render, which is worse than having no card at all. So the same card is
# also drawn as a PNG with Pillow, which is already a dependency, and the PNG is
# what the meta tag points at. Built once on first request and held in memory,
# because it never changes between deploys and a scraper asks for it per share.
_OG_PNG_CACHE: dict[str, bytes] = {}


def _og_png() -> bytes:
    if "png" in _OG_PNG_CACHE:
        return _OG_PNG_CACHE["png"]
    from PIL import Image, ImageDraw
    from backend.core import ailabel
    W, H = 1200, 630
    im = Image.new("RGB", (W, H), (247, 245, 239))
    d = ImageDraw.Draw(im)
    f = ailabel._font           # same font resolution, so no new font dependency

    d.rectangle([0, 0, W, 8], fill=(30, 58, 138))
    d.rounded_rectangle([72, 66, 118, 112], radius=11, fill=(30, 58, 138))
    d.text((83, 79), "1T", font=f(19), fill=(255, 255, 255))
    d.text((132, 78), "One Tap Manager", font=f(25), fill=(16, 24, 40))

    d.text((72, 140), "Run your shop the way a", font=f(50), fill=(16, 24, 40))
    d.text((72, 200), "big brand runs theirs.", font=f(50), fill=(16, 24, 40))
    d.text((72, 278), "It reads your sales and tells you the three things",
           font=f(23), fill=(71, 84, 103))
    d.text((72, 312), "worth doing this morning.", font=f(23), fill=(71, 84, 103))

    cards = [
        ("STOCK", "4 things are about", "to run out", "order form already written"),
        ("CUSTOMERS", "38 buyers have not", "come back", "the message is written"),
        ("REVIEWS", "Sizing runs small is", "your top complaint", "3 pages to edit"),
    ]
    for i, (tag, l1, l2, metric) in enumerate(cards):
        x = 72 + i * 360
        d.rounded_rectangle([x, 396, x + 330, 546], radius=12, fill=(17, 24, 39))
        d.text((x + 24, 416), tag, font=f(13), fill=(245, 166, 35))
        d.text((x + 24, 444), l1, font=f(19), fill=(229, 231, 235))
        d.text((x + 24, 470), l2, font=f(19), fill=(229, 231, 235))
        d.text((x + 24, 508), metric, font=f(14), fill=(52, 211, 153))

    # Said on the card itself, not only on the page, because the card is what
    # gets forwarded and the page is what does not.
    d.text((72, 574), "Worked examples. Not customer results.",
           font=f(15), fill=(107, 114, 128))

    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    _OG_PNG_CACHE["png"] = buf.getvalue()
    return _OG_PNG_CACHE["png"]


@app.get("/og-image.png")
def og_image_png():
    try:
        body = _og_png()
    except Exception as e:  # noqa: BLE001 - a missing card must not 500 the route
        errors.record(e, where="GET /og-image.png")
        return Response(content=_OG_IMAGE, media_type="image/svg+xml")
    return Response(content=body, media_type="image/png",
                    headers={"Cache-Control": "public, max-age=604800"})


# The logo Google shows beside the site in results and in the knowledge panel.
# Organization markup needs a raster image of at least 112px, square, and it is
# the "1T" mark from the site header so a search result and the page match.
_LOGO_PNG_CACHE: dict = {}


def _logo_png() -> bytes:
    if "png" in _LOGO_PNG_CACHE:
        return _LOGO_PNG_CACHE["png"]
    from PIL import Image, ImageDraw
    from backend.core import ailabel
    S = 512
    im = Image.new("RGB", (S, S), (247, 245, 239))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([32, 32, S - 32, S - 32], radius=96, fill=(30, 58, 138))
    font = ailabel._font(210)
    box = d.textbbox((0, 0), "1T", font=font)
    w, h = box[2] - box[0], box[3] - box[1]
    d.text(((S - w) / 2 - box[0], (S - h) / 2 - box[1]), "1T", font=font, fill=(255, 255, 255))
    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    _LOGO_PNG_CACHE["png"] = buf.getvalue()
    return _LOGO_PNG_CACHE["png"]


@app.get("/logo.png")
def logo_png():
    try:
        body = _logo_png()
    except Exception as e:  # noqa: BLE001 - a missing logo must not 500 the route
        errors.record(e, where="GET /logo.png")
        return Response(content=_FAVICON, media_type="image/svg+xml")
    return Response(content=body, media_type="image/png",
                    headers={"Cache-Control": "public, max-age=604800"})


@app.get("/og-image.svg")
def og_image():
    """The card a pasted link shows. Cached hard, because it never changes
    between deploys and a social scraper will ask for it once per share."""
    return Response(content=_OG_IMAGE, media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=604800"})


@app.get("/oops.js")
def oops_script():
    """The browser's unhandled-error handler, served to every surface.

    Same reasoning as /consent.js above: one file behind one route, because
    three copies under three mounts is how one of them ends up a version
    behind.
    """
    path = os.path.join(STORE_DIR, "oops.js")
    if not os.path.exists(path):
        return Response(content="/* oops script missing */",
                        media_type="application/javascript")
    with open(path, encoding="utf-8") as fh:
        return Response(content=fh.read(),
                        media_type="application/javascript",
                        headers={"Cache-Control": "public, max-age=300"})


class ClientError(Exception):
    """A fault that happened in somebody's browser, not in this process.

    A real exception type so it goes through errors.record() like everything
    else and lands in the same log, the same fingerprinting and the same
    operator email. The name is what appears as the "kind" in that log, which
    is how a browser fault is told apart from a server one at a glance.
    """


# A page in a render loop can throw thousands of times a second, and this
# endpoint is public. oops.js caps itself at five per page load, but that is
# the honest client's promise and not something to rely on, so the server
# keeps its own ceiling: a bounded dict of recent reporters, and a global
# count per window. Bounded because the key is caller-controlled.
_CE_WINDOW = 600.0          # ten minutes
_CE_PER_CALLER = 5
_CE_GLOBAL = 200
_ce_seen: dict[str, list] = {}
_ce_global: list = [0.0, 0]  # window start, count in window


def _client_error_allowed(caller: str) -> bool:
    now = time.time()
    if now - _ce_global[0] > _CE_WINDOW:
        _ce_global[0], _ce_global[1] = now, 0
        _ce_seen.clear()          # the only place this is emptied, so it cannot grow without bound
    if _ce_global[1] >= _CE_GLOBAL:
        return False
    hits = _ce_seen.get(caller)
    if hits is None:
        if len(_ce_seen) >= 500:  # a flood of distinct callers must not grow the dict either
            return False
        hits = [0]
        _ce_seen[caller] = hits
    if hits[0] >= _CE_PER_CALLER:
        return False
    hits[0] += 1
    _ce_global[1] += 1
    return True


@app.post("/api/client-error")
async def client_error(request: Request):
    """Record a fault that happened in the browser.

    Always answers 204, whatever happens. This endpoint exists so a bug gets
    seen; it can never itself become a reason a seller's page misbehaves, and
    it tells an anonymous caller nothing about whether it was stored.
    """
    try:
        raw = await request.body()
        if len(raw) > 8192:              # bounded before it is parsed
            return Response(status_code=204)
        body = json.loads(raw or b"{}")
        if not isinstance(body, dict):
            return Response(status_code=204)
        caller = (request.headers.get("x-session-id")
                  or (request.client.host if request.client else "") or "?")[:80]
        if not _client_error_allowed(caller):
            return Response(status_code=204)
        try:
            who = optional_user(request.headers.get("authorization")) or ""
        except Exception:  # noqa: BLE001
            who = ""

        def f(k, n):
            return str(body.get(k) or "")[:n]

        exc = ClientError(f("message", 400) or "a browser error with no message")
        # The stack is the browser's, so it is passed as data rather than
        # pretending it is this process's traceback.
        errors.record(exc, where=f("page", 200) or "browser", email=who, extra={
            "kind": f("kind", 40),
            "source": f("source", 300),
            "line": f("line", 12),
            "col": f("col", 12),
            "ua": f("ua", 200),
            "stack": f("stack", 2000),
        })
    except Exception:  # noqa: BLE001 — reporting must never be the thing that breaks
        pass
    return Response(status_code=204)


@app.get("/consent.js")
def consent_script():
    """The consent gate, served to every surface from one file.

    A route rather than three copies under three static mounts, because three
    copies is how one of them ends up a version behind and quietly loading a
    tracker somebody rejected.
    """
    path = os.path.join(STORE_DIR, "consent.js")
    if not os.path.exists(path):
        return Response(content="/* consent script missing */",
                        media_type="application/javascript")
    with open(path, encoding="utf-8") as fh:
        body = fh.read()
    return Response(content=body, media_type="application/javascript",
                    headers={"Cache-Control": "public, max-age=3600"})


@app.get("/favicon.svg")
def favicon_svg():
    return Response(content=_FAVICON, media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=604800"})


@app.get("/favicon.ico")
def favicon_ico():
    """Browsers still ask for this by name. Answer with the SVG rather than a
    404, because a 404 here shows up in the console of every page load."""
    return Response(content=_FAVICON, media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=604800"})


@app.get("/smart")
def smart_page():
    index = os.path.join(SMART_DIR, "smart.html")
    if not os.path.exists(index):
        raise HTTPException(404, "Smart CafeX UI not found.")
    return FileResponse(index, headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"})


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Paths that belong to the app itself, whatever host they arrive on. Everything
# else on a seller's own domain is their shop.
@app.middleware("http")
async def _learn_base_url(request: Request, call_next):
    """Remember what this app's public address is, from real traffic.

    Meta fetches media from us, so publishing needs an absolute https address.
    A web request knows it; the background ticker does not, and used to read an
    environment variable that no deployment ever set — which is why nothing
    published. Learning it here means there is nothing to configure."""
    try:
        publisher.remember_base_url(_public_base_url(request))
    except Exception:  # noqa: BLE001 — never break a request over bookkeeping
        pass
    return await call_next(request)


_APP_PATHS = ("/api/", "/smart", "/smart-static/", "/static/", "/generated_images/",
              "/s/", "/docs", "/openapi.json", "/redoc", "/health", "/favicon.ico",
              # Meta fetches this to prove it can reach us. If a seller's custom
              # domain swallowed it and served their storefront instead, the
              # connection test would fail on every account that has one.
              "/preflight-image.jpg")


@app.middleware("http")
async def _force_https(request, call_next):
    """Bounce a plain-http request to https, and say so in a header.

    Only when a proxy has explicitly reported the original request as http. See
    publicurl.should_redirect_to_https for why that narrowness matters: behind a
    TLS terminator every request looks like http from inside this process, and a
    redirect based on that is an infinite loop that takes the whole site down,
    every shop on it included.
    """
    if publicurl.should_redirect_to_https(request.url.hostname or "", request.headers):
        target = str(request.url.replace(scheme="https"))
        return RedirectResponse(target, status_code=301)
    response = await call_next(request)
    # HSTS, so a browser that has been here once never tries http again. Two
    # years is the usual value; no preload and no includeSubDomains, because a
    # seller's custom domain is a subdomain we do not control and should not be
    # making promises about.
    if not publicurl.is_local(request.url.hostname or ""):
        response.headers.setdefault("Strict-Transport-Security", "max-age=63072000")

    # The rest of the headers a browser needs to be told, which HSTS is not.
    #
    # CLICKJACKING. /smart approves purchase orders, cancels subscriptions and
    # deletes accounts, all of them one click behind a logged-in session. With
    # nothing said about framing, any page anywhere could load the app in an
    # invisible iframe and steer a seller into clicking one of them. frame-
    # ancestors is the modern spelling and X-Frame-Options is the one older
    # browsers still read; both are cheap and they say the same thing.
    #
    # 'self', NOT 'none'. This was 'none' for one release, on the reasoning
    # that nothing in the product is meant to be embedded, and that reasoning
    # was wrong: the Website Builder's live preview IS an iframe of the seller's
    # own storefront, served from this same origin, so 'none' blanked the
    # builder for every seller while protecting nothing extra. 'self' still
    # refuses every other site, which is the whole of the clickjacking threat;
    # the only thing it allows is this app framing its own pages.
    #
    # REFERRER. A password reset link is a bearer credential IN a URL. Without
    # a policy, following any link from that page would hand the whole thing,
    # token and all, to the site being visited in the Referer header.
    # strict-origin-when-cross-origin keeps full referrers inside our own
    # origin and sends only the bare origin outward.
    #
    # setdefault throughout: /generated_images sets its own, much stricter CSP
    # for user-uploaded files, and that one must win.
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Content-Security-Policy", "frame-ancestors 'self'")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    return response


@app.middleware("http")
async def _custom_domain(request, call_next):
    """A request that arrived on korastudio.com renders that seller's shop.

    The site is always reachable at /s/<handle>; a custom domain is a second
    front door pointed here with a CNAME, so the seller can give customers an
    address that is theirs. The app's own paths (the API, the seller's console,
    static files) keep working on every host, which is what lets one deployment
    answer for the app AND for every shop domain."""
    path = request.url.path
    if path.startswith(_APP_PATHS):
        return await call_next(request)
    host = request.url.hostname or ""
    handle = ""
    # Our own host is never a seller's domain, and asking the database whether
    # it is would put a lookup in front of every visit to the landing page.
    if not _own_host(host):
        try:
            handle = sitebuilder.resolve_domain(host)
        except Exception:  # noqa: BLE001 — never break a request over this
            handle = ""
    if handle:
        if path in ("/", ""):
            return _render_store(handle, request)
        if path.startswith("/p/"):
            return _render_store(handle, request, sitebuilder.product_id_from_slug(
                path[len("/p/"):].split("/")[0]))
        if path == "/sitemap.xml":
            return storefront_sitemap(handle, request)
        return await call_next(request)

    # onetapmanager.com/<company>: the default public address of every shop.
    # Rewritten onto the /s/ routes rather than served by a second copy of
    # them, so the home page, product pages, policy pages and sitemap all come
    # from the one implementation that is already tested; store_base tells the
    # renderer to write its links in this short form.
    pretty = _pretty_shop(path)
    if pretty:
        h, rest = pretty
        new_path = f"/s/{h}{rest}"
        request.scope["path"] = new_path
        request.scope["raw_path"] = new_path.encode()
        request.state.store_base = f"/{h}"
    return await call_next(request)


def _own_host(host: str) -> bool:
    """The app's own addresses, as opposed to a seller's domain."""
    h = (host or "").split(":")[0].lower()
    if not h or publicurl.is_local(h) or h.endswith(".onrender.com"):
        return True
    own = {x for x in (publicurl.configured().split("://")[-1].split("/")[0],
                       os.environ.get("RENDER_EXTERNAL_HOSTNAME", "")) if x}
    own |= {"www." + x for x in own}
    return h in own


_PRETTY_TTL = 30.0
_PRETTY_MAX = 5000
_pretty_seen: dict[str, tuple[float, bool]] = {}


def _pretty_shop(path: str):
    """(handle, rest) when the first segment of `path` is a shop's handle.

    Cached for thirty seconds, misses included. Anything that looks like a
    word reaches here (/wp-admin, /phpmyadmin: the internet tries all of them),
    and without a cache each of those would be a database query. Thirty seconds
    is how long a brand-new shop's short address can take to start answering;
    its /s/ address works from the first moment.
    """
    parts = path.split("/", 2)
    seg = parts[1] if len(parts) > 1 else ""
    if len(seg) < 3 or seg != sitebuilder.normalise_handle(seg):
        return None
    if sitebuilder.handle_reserved(seg):
        return None
    rest = ("/" + parts[2]) if len(parts) > 2 and parts[2] else ""
    now = time.time()
    hit = _pretty_seen.get(seg)
    if hit and now - hit[0] < _PRETTY_TTL:
        live = hit[1]
    else:
        try:
            live = sitebuilder.resolve_handle(seg) is not None
        except Exception:  # noqa: BLE001
            live = False
        if len(_pretty_seen) >= _PRETTY_MAX:
            _pretty_seen.clear()       # bounded: the key is caller-controlled
        _pretty_seen[seg] = (now, live)
    return (seg, rest) if live else None


# The landing page holds __BASE_URL__ wherever it needs its own absolute address:
# the canonical tag, og:url, og:image and the three schema.org @id values. It is
# filled in per request rather than hardcoded so that connecting a custom domain
# is one environment variable (PUBLIC_BASE_URL) and not a search and replace
# across the file, and so a canonical tag can never point at the old host after
# a move, which is the classic way a site disappears from search the week it gets
# its real domain.
_LANDING_CACHE: dict[str, str] = {}


@app.get("/")
def landing(request: Request):
    base = _public_base_url(request)
    cached = _LANDING_CACHE.get(base)
    if cached is None:
        with open(os.path.join(STATIC_DIR, "landing.html"), encoding="utf-8") as fh:
            cached = (fh.read().replace("__BASE_URL__", base)
                      .replace('["__SAME_AS__"]', geo.same_as_json()))
        # One entry per host, so a seller domain and the app's own host do not
        # keep evicting each other. Bounded, because this is a public endpoint
        # and Host is attacker-controlled.
        if len(_LANDING_CACHE) > 8:
            _LANDING_CACHE.clear()
        _LANDING_CACHE[base] = cached
    return Response(content=cached, media_type="text/html",
                    headers={"Cache-Control": "public, max-age=300"})


@app.get("/app")
def app_page():
    # The old "Classic" interface is gone; one workspace lives at /smart.
    # Kept as a permanent redirect so bookmarks and old links still land.
    return RedirectResponse("/smart", status_code=301)


# ---------------------------------------------------------------------------
# Legal
# ---------------------------------------------------------------------------
# Rule 3(1)(a) of the IT Rules 2021 requires an intermediary to publish its
# rules and regulations, its privacy policy AND its user agreement. Hosting
# seller shops makes this app an intermediary, so all three are mandatory and
# all three are served from here rather than from a static file, because they
# have to name the operator and that comes from configuration. See
# backend/core/legal.py for which rule each document answers.
# ---------------------------------------------------------------------------
# Pages written to be quoted by AI assistants and search (core/geo.py)
# ---------------------------------------------------------------------------
def _geo_page(path: str, request: Request) -> Response:
    # Query parameters only matter to a page with a calculator (the reorder
    # point guide); every other page ignores them.
    html = geo.render(path, _public_base_url(request), dict(request.query_params))
    if not html:
        raise HTTPException(404, "No such page.")
    return Response(content=html, media_type="text/html",
                    headers={"Cache-Control": "public, max-age=3600"})


@app.get("/guides", response_class=Response)
def geo_guides(request: Request):
    return Response(content=geo.hub(_public_base_url(request)), media_type="text/html",
                    headers={"Cache-Control": "public, max-age=3600"})


@app.get("/about", response_class=Response)
def geo_about(request: Request):
    return _geo_page("/about", request)


@app.get("/for/{slug}", response_class=Response)
def geo_for(slug: str, request: Request):
    return _geo_page(f"/for/{slug}", request)


@app.get("/compare/{slug}", response_class=Response)
def geo_compare(slug: str, request: Request):
    return _geo_page(f"/compare/{slug}", request)


@app.get("/features/{slug}", response_class=Response)
def geo_feature(slug: str, request: Request):
    return _geo_page(f"/features/{slug}", request)


@app.get("/guides/{slug}", response_class=Response)
def geo_guide(slug: str, request: Request):
    return _geo_page(f"/guides/{slug}", request)


@app.get("/pricing", response_class=Response)
def geo_pricing(request: Request):
    return _geo_page("/pricing", request)


@app.get("/hi", response_class=Response)
def geo_hindi(request: Request):
    return _geo_page("/hi", request)


@app.get("/llms.txt")
def llms_txt(request: Request):
    return Response(content=geo.llms_txt(_public_base_url(request)),
                    media_type="text/plain; charset=utf-8",
                    headers={"Cache-Control": "public, max-age=3600"})


@app.get("/indexnow.txt")
def indexnow_key():
    """The IndexNow key file. Bing, and through it ChatGPT search, re-crawls a
    page within hours when told it changed; scripts/indexnow_ping.py does the
    telling. 404 until INDEXNOW_KEY is set, so nothing is claimed early."""
    key = (os.getenv("INDEXNOW_KEY") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9-]{8,128}", key):
        raise HTTPException(404, "Not found")
    return Response(content=key, media_type="text/plain")


@app.get("/BingSiteAuth.xml")
def bing_site_auth():
    """Bing Webmaster Tools' XML verification file, from BING_SITE_VERIFICATION."""
    code = (os.getenv("BING_SITE_VERIFICATION") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9]{8,64}", code):
        raise HTTPException(404, "Not found")
    return Response(content=('<?xml version="1.0"?>\n<users>\n'
                             f"\t<user>{code}</user>\n</users>\n"),
                    media_type="application/xml")


@app.get("/legal", response_class=Response)
def legal_hub(request: Request):
    return Response(content=legal_html.hub(_public_base_url(request)),
                    media_type="text/html")


@app.get("/legal/{slug}", response_class=Response)
def legal_page(slug: str, request: Request):
    html = legal_html.page(slug, _public_base_url(request))
    if not html:
        raise HTTPException(404, "No such document.")
    return Response(content=html, media_type="text/html")


# The old single privacy page kept its URL, because it may already be linked
# from somewhere we do not control. A permanent redirect is the honest way to
# move a published legal page.
@app.get("/privacy")
def privacy_page():
    return RedirectResponse("/legal/privacy", status_code=301)


@app.get("/terms")
def terms_redirect():
    return RedirectResponse("/legal/terms", status_code=301)


@app.get("/refunds")
def refunds_redirect():
    return RedirectResponse("/legal/refunds", status_code=301)


@app.get("/cookies")
def cookies_redirect():
    return RedirectResponse("/legal/cookies", status_code=301)


@app.get("/api/legal/config")
def legal_config():
    """What the footer and the consent banner need, in one call.

    Public on purpose: it carries only what is already printed on the legal
    pages, and the frontend needs it before anybody signs in.
    """
    ix = legal.index()
    return {
        "product": ix["product"],
        "identity": ix["identity"],
        "documents": ix["documents"],
        "complete": ix["complete"],
        "reviewed_on": ix["reviewed_on"],
        "grievance": {"ack_hours": legal.ACK_HOURS,
                      "resolve_days": legal.RESOLVE_DAYS},
        # The banner appears only when there is actually a tracker to consent
        # to. See legal.consent_required() for why that is the correct test
        # rather than showing one unconditionally.
        "consent": {"required": legal.consent_required(),
                    "analytics_id": legal.analytics_id()},
    }


# =========================================================================
# GST, invoicing and shipping labels
# =========================================================================
def _flag_cancel_requests(seller: str, orders: list[dict]) -> list[dict]:
    """Mark orders that already have an open cancellation request.

    Both the shopper's order list and the seller's Orders module read this, so
    a shopper cannot fire off five requests for the same parcel and the seller
    is never shown a Cancel control for something already in the inbox."""
    try:
        open_ids = {r["ref_id"] for r in cancel_requests.open_requests(seller)}
    except Exception:  # noqa: BLE001
        return orders
    for o in orders:
        o["cancel_requested"] = o.get("id") in open_ids
    return orders


def _seller_profile(email: str) -> dict:
    """The seller identity a label or invoice needs, assembled from GST
    settings with the site as a fallback for the trading name."""
    s = invoices.get_settings(email)
    site = sitebuilder.get_site(email)
    return {**s, "business_name": s.get("legal_name") or site.get("name") or ""}


@app.get("/api/gst/settings")
def gst_settings(authorization: str | None = Header(default=None)):
    return invoices.settings_status(require_user(authorization))


@app.post("/api/gst/settings")
def gst_settings_save(body: GstSettingsBody,
                      authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    invoices.save_settings(email, body.patch or {})
    return invoices.settings_status(email)


@app.get("/api/gst/check")
def gst_check(gstin: str = "", authorization: str | None = Header(default=None)):
    require_user(authorization)
    return gst.describe_gstin(gstin)


@app.get("/api/gst/rate")
def gst_rate(hsn: str = "", price: float = 0, name: str = "",
             authorization: str | None = Header(default=None)):
    """Live rate preview while a seller types an HSN into the product form."""
    require_user(authorization)
    return gst.resolve_rate(hsn, int(round(price * 100)), name, inclusive=True)


@app.get("/api/gst/suggest-hsn")
def gst_suggest(category: str = "", name: str = "",
                authorization: str | None = Header(default=None)):
    require_user(authorization)
    return {"hsn": gst.suggest_hsn(category, name)}


@app.get("/api/invoices")
def invoice_list(fy: str = "", authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {"invoices": invoices.listing(email, fy),
            "fy": fy or gst.financial_year(),
            "settings": invoices.settings_status(email)}


@app.get("/api/invoices/preview")
def invoice_preview(order_id: str, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    order = next((o for o in storefront.get_orders(email) if o.get("id") == order_id), None)
    if not order:
        raise HTTPException(404, "Order not found")
    existing = invoices.for_order(email, order_id)
    return {"preview": invoices.build_from_order(email, order), "existing": existing}


@app.post("/api/invoices/issue")
def invoice_issue(body: IssueInvoiceBody,
                  authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    order = next((o for o in storefront.get_orders(email) if o.get("id") == body.order_id), None)
    if not order:
        raise HTTPException(404, "Order not found")
    return invoices.issue(email, order, force=body.force)


@app.post("/api/invoices/cancel")
def invoice_cancel(body: CancelInvoiceBody,
                   authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return invoices.cancel(email, body.invoice_id, body.reason or "")


@app.get("/api/invoices/{invoice_id}/pdf")
def invoice_download(invoice_id: str, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    inv = invoices.get(email, invoice_id)
    if not inv:
        raise HTTPException(404, "Invoice not found")
    pdf = invoice_pdf.build(inv)
    name = (inv.get("number") or invoice_id).replace("/", "-")
    return Response(content=pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{name}.pdf"'})


@app.get("/api/gstr1")
def gstr1_view(fy: str = "", authorization: str | None = Header(default=None)):
    return invoices.gstr1(require_user(authorization), fy)


@app.get("/api/gstr1.csv")
def gstr1_csv(fy: str = "", authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    csv = invoices.gstr1_csv(email, fy)
    return Response(content=csv, media_type="text/csv",
                    headers={"Content-Disposition":
                             f'attachment; filename="gstr1-{fy or gst.financial_year()}.csv"'})


@app.post("/api/orders/labels")
def order_labels(body: LabelBody, authorization: str | None = Header(default=None)):
    """The Generate Bill Sticker button. Takes one order or a whole morning's
    dispatch and returns a single print-ready PDF."""
    email = require_user(authorization)
    wanted = set(body.order_ids or [])
    rows = [o for o in storefront.get_orders(email) if not wanted or o.get("id") in wanted]
    if not rows:
        raise HTTPException(404, "No matching orders")
    pdf = labels.build_many(rows, _seller_profile(email), sitebuilder.get_site(email))
    fname = ("label-" + rows[0].get("order_no", "order")) if len(rows) == 1 else \
            f"labels-{len(rows)}-orders"
    return Response(content=pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{fname}.pdf"'})


# =========================================================================
# Cancellation requests — the WhatsApp conversation, not a fired action
# =========================================================================
@app.post("/api/shop/{handle}/cancel-request")
def shopper_cancel_request(handle: str, body: CancelRequestBody, request: Request):
    """Called from the shopper's own order page. Deliberately does NOT cancel."""
    seller = sitebuilder.resolve_handle(handle)
    if not seller:
        raise HTTPException(404, "Store not found")
    order = next((o for o in storefront.get_orders(seller) if o.get("id") == body.order_id), None)
    if not order:
        raise HTTPException(404, "Order not found")
    if order.get("status") in ("delivered", "cancelled"):
        return {"ok": False,
                "message": "This order is already " + str(order.get("status")) + "."}

    req = cancel_requests.raise_request(
        seller, kind="order", ref_id=order["id"], ref_no=order.get("order_no", ""),
        reason_code=body.reason_code, reason_text=body.reason_text or "",
        raised_by="shopper",
        counterparty={"name": order.get("customer_name"), "phone": order.get("phone")})

    site = sitebuilder.get_site(seller)
    payload = cancel_requests.notify_payload(
        seller, req, site.get("name") or "the store",
        (invoices.get_settings(seller).get("pickup_address") or {}).get("phone")
        or site.get("contact_phone") or "")

    try:
        messaging.send(to_email=seller,
                       subject=f"Cancellation request - order {order.get('order_no')}",
                       text=payload["seller_text"])
    except Exception:  # noqa: BLE001
        # A failed email must never lose the request itself. The seller still
        # sees it in Orders, and the WhatsApp link still works.
        pass
    cancel_requests.mark_notified(seller, req["id"])
    cache.clear(seller)

    return {"ok": True, "request": req,
            "message": "We've told the seller. Nothing is cancelled yet — they "
                       "will message you on WhatsApp shortly.",
            "seller_wa": payload["seller_wa"]}


@app.get("/api/cancel-requests")
def cancel_request_list(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    site = sitebuilder.get_site(email)
    rows = cancel_requests.open_requests(email)
    for r in rows:
        r["links"] = cancel_requests.notify_payload(email, r, site.get("name") or "our store", "")
    return {"open": rows, "history": cancel_requests.history(email, 60),
            "summary": cancel_requests.summary(email)}


@app.post("/api/cancel-requests/resolve")
def cancel_request_resolve(body: ResolveCancelBody,
                           authorization: str | None = Header(default=None)):
    """Approving is the ONLY thing that actually cancels."""
    email = require_user(authorization)
    req = cancel_requests.resolve(email, body.request_id, body.decision, body.note or "")
    if req.get("error"):
        raise HTTPException(404, req["error"])
    if body.decision == "approved":
        if req.get("kind") == "po":
            supply.set_po_status(email, req["ref_id"], "cancelled",
                                 note=req.get("reason_label", ""))
        else:
            storefront.set_status(email, req["ref_id"], "cancelled", by="shopper",
                                  reason=req.get("reason_code") or "requested")
    cache.clear(email)
    return {"request": req, "summary": cancel_requests.summary(email)}


@app.post("/api/purchase-orders/cancel-request")
def po_cancel_request(body: PoCancelRequestBody,
                      authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    po = supply.get_po(email, body.po_number)
    if not po:
        raise HTTPException(404, "Purchase order not found")
    sup = po.get("supplier") or {}
    req = cancel_requests.raise_request(
        email, kind="po", ref_id=str(po.get("po_number")), ref_no=str(po.get("po_number")),
        reason_code=body.reason_code, reason_text=body.reason_text or "",
        raised_by="seller",
        counterparty={"name": sup.get("name"), "phone": sup.get("phone")})
    site = sitebuilder.get_site(email)
    return {"request": req,
            "links": cancel_requests.notify_payload(email, req,
                                                    site.get("name") or "our store", "")}


# =========================================================================
# Purchase orders — the manual path
# =========================================================================
@app.post("/api/purchase-orders/manual")
def po_manual(body: ManualPoBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        po = supply.create_manual_po(email, body.supplier or {}, body.lines or [],
                                     body.expected_on or "", body.terms or "",
                                     body.note or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    send = {}
    if body.send:
        # Straight out to the supplier, PO attached, no draft to approve — the
        # seller already said what to order and to whom.
        try:
            send = replenish.send_po(email, po["po_number"])
        except Exception as e:  # noqa: BLE001 — the PO exists either way
            errors.record(e, where="POST /api/purchase-orders/manual (send)", email=email)
            send = {"sent": False, "reason": str(e)[:200]}
    cache.clear(email)
    return {**(supply.get_po(email, po["po_number"]) or po), "send": send,
            "supply": _supply_payload(email)}


@app.post("/api/purchase-orders/status")
def po_status(body: PoStatusBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    try:
        po = supply.set_po_status(email, body.po_number, body.status, body.note or "")
    except ValueError as e:
        raise HTTPException(400, str(e))
    if po is None:
        raise HTTPException(404, "Purchase order not found")
    cache.clear(email)
    return po


# =========================================================================
# Social Media Manager
# =========================================================================
def _social_catalogue(email: str) -> list[dict]:
    out = []
    for p in products.listed_products(email):
        out.append({"id": p.get("id"), "name": p.get("name"), "price": p.get("price"),
                    "description": p.get("description"), "category": p.get("category"),
                    "stock": p.get("stock")})
    return out


@app.get("/api/social/performance")
def social_performance(days: int = 28, refresh: int = 0,
                       authorization: str | None = Header(default=None)):
    """What the seller's Instagram posts actually did, joined to the choices
    the planner made.

    A refusal from Instagram is a 200 with a `refused` block, not an error
    status. That is deliberate: for most accounts, most of the time, a refusal
    IS the answer (an app can only read insights for accounts on its tester
    list until Meta has reviewed it), and a screen that has to distinguish
    "your numbers are here" from "Instagram will not give them to us yet" needs
    both shapes to arrive the same way.
    """
    email = require_user(authorization)
    if refresh:
        from backend.core import iginsights
        iginsights.clear_cache(email)
    try:
        data = social.performance(email, days=max(1, min(int(days or 28), 90)))
    except Exception as e:                                       # noqa: BLE001
        errors.record(e, where="GET /api/social/performance", email=email)
        raise HTTPException(500, "Could not read the Instagram numbers just now.")
    return {**data, "readiness": social.performance_readiness(email)}


@app.get("/api/social")
def social_home(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {
        "settings": social.get_settings(email),
        "pillars": social.PILLARS,
        "cadence": social.CADENCE,
        "formats": social.FORMATS,
        "languages": social.LANGUAGES,
        # How many of the month's AI pictures are used, for the tracker in the
        # header. Carried here so the Social screen needs no second round trip.
        "image_quota": aicaps.image_month_status(email),
        "week": social.week(email),
        "radar": social.radar(email),
        "working": social.whats_working(email),
        "ai": aiprovider.status(),
        "offer_cap": social.OFFER_CAP_PERCENT,
        "catalogue_size": len(_social_catalogue(email)),
        "autoplan": _safe_autoplan_status(email),
        "day_names": autoplan.DAY_NAMES,
        # Whether posts can go out by themselves. Wrapped because a broken
        # credential store must not take the whole Social screen down with it —
        # planning works perfectly well with Instagram disconnected.
        "instagram": _safe_instagram_status(email),
    }


def _safe_instagram_status(email: str) -> dict:
    try:
        st = instagram.status(email)
        # `refresh_if_due` is cheap when it is not due and this is the screen a
        # seller looks at most, so it is the natural place to keep a 60-day
        # token alive without a second scheduler.
        if st.get("connected"):
            try:
                instagram.refresh_if_due(email)
            except Exception:  # noqa: BLE001
                pass
        return {**st, "oauth_available": instagram.oauth_configured()}
    except Exception:  # noqa: BLE001
        return {"connected": False, "oauth_available": instagram.oauth_configured()}


@app.post("/api/social/settings")
def social_settings(body: SocialSettingsBody,
                    authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return social.save_settings(email, body.patch or {})


@app.post("/api/social/week")
def social_week(body: SocialWeekBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cat = _social_catalogue(email)
    if not cat:
        raise HTTPException(400, "Add a product first, there is nothing to post about.")
    # "Plan this week" runs the SAME planner the scheduler ("Plan next week now")
    # runs — sales signals, the story engine and the festival auto-scheduling —
    # so the two buttons can never produce different kinds of plan. The only
    # difference is which week: this button plans the current week, the scheduler
    # the next. replace=True so a re-press rebuilds this week's drafts; wait so a
    # background catch-up in flight is waited on rather than erroring.
    #
    # "Plan 4 weeks" still uses the multi-week builder — a different feature.
    if body.weeks and body.weeks > 1:
        made = social.plan_ahead(email, cat, body.weeks)
        return {"posts": made, "week": social.week(email)}
    from datetime import timedelta as _td
    today = autoplan.now_local(email).date()
    this_week = today - _td(days=today.weekday())
    # "This week" means the coming full week of content. If enough of the current
    # week is still ahead to hold the cadence, plan it; once it is nearly over
    # (a press on Friday or the weekend) plan the upcoming week instead — which
    # is what the old builder effectively did by rolling forward from today.
    cadence = social.CADENCE.get(social.get_settings(email).get("cadence") or "standard",
                                 social.CADENCE["standard"])["posts"]
    days_left = sum(1 for i in range(7) if (this_week + _td(days=i)) >= today)
    target = this_week if days_left >= cadence else autoplan.next_monday(today)
    res = autoplan.run_for(email, target, trigger="manual", replace=True, wait=120)
    if res.get("skipped"):
        raise HTTPException(409, res.get("reason") or "A plan is already being made.")
    cache.clear(email)
    return {"posts": social.week(email), "week": social.week(email), "brief": res}


@app.post("/api/social/approve-all")
def social_approve(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {**social.approve_all(email), "week": social.week(email)}


@app.get("/api/social/post/{post_id}")
def social_post_get(post_id: str, authorization: str | None = Header(default=None)):
    """One post by id -- lets the Approval panel's 'Details' open the editor
    for a post that isn't necessarily in the currently-loaded calendar month
    (the panel only shows the next 7 days; the post itself can be further out)."""
    email = require_user(authorization)
    p = social.get_post(email, post_id)
    if not p:
        raise HTTPException(404, "That post no longer exists.")
    return p


@app.post("/api/social/clear")
def social_clear(authorization: str | None = Header(default=None)):
    """The full reset: every planned post and tracked campaign, gone. For
    walking away from a plan entirely rather than deciding it post by post."""
    email = require_user(authorization)
    n = social.clear_plan(email)
    cache.clear(email)
    return {"cleared": n}


@app.post("/api/social/post")
def social_post_update(body: SocialPostBody,
                       authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    p = social.update_post(email, body.post_id, body.patch or {})
    if p.get("error"):
        raise HTTPException(404, p["error"])
    return p


@app.post("/api/social/state")
def social_post_state(body: SocialStateBody,
                      authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    p = social.set_state(email, body.post_id, body.state)
    if p.get("error"):
        raise HTTPException(400, p["error"])
    return p


@app.post("/api/social/regenerate")
def social_regenerate(body: SocialCloneBody,
                      authorization: str | None = Header(default=None)):
    """Rewrite one post's caption without touching the rest of the week."""
    email = require_user(authorization)
    post = next((p for p in social.week(email) if p.get("id") == body.post_id), None)
    if not post:
        raise HTTPException(404, "Post not found")
    cat = {p["id"]: p for p in _social_catalogue(email)}
    product = cat.get(post.get("product_id")) or {"name": post.get("product_name")}
    cap = social.write_caption(email, product, post.get("pillar") or "detail")
    return social.update_post(email, body.post_id, {
        "hook": cap.get("hook"), "body": cap.get("body"),
        "question": cap.get("question"), "cta": cap.get("cta"),
        "tags": cap.get("tags")})


@app.post("/api/social/regenerate-script")
def social_regenerate_script(body: SocialCloneBody,
                             authorization: str | None = Header(default=None)):
    """Rewrite one reel's shot list without touching the rest of the week.

    Also the way a reel planned before scripts existed gets one: the editor
    offers this same action whenever a reel post's script is empty."""
    email = require_user(authorization)
    post = next((p for p in social.week(email) if p.get("id") == body.post_id), None)
    if not post:
        raise HTTPException(404, "Post not found")
    if post.get("format") != "reel":
        raise HTTPException(400, "Only reel-format posts get a script.")
    cat = {p["id"]: p for p in _social_catalogue(email)}
    product = cat.get(post.get("product_id")) or {"name": post.get("product_name")}
    occasion = ({"name": post["occasion"], "days_away": post.get("occasion_days") or 0}
               if post.get("occasion") else None)
    script = social.write_reel_script(email, product, post.get("pillar") or "detail",
                                      occasion=occasion,
                                      shot_type=post.get("shot_type") or "",
                                      theme=post.get("theme_note") or "")
    return social.update_post(email, body.post_id, {"script": script})


@app.post("/api/social/clone")
def social_clone(body: SocialCloneBody, authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    p = social.clone_winner(email, body.post_id, _social_catalogue(email))
    if p.get("error"):
        raise HTTPException(400, p["error"])
    return p


@app.get("/api/social/shoot-list")
def social_shoot(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return social.shoot_list(email, _social_catalogue(email))


# =========================================================================
# AI provider status — so a seller can see what is writing their copy
# =========================================================================
class AiWriteBody(BaseModel):
    kind: str = "general"
    label: str | None = ""
    current: str | None = ""
    context: dict | None = None
    instruction: str | None = ""


class AiSiteCopyBody(BaseModel):
    brief: str


class AiProductCopyBody(BaseModel):
    product: dict = {}
    notes: str | None = ""


def _ai_meta() -> dict:
    st = aiprovider.status()
    return {"ready": st["ready"], "active": st["active"],
            # With nothing configured on the server the browser can still ask
            # Puter directly (puter.js), on the seller's own Puter account.
            "browser_puter": (os.environ.get("AI_BROWSER_PUTER", "on").lower()
                              not in ("off", "0", "false"))}


@app.get("/api/ai/status")
def ai_status(authorization: str | None = Header(default=None)):
    require_user(authorization)
    return _ai_meta()


@app.post("/api/ai/write")
def ai_write(body: AiWriteBody, authorization: str | None = Header(default=None)):
    """The ✨ on any text field: write it, or improve what is there, in the
    brand's voice and from the seller's own facts only."""
    email = require_user(authorization)
    try:
        aicaps.check(email, "text")
    except aicaps.CapReached:
        raise
    except Exception:  # noqa: BLE001 — the cap is a guard, not a dependency
        pass
    res = writer.write_field(email, body.kind or "general", body.label or "",
                             body.current or "", body.context or {}, body.instruction or "")
    try:
        if res.get("ai"):
            aicaps.consume(email, "text")
            from backend.core import credits
            credits.spend(email, "text")
    except Exception:  # noqa: BLE001
        pass
    return {**res, **{"meta": _ai_meta()}}


@app.post("/api/ai/site-copy")
def ai_site_copy(body: AiSiteCopyBody, authorization: str | None = Header(default=None)):
    """Every word on the storefront from a line or two about the shop. Nothing
    is saved here — the builder shows it first and the seller picks what to use."""
    email = require_user(authorization)
    if len((body.brief or "").strip()) < 8:
        raise HTTPException(400, "Tell us a little about your shop first, a sentence is enough.")
    res = writer.site_copy(email, body.brief)
    return {**res, "meta": _ai_meta()}


@app.post("/api/ai/product-copy")
def ai_product_copy(body: AiProductCopyBody, authorization: str | None = Header(default=None)):
    """Description, key points and a search description for one product."""
    email = require_user(authorization)
    if not (body.product or {}).get("name"):
        raise HTTPException(400, "Give the product a name first.")
    return {**writer.product_copy(email, body.product or {}, body.notes or ""),
            "meta": _ai_meta()}


@app.get("/api/ai/providers")
def ai_providers(authorization: str | None = Header(default=None)):
    require_user(authorization)
    st = aiprovider.status()
    st["storage_durable"] = media.durable()
    return st


# =========================================================================
# Product Studio — design language and image generation
# =========================================================================
@app.get("/api/studio/design-language")
def studio_design_language(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    brand = studio.get_brand(email)
    return {"refs": brand.get("refs") or [], "aesthetic": brand.get("aesthetic") or "",
            "aesthetic_from": brand.get("aesthetic_from") or 0,
            "vision_ready": aiprovider.vision_ready(),
            "image_engine": studio.image_engine()}


@app.post("/api/studio/design-language/add")
def studio_ref_add(body: StudioRefBody,
                   authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return studio.add_ref(email, body.url)


@app.post("/api/studio/design-language/remove")
def studio_ref_remove(body: StudioRefBody,
                      authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return studio.remove_ref(email, body.url)


@app.post("/api/studio/design-language/read")
def studio_read_aesthetic(authorization: str | None = Header(default=None)):
    """Look at the reference images and write what they have in common."""
    email = require_user(authorization)
    res = studio.read_aesthetic(email)
    if not res.get("ok"):
        raise HTTPException(400, res.get("reason", "Could not read the references."))
    cache.clear(email)
    return res


@app.post("/api/studio/read-shots")
def studio_read_shots(body: StudioReadShotsBody,
                      authorization: str | None = Header(default=None)):
    """Look at a product's own photographs and write what the thing is.

    This is the step that makes generated imagery resemble the actual product
    rather than a plausible invention of one."""
    email = require_user(authorization)
    res = studio.read_product_shots(email, body.product_id)
    if not res.get("ok"):
        raise HTTPException(400, res.get("reason", "Could not read the photos."))
    return res


@app.post("/api/studio/image")
def studio_image_only(body: StudioImageOnlyBody,
                      authorization: str | None = Header(default=None)):
    """Generate a picture and nothing else — no caption rewritten over the top.

    When `post_id` is given the image is attached to that planned post, so it
    shows up in the Social Media Manager's week -- and, if the post is tied
    to a festival, that festival's colours and motifs are worked into the
    photo too (see studio.guidance_for). Without this the picture had no way
    to know it was a Ganesh Chaturthi post at all; only the caption did."""
    email = require_user(authorization)
    occasion_key = ""
    shot_type = body.shot_type or ""
    if body.post_id:
        post = social.get_post(email, body.post_id)
        if post:
            occasion_key = post.get("occasion_key") or ""
            # The beat already knows what kind of photograph it is; an explicit
            # shot_type on the request still wins, so the editor can override.
            shot_type = shot_type or post.get("shot_type") or ""
    try:
        img = studio.generate_image_only(email, body.product_id,
                                         body.pillar or "", body.format or "",
                                         body.angle or "",
                                         use_reference=body.use_reference,
                                         strength=body.strength,
                                         occasion_key=occasion_key,
                                         shot_type=shot_type,
                                         engine=body.engine or "")
    except aicaps.CapReached as e:
        # When the picture is for a planned post, the cap is not a dead end: put
        # the post's own upload task on the list (carrying the shot we would have
        # made) so the seller can add their own photo, then let the 429 through
        # so the button shows the same allowance message everywhere.
        if body.post_id:
            post = social.get_post(email, body.post_id)
            if post:
                shot = ""
                try:
                    shot = studio.preview_prompt(
                        email, body.product_id, body.pillar or "", body.format or "",
                        body.angle or "", use_reference=body.use_reference,
                        occasion_key=occasion_key, shot_type=shot_type).get("prompt", "")
                except Exception:  # noqa: BLE001
                    shot = ""
                smart.ensure_post_task(
                    email, post,
                    "video" if post.get("format") == "reel" else "photo",
                    reason=str(e), prompt=shot)
        raise            # 429 via the handler, not a 400
    except (RuntimeError, ValueError) as e:
        raise HTTPException(400, str(e))
    if body.post_id:
        social.attach_image(email, body.post_id, img["url"], True, img.get("prompt", ""))
    cache.clear(email)
    return img


@app.post("/api/studio/prompt-preview")
def studio_prompt_preview(body: StudioImageOnlyBody,
                          authorization: str | None = Header(default=None)):
    """Show the seller the exact instruction the image AI will be given.

    No generation, no cost. This is how "it ignored my brand" becomes an
    answerable question.
    """
    email = require_user(authorization)
    occasion_key, shot_type = "", body.shot_type or ""
    if body.post_id:
        post = social.get_post(email, body.post_id)
        if post:
            occasion_key = post.get("occasion_key") or ""
            shot_type = shot_type or post.get("shot_type") or ""
    try:
        return studio.preview_prompt(email, body.product_id, body.pillar or "",
                                     body.format or "", body.angle or "",
                                     use_reference=body.use_reference,
                                     occasion_key=occasion_key, shot_type=shot_type)
    except aicaps.CapReached:
        raise            # 429 via the handler, not a 400
    except (RuntimeError, ValueError) as e:
        raise HTTPException(400, str(e))


@app.post("/api/social/attach-image")
def social_attach(body: SocialAttachBody,
                  authorization: str | None = Header(default=None)):
    """Attach any image — generated, uploaded, or exported from elsewhere."""
    email = require_user(authorization)
    p = social.attach_image(email, body.post_id, body.url, False, "")
    if p.get("error"):
        raise HTTPException(404, p["error"])
    return p


class SocialReadyBody(BaseModel):
    post_id: str
    # A reel is filmed or generated, never drawn — so "make the media for me"
    # means different things per format and the caller says which it wants.
    generate: bool = True
    engine: str | None = ""


def _approve_post_ready(email: str, post_id: str, generate: bool = True,
                        engine: str = "") -> dict:
    """Approve one post and do the work that approving it implies.

    WHY: approving used to mean "set a flag". The seller then had to find the
    post in the calendar, generate its picture and save — three steps after
    they had already said yes. Approving now means "yes, make it ready":

      * a PHOTO post gets its picture generated from Product Studio (the
        product's own photo + the brand's look), passed through the watermark
        remover, attached, and the post is SCHEDULED;
      * a REEL cannot be drawn — there is no single photograph that is a
        video — so it is marked APPROVED and a task goes to the top of the
        Home task list that walks the seller through it: copy the prompt,
        open Google Flow, paste and generate, upload the clip here (cleaned of
        Flow's mark on the way in), then save & schedule.

    A picture that cannot be made (no engine, allowance spent) never loses the
    decision: the post is approved, the reason is reported, and it gets a task
    of its own so it cannot slip out with an empty frame."""
    post = social.get_post(email, post_id)
    if not post:
        raise HTTPException(404, "Post not found")

    is_reel = post.get("format") == "reel"
    made, media_error, script, task = None, "", None, None
    img_prompt = ""     # the shot we would have made, for the upload task on a cap

    if is_reel:
        script = post.get("script") or None
        if not script or not (script.get("beats") or []):
            cat = {p["id"]: p for p in _social_catalogue(email)}
            product = cat.get(post.get("product_id")) or {"name": post.get("product_name")}
            occasion = ({"name": post["occasion"],
                         "days_away": post.get("occasion_days") or 0}
                        if post.get("occasion") else None)
            script = social.write_reel_script(
                email, product, post.get("pillar") or "detail", occasion=occasion,
                shot_type=post.get("shot_type") or "",
                theme=post.get("theme_note") or "")
            social.update_post(email, post_id, {"script": script})
            script = (social.get_post(email, post_id) or {}).get("script") or script
    elif generate and not post.get("image_url"):
        try:
            made = studio.generate_image_only(
                email, post.get("product_id") or "",
                post.get("pillar") or "", post.get("format") or "",
                use_reference=True,
                occasion_key=post.get("occasion_key") or "",
                shot_type=post.get("shot_type") or "",
                engine=engine or "")
            social.attach_image(email, post_id, made["url"], True,
                                made.get("prompt", ""))
        except aicaps.CapReached as e:
            media_error = str(e)
            # The picture could not be made because the allowance is spent, so
            # the seller is going to add their own. Work out the shot we WOULD
            # have generated (no cost — it is just the text prompt) and hand it
            # to the task, so "add your own photo" comes with the picture to
            # take rather than a blank instruction.
            try:
                img_prompt = studio.preview_prompt(
                    email, post.get("product_id") or "",
                    post.get("pillar") or "", post.get("format") or "",
                    use_reference=True,
                    occasion_key=post.get("occasion_key") or "",
                    shot_type=post.get("shot_type") or "").get("prompt", "")
            except Exception:  # noqa: BLE001 — a missing prompt must not block approval
                img_prompt = ""
        except (RuntimeError, ValueError) as e:
            media_error = str(e)

    fresh = social.get_post(email, post_id) or post
    if social.post_ready(fresh):
        p = social.set_state(email, post_id, "scheduled")
    else:
        p = social.set_state(email, post_id, "approved")
        task = smart.ensure_post_task(email, fresh, "video" if is_reel else "photo",
                                      reason=media_error, prompt=img_prompt)
    if p.get("error"):
        raise HTTPException(400, p["error"])
    cache.clear(email)
    out_post = social.get_post(email, post_id)
    return {"post": out_post,
            "image": made, "script": script, "is_reel": is_reel,
            "media_error": media_error, "task": task,
            "tasks": smart.get_tasks(email),
            "watermark": (made or {}).get("watermark"),
            "ready": social.post_ready(out_post or {})}


@app.post("/api/social/approve-ready")
def social_approve_ready(body: SocialReadyBody,
                         authorization: str | None = Header(default=None)):
    """Approve a post AND give it what it needs — see _approve_post_ready."""
    email = require_user(authorization)
    return _approve_post_ready(email, body.post_id, body.generate, body.engine or "")


class SocialScheduleBody(BaseModel):
    post_id: str
    scheduled_at: str | None = ""


@app.post("/api/social/schedule-ready")
def social_schedule_ready(body: SocialScheduleBody,
                          authorization: str | None = Header(default=None)):
    """The last step of a reel task: the clip is on the post, so save and
    schedule it. Refuses a post that still has no media, rather than
    scheduling an empty frame."""
    email = require_user(authorization)
    post = social.get_post(email, body.post_id)
    if not post:
        raise HTTPException(404, "Post not found")
    if not social.post_ready(post):
        raise HTTPException(400, "This reel has no clip yet. Upload it first, then schedule."
                            if post.get("format") == "reel" else
                            "This post has no picture yet. Add one first, then schedule.")
    if body.scheduled_at:
        social.update_post(email, body.post_id, {"scheduled_at": body.scheduled_at})
    p = social.set_state(email, body.post_id, "scheduled")
    cache.clear(email)
    return {"post": p, "tasks": smart.get_tasks(email)}


# -------------------------------------------------------------------------
# Automatic weekly planning — see backend/core/autoplan.py for the flow
# -------------------------------------------------------------------------
class AutoplanSettingsBody(BaseModel):
    enabled: bool | None = None
    day: int | None = None
    hour: int | None = None


class AutoplanRunBody(BaseModel):
    week: str | None = ""       # a Monday, YYYY-MM-DD; default = next week


class AutoplanWeekBody(BaseModel):
    week: str


@app.get("/api/social/autoplan")
def social_autoplan(authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    return {**autoplan.status(email), "day_names": autoplan.DAY_NAMES,
            "watermark": watermark.capabilities(),
            "ai_label": ailabel_mod.compliance_state()}


@app.post("/api/social/autoplan/settings")
def social_autoplan_settings(body: AutoplanSettingsBody,
                             authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    patch = {k: v for k, v in body.model_dump().items() if v is not None} \
        if hasattr(body, "model_dump") else {k: v for k, v in body.dict().items() if v is not None}
    st = autoplan.save_config(email, patch)
    cache.clear(email)
    return st


@app.post("/api/social/autoplan/run-now")
def social_autoplan_run_now(body: AutoplanRunBody,
                            authorization: str | None = Header(default=None)):
    """"Plan next week now" — the same planner the schedule runs, on demand.
    Fills next week up to the cadence and never past it."""
    email = require_user(authorization)
    from datetime import date as _date
    week = None
    if body.week:
        try:
            week = _date.fromisoformat(body.week)
        except ValueError:
            raise HTTPException(400, "week must be a date like 2026-09-14")
        week = week - __import__("datetime").timedelta(days=week.weekday())
    # wait: if the background catch-up grabbed the lock when the app opened, wait
    # for it rather than failing with "a plan is already being made". replace: a
    # re-press rebuilds this week's drafts instead of no-op'ing — the same engine
    # and the same behaviour as the "Plan this week" button.
    res = autoplan.run_for(email, week, trigger="manual", replace=True, wait=120)
    if res.get("skipped"):
        raise HTTPException(409, res.get("reason") or "A plan is already being made.")
    cache.clear(email)
    return {"brief": res, "status": autoplan.status(email), "week": social.week(email)}


@app.get("/api/social/autoplan/brief")
def social_autoplan_brief(week: str = "", authorization: str | None = Header(default=None)):
    """What the planner found for a week: occasions, sales, what it added."""
    email = require_user(authorization)
    b = autoplan.latest_brief(email, week)
    if not b:
        raise HTTPException(404, "No automatic plan for that week yet.")
    return b


@app.post("/api/social/autoplan/cancel")
def social_autoplan_cancel(body: AutoplanWeekBody,
                           authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    n = autoplan.cancel_week(email, body.week)
    cache.clear(email)
    return {"cancelled": n, "insights": smart.build_insights(email)}


@app.post("/api/social/autoplan/run")
def social_autoplan_cron(x_admin_token: str | None = Header(default=None)):
    """Cron target (operator only): plan next week for every account whose
    chosen day and hour have come. Safe to call every 15 minutes — each week
    is planned at most once per account. The app also runs this itself in the
    background; the cron is for hosts that sleep between requests."""
    _require_admin(x_admin_token)
    return autoplan.run_due()


@app.get("/api/studio/video-engine")
def studio_video_engine(authorization: str | None = Header(default=None)):
    """Whether clips can be generated, what one costs, and every engine the
    seller may choose between — asked before the button does anything, so the
    price is never a surprise."""
    require_user(authorization)
    return {**studio.video_engine(), "engines": studio.video_engines()}


@app.get("/api/studio/ai-usage")
def studio_ai_usage(authorization: str | None = Header(default=None)):
    """What is left of today's generation allowance, so nothing is a surprise."""
    return aicaps.status(require_user(authorization))


@app.get("/api/studio/video-tools")
def studio_video_tools(authorization: str | None = Header(default=None)):
    """Where to go to make the clip yourself, and what it costs there.

    Offered ahead of our own generator on purpose: Google Flow's free tier gives
    a seller about five clips a day for nothing and lets them look at the result
    before committing, where our Veo call bills their card about a hundred rupees
    a clip sight unseen. See backend/core/videotools.py.
    """
    require_user(authorization)
    return videotools.tools()


@app.get("/api/studio/image-engines")
def studio_image_engines(reshoot: bool = False,
                         authorization: str | None = Header(default=None)):
    """Every drawing engine this server can offer, so the seller picks rather
    than inheriting whatever the server preferred.

    `reshoot=true` drops the engines that cannot start from the seller's own
    photograph. Offering one there would mean quietly returning a picture of a
    product they do not sell."""
    require_user(authorization)
    rows = studio.image_engines(for_reshoot=reshoot)
    return {"engines": rows, "default": rows[0]["id"] if rows else ""}


class StudioVideoBody(BaseModel):
    product_id: str
    post_id: str | None = ""
    prompt: str | None = ""
    engine: str | None = ""


@app.post("/api/studio/video")
def studio_video(body: StudioVideoBody,
                 authorization: str | None = Header(default=None)):
    """Generate a short clip from the seller's own product photograph.

    Slow — around a minute — and it costs real money per call, so the UI
    confirms the price first and warns that the tab can be left alone."""
    email = require_user(authorization)
    try:
        vid = studio.generate_video(email, body.product_id, body.prompt or "",
                                    engine=body.engine or "")
    except aicaps.CapReached:
        raise            # 429 via the handler, not a 400
    except (RuntimeError, ValueError) as e:
        raise HTTPException(400, str(e))
    if body.post_id:
        social.attach_video(email, body.post_id, vid["url"])
    cache.clear(email)
    return vid


@app.post("/api/social/attach-video")
def social_attach_video(body: SocialAttachBody,
                        authorization: str | None = Header(default=None)):
    """Attach the finished clip to a planned post — filmed on a phone, or
    generated from the shot-list prompt and downloaded.

    Upload the file through /api/site/image first (it already takes MP4 and
    WEBM up to 48MB and stores them durably); this endpoint only records which
    clip belongs to which post. Sending an empty url takes the clip off again,
    so a wrong upload is one action to undo rather than a reason to delete a
    post the seller has already written and scheduled."""
    email = require_user(authorization)
    if not social.get_post(email, body.post_id):
        raise HTTPException(404, "not found")
    url, report, label = body.url, None, None
    # A reel clip is almost always generated somewhere else: Google Flow, Kling,
    # Veo. What happens to it on the way in changed on 15 September 2026. It used
    # to have the other tool's mark rubbed out, which the IT Rules as amended on
    # 20 February 2026 forbid a platform like this one from enabling. Now, if the
    # seller says the clip was AI made, we put OUR label on it, which is what the
    # same rule requires. If they say it was filmed, it is stored untouched.
    if url and body.ai_generated:
        from backend.core import ailabel
        done = ailabel.label_media_url(url, email, engine="uploaded",
                                      kind_hint="video")
        url, label = done["url"], done["report"]
    if url and body.clean and not body.ai_generated:
        # Older clients still send clean=True. The gate reports honestly rather
        # than pretending something was removed.
        cleaned = watermark.clean_media_url(url, email)
        url, report = cleaned["url"], cleaned["report"]
    p = social.attach_video(email, body.post_id, url, original_url=body.url or "",
                            watermark=report or {}, ai_label=label or {})
    if p.get("error"):
        raise HTTPException(404, p["error"])
    # Everything below is bookkeeping. The clip is on the post by now, and a
    # failure ticking task steps must not turn a finished upload into an error.
    if url and p.get("state") == "approved":
        try:
            smart_tasks_for = [t for t in smart.post_tasks(email)
                               if t.get("post_id") == body.post_id and not t.get("done")]
            # A clip on the post means every step before the upload happened too.
            for t in smart_tasks_for:
                for step in ("copy", "flow", "make", "upload"):
                    smart.task_progress(email, t["id"], step, True)
        except Exception as e:  # noqa: BLE001
            errors.record(e, where="POST /api/social/attach-video (task steps)", email=email)
    try:
        cache.clear(email)
    except Exception:  # noqa: BLE001
        pass
    try:
        tasks = smart.get_tasks(email)
    except Exception:  # noqa: BLE001
        tasks = None
    return {**p, "watermark": report, "ai_label": label,
            **({"tasks": tasks} if tasks is not None else {})}


class SocialRecleanBody(BaseModel):
    post_id: str
    corner: str = "bottom-right"


@app.post("/api/social/reclean-video")
def social_reclean_video(body: SocialRecleanBody,
                         authorization: str | None = Header(default=None)):
    """"Still see a watermark?" — run the remover again on the ORIGINAL upload,
    told which corner the mark is in. Pointing at a corner lets it accept a
    fainter or smaller mark, and one on a shot that barely moves, which it
    will not risk guessing at on its own."""
    email = require_user(authorization)
    from backend.core import ailabel
    if not ailabel.removal_enabled():
        # A button that reports success and changes nothing is worse than a
        # button that is gone. This tells the seller the lawful way to get the
        # clean frame they are asking for.
        raise HTTPException(400,
            "We cannot take another tool's watermark off a clip. Indian law "
            "(IT Rules 2021, as amended on 20 February 2026) requires a platform "
            "that offers AI generation to make sure an AI label cannot be "
            "removed. Do it at the source instead: in Google Flow open Settings "
            "and switch Media Watermark off, then generate the clip again. Free "
            "accounts have that setting. Kling's free tier does not, so use Flow "
            "for clips you want unmarked. Our own AI label still goes on, "
            "because that one is required.")
    if body.corner not in watermark.CORNER_NAMES:
        raise HTTPException(400, "Pick a corner: " + ", ".join(watermark.CORNER_NAMES))
    post = social.get_post(email, body.post_id)
    if not post:
        raise HTTPException(404, "That post no longer exists.")
    src = post.get("video_original_url") or post.get("video_url") or ""
    if not src:
        raise HTTPException(400, "This post has no clip yet, upload one first.")
    cleaned = watermark.clean_media_url(src, email, corner=body.corner)
    report = {**(cleaned.get("report") or {}), "corner": body.corner}
    if report.get("removed"):
        p = social.attach_video(email, body.post_id, cleaned["url"], original_url=src, watermark=report)
    else:
        p = social.attach_video(email, body.post_id, post.get("video_url") or src,
                                original_url=src, watermark=report)
    try:
        cache.clear(email)
    except Exception:  # noqa: BLE001
        pass
    return {**p, "watermark": report}


@app.get("/api/managers")
def manager_desks(authorization: str | None = Header(default=None)):
    """Who is on the team and what each of them has waiting."""
    email = require_user(authorization)
    cards = smart.build_insights(email)
    return {"managers": list(personas.MANAGERS.values()),
            "desks": personas.desks(cards), "pending": len(cards)}


@app.get("/api/social/month")
def social_month(year: int = 0, month: int = 0,
                 authorization: str | None = Header(default=None)):
    """One month of the plan, laid out as a calendar.

    Festivals come back whether or not anything is planned for them — the empty
    ones are the point. A seller flipping to October should see Navratri and
    Diwali sitting there with nothing against them."""
    email = require_user(authorization)
    from datetime import date as _date
    t = _date.today()
    return social.month(email, year or t.year, month or t.month)


@app.get("/api/social/upcoming")
def social_upcoming(days: int = 5, authorization: str | None = Header(default=None)):
    """The next few days, for the home screen."""
    email = require_user(authorization)
    rows = social.upcoming(email, days)
    return {"posts": rows,
            "needs_decision": len([p for p in rows if p.get("state") == "draft"])}


# =========================================================================
# Festival campaigns — a plan with a shape, not a queue of suggestions
# =========================================================================
@app.get("/api/social/festivals")
def social_festivals(authorization: str | None = Header(default=None)):
    """The festivals worth this seller's time, best first.

    Filtered by category weight rather than listed exhaustively: a perfume
    seller offered Dhanteras learns quickly that the suggestions are not
    thought through."""
    email = require_user(authorization)
    s = social.get_settings(email)
    cat = s.get("category") or "clothing"
    live = {c["key"]: c for c in social.campaigns(email)}
    out = []
    for f in playbook.for_category(cat):
        prev = social.campaign_preview(email, f["key"])
        out.append({
            "key": f["key"], "name": f["name"], "weight": f["weight_for"],
            "core": f["core"], "buys_for": f["buys_for"],
            "date": prev.get("date", ""), "days_out": prev.get("days_out"),
            "undated": bool(prev.get("undated")),
            "late": bool(prev.get("late")),
            "running": f["key"] in live,
            "note": f.get("note", ""),
        })
    return {"category": cat, "festivals": out,
            "campaigns": social.campaigns(email)}


@app.get("/api/social/campaign")
def social_campaign_preview(festival: str,
                            authorization: str | None = Header(default=None)):
    """What the campaign would be, before anything is created."""
    email = require_user(authorization)
    return social.campaign_preview(email, festival)


@app.post("/api/social/campaign")
def social_campaign_start(body: FestivalCampaignBody,
                          authorization: str | None = Header(default=None)):
    email = require_user(authorization)
    cat = _social_catalogue(email)
    if not cat:
        raise HTTPException(400, "Add a product first, there is nothing to post about.")
    res = social.start_campaign(email, body.festival, cat)
    if res.get("error"):
        raise HTTPException(400, res["error"])
    cache.clear(email)
    return res


@app.post("/api/social/campaign/revert")
def social_campaign_revert(body: FestivalCampaignBody,
                           authorization: str | None = Header(default=None)):
    """Undo a planned festival campaign. Removes its still-unposted posts and
    forgets the campaign; anything already published is left untouched."""
    email = require_user(authorization)
    res = social.revert_campaign(email, body.festival)
    cache.clear(email)
    return res


@app.get("/api/social/playbook")
def social_playbook(festival: str, authorization: str | None = Header(default=None)):
    """The full content library entry — angles, taglines, cautions, what people
    actually buy. Shown to the seller, not just fed to the model."""
    email = require_user(authorization)
    s = social.get_settings(email)
    b = playbook.brief(festival, s.get("category") or "clothing")
    if not b:
        raise HTTPException(404, "No playbook for that festival")
    return b


# Every first path segment this app answers on is a word no shop may take as
# its handle, now that /<handle> is a shop's address. Computed from the routes
# themselves, at the end of this module where all of them exist, so a route
# added later is reserved without anybody having to remember to reserve it.
def _reserve_app_routes() -> None:
    segs = set()
    for r in app.routes:
        p = getattr(r, "path", "") or ""
        first = p.split("/")[1] if p.startswith("/") and "/" in p[1:] + "/" else ""
        if first and "{" not in first:
            segs.add(first)
    sitebuilder.reserve_routes(segs)


_reserve_app_routes()
